//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BvRedWy6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/contact",
			"/offers",
			"/products/$id",
			"/products/accessories",
			"/products/ev",
			"/products/lubes",
			"/resources/video-gallery",
			"/vehicles/$slug",
			"/vehicles/"
		],
		preloads: [
			"/assets/index-Buozkgqt.js",
			"/assets/jsx-runtime-DwuOsvnn.js",
			"/assets/Match-D4TgXLiq.js",
			"/assets/link-YnfR2v_a.js",
			"/assets/matchContext-CFXVncMh.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Buozkgqt.js"
		} }]
	},
	"/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D3KdZrQj.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/arrow-right-B8TqEU9E.js",
			"/assets/badge-percent-DCPulaBE.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/vehicle-card-BfrKgxhL.js",
			"/assets/phone-Bv5op1u-.js",
			"/assets/shield-check-C8fO0WMy.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/about": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BgQ1NGla.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/arrow-right-B8TqEU9E.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/phone-Bv5op1u-.js"
		]
	},
	"/admin": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.tsx",
		children: [
			"/admin/enquiries",
			"/admin/offers",
			"/admin/products",
			"/admin/vehicles",
			"/admin/"
		],
		preloads: [
			"/assets/admin-B0Y1I0Bk.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/badge-percent-DCPulaBE.js",
			"/assets/bike-CLaq02f9.js",
			"/assets/inbox-CJWEGP_o.js",
			"/assets/package-open-D4fB9M6k.js",
			"/assets/shield-check-C8fO0WMy.js",
			"/assets/label-vfCtvWu0.js"
		]
	},
	"/contact": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-mswqCI-u.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/enquiry-form-DcCMCrQt.js",
			"/assets/clock-C24gDAYP.js",
			"/assets/phone-Bv5op1u-.js"
		]
	},
	"/offers": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-9LDlJj6Q.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/badge-percent-DCPulaBE.js",
			"/assets/bike-CLaq02f9.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/phone-Bv5op1u-.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/admin/enquiries": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.enquiries.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.enquiries-gTQRexDo.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/useMutation-mwU4pNE1.js",
			"/assets/phone-Bv5op1u-.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/admin/offers": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.offers.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.offers-CXWUr073.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/useMutation-mwU4pNE1.js",
			"/assets/switch-mDMw8PkT.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/textarea-Bad6Mw2d.js"
		]
	},
	"/admin/products": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.products.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.products-EujClL_I.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/useMutation-mwU4pNE1.js",
			"/assets/image-manager-DFxZ-g0T.js",
			"/assets/switch-mDMw8PkT.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/textarea-Bad6Mw2d.js",
			"/assets/availability-badge-9fat098s.js"
		]
	},
	"/admin/vehicles": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.vehicles.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.vehicles-hE8C-Tkm.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/useMutation-mwU4pNE1.js",
			"/assets/image-manager-DFxZ-g0T.js",
			"/assets/switch-mDMw8PkT.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/textarea-Bad6Mw2d.js",
			"/assets/availability-badge-9fat098s.js"
		]
	},
	"/products/$id": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products._id-DbSpFA46.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/arrow-left-Cwsy3jPH.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/phone-Bv5op1u-.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/availability-badge-9fat098s.js"
		]
	},
	"/products/accessories": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.accessories.tsx",
		children: void 0,
		preloads: ["/assets/products.accessories-xFk0M1Hr.js", "/assets/product-listing-page-BhuuQ8Lk.js"]
	},
	"/products/lubes": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.lubes.tsx",
		children: void 0,
		preloads: ["/assets/products.lubes-5X_EHGlt.js", "/assets/product-listing-page-BhuuQ8Lk.js"]
	},
	"/resources/video-gallery": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/resources.video-gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/resources.video-gallery-B-h7HmFi.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/play-DRa9I8bC.js",
			"/assets/shield-check-C8fO0WMy.js"
		]
	},
	"/vehicles/$slug": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/vehicles.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles._slug-DJAoCeqX.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/arrow-left-Cwsy3jPH.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/enquiry-form-DcCMCrQt.js",
			"/assets/phone-Bv5op1u-.js",
			"/assets/dist-1DjoKzri.js",
			"/assets/dist-BZjgKkGf.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/label-vfCtvWu0.js",
			"/assets/dist-Ci94ycMT.js",
			"/assets/availability-badge-9fat098s.js"
		]
	},
	"/admin/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CI2FVc4f.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/arrow-right-B8TqEU9E.js",
			"/assets/circle-check-CWLJlsxZ.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/vehicles/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/vehicles.index.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles.index-198eVTIT.js",
			"/assets/catalogue-IZcCGyeo.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/mobile-contact-bar-CsfT0dlh.js",
			"/assets/vehicle-card-BfrKgxhL.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
