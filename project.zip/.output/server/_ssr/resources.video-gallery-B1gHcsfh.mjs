import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { a as Sparkles, n as Wrench, o as ShieldCheck, u as Play } from "../_libs/lucide-react.mjs";
import { n as SiteFooter, r as SiteHeader, t as MobileContactBar } from "./mobile-contact-bar-Du0E7NVK.mjs";
import { t as DESCRIPTION } from "./resources.video-gallery-C6DDxbnZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resources.video-gallery-B1gHcsfh.js
var import_jsx_runtime = require_jsx_runtime();
var video_gallery_cover_default = "/assets/video-gallery-cover-COE9Pq-q.jpg";
var VIDEOS = [
	{
		title: "Meet the latest Honda range",
		category: "Product walkthroughs",
		icon: Sparkles,
		description: "A closer look at design, comfort, technology and practical features across the line-up."
	},
	{
		title: "Simple care between services",
		category: "Maintenance guides",
		icon: Wrench,
		description: "Everyday checks and care tips that help keep your two-wheeler ready for the road."
	},
	{
		title: "Ride prepared, ride safe",
		category: "Safety & riding tips",
		icon: ShieldCheck,
		description: "Responsible riding habits, protective equipment and essential road-awareness guidance."
	}
];
function VideoGalleryPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen pb-14 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-border bg-secondary py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Resources"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-5xl font-bold uppercase leading-none sm:text-6xl",
							children: "Video gallery"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-muted-foreground",
							children: DESCRIPTION
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "container-page py-12 sm:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 lg:grid-cols-3",
					children: VIDEOS.map((video, index) => {
						const Icon = video.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "overflow-hidden rounded-xl border border-border bg-card shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative aspect-video overflow-hidden bg-ink",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: video_gallery_cover_default,
										alt: "Motorcyclist riding safely on a scenic road",
										loading: "lazy",
										width: 1400,
										height: 900,
										className: "h-full w-full object-cover opacity-80"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute inset-0 flex items-center justify-center",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex size-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-red",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-1 size-6" })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "absolute left-4 top-4 rounded-md bg-ink/85 px-3 py-1 font-display text-xs font-semibold uppercase text-ink-foreground",
										children: ["Video ", index + 1]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs font-semibold uppercase text-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), video.category]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-display text-2xl font-bold uppercase",
										children: video.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted-foreground",
										children: video.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										className: "mt-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "https://www.honda2wheelersindia.com/video-gallery",
											target: "_blank",
											rel: "noreferrer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), " View official gallery"]
										})
									})
								]
							})]
						}, video.title);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-muted-foreground",
					children: "Demo gallery for development. Showroom videos and thumbnails will replace this reference content."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileContactBar, {})
		]
	});
}
//#endregion
export { VideoGalleryPage as component };
