import { r as SHOWROOM } from "./showroom-qI0FNTtp.mjs";
import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products._id-CocmRs_b.js
var $$splitComponentImporter = () => import("./products._id-DEdh_VxE.mjs");
var Route = createFileRoute("/products/$id")({
	head: () => ({ meta: [{ title: `Product — ${SHOWROOM.name}` }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
