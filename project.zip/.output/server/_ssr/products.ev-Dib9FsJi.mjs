//#region node_modules/.nitro/vite/services/ssr/assets/products.ev-Dib9FsJi.js
var DESCRIPTION = "Explore demo information about Honda electric scooters, everyday range, charging and battery solutions.";
//#endregion
export { DESCRIPTION as t };
