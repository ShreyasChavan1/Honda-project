import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as DESCRIPTION } from "./products.accessories-CZ3i8rd4.mjs";
import { t as ProductListingPage } from "./product-listing-page-B-46-eGv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.accessories-R1Z5SvqP.js
var import_jsx_runtime = require_jsx_runtime();
var accessories_default = "/assets/accessories-ISdcnwFd.jpg";
function AccessoriesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductListingPage, {
		category: "accessories",
		eyebrow: "Personalise your ride",
		title: "Accessories",
		description: DESCRIPTION,
		image: accessories_default,
		imageAlt: "A selection of two-wheeler riding and vehicle accessories",
		note: "Product range, compatibility and prices must be confirmed with the showroom before purchase."
	});
}
//#endregion
export { AccessoriesPage as component };
