import { n as __toESM } from "../_runtime.mjs";
import { a as waLink, n as SHOWROOM } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Bike, C as Film, O as ChevronDown, _ as Mail, d as Phone, g as MapPin, h as Menu, l as PlugZap, m as MessageCircle, p as PackageOpen, t as X, w as Droplets } from "../_libs/lucide-react.mjs";
import { a as List, c as Viewport, i as Link$1, n as Indicator, o as Root2, r as Item, s as Trigger, t as Content } from "../_libs/@radix-ui/react-navigation-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mobile-contact-bar-Du0E7NVK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NavigationMenu = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root2, {
	ref,
	className: cn("relative z-10 flex max-w-max flex-1 items-center justify-center", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuViewport, {})]
}));
NavigationMenu.displayName = Root2.displayName;
var NavigationMenuList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("group flex flex-1 list-none items-center justify-center space-x-1", className),
	...props
}));
NavigationMenuList.displayName = List.displayName;
var NavigationMenuItem = Item;
var navigationMenuTriggerStyle = cva("group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium cursor-pointer transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=open]:text-accent-foreground data-[state=open]:bg-accent/50 data-[state=open]:hover:bg-accent data-[state=open]:focus:bg-accent");
var NavigationMenuTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger, {
	ref,
	className: cn(navigationMenuTriggerStyle(), "group", className),
	...props,
	children: [
		children,
		" ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
			className: "relative top-[1px] ml-1 h-3 w-3 transition duration-300 group-data-[state=open]:rotate-180",
			"aria-hidden": "true"
		})
	]
}));
NavigationMenuTrigger.displayName = Trigger.displayName;
var NavigationMenuContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("left-0 top-0 w-full data-[motion^=from-]:animate-in data-[motion^=to-]:animate-out data-[motion^=from-]:fade-in data-[motion^=to-]:fade-out data-[motion=from-end]:slide-in-from-right-52 data-[motion=from-start]:slide-in-from-left-52 data-[motion=to-end]:slide-out-to-right-52 data-[motion=to-start]:slide-out-to-left-52 md:absolute md:w-auto ", className),
	...props
}));
NavigationMenuContent.displayName = Content.displayName;
var NavigationMenuLink = Link$1;
var NavigationMenuViewport = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("absolute left-0 top-full flex justify-center"),
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
		className: cn("origin-top-center relative mt-1.5 h-[var(--radix-navigation-menu-viewport-height)] w-full overflow-hidden rounded-md border bg-popover text-popover-foreground shadow data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90 md:w-[var(--radix-navigation-menu-viewport-width)]", className),
		ref,
		...props
	})
}));
NavigationMenuViewport.displayName = Viewport.displayName;
var NavigationMenuIndicator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
	ref,
	className: cn("top-full z-[1] flex h-1.5 items-end justify-center overflow-hidden data-[state=visible]:animate-in data-[state=hidden]:animate-out data-[state=hidden]:fade-out data-[state=visible]:fade-in", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "relative top-[60%] h-2 w-2 rotate-45 rounded-tl-sm bg-border shadow-md" })
}));
NavigationMenuIndicator.displayName = Indicator.displayName;
var PRODUCT_LINKS = [
	{
		to: "/vehicles",
		search: { category: "motorcycle" },
		label: "Motorcycles",
		description: "Commuter, performance and premium models",
		icon: Bike
	},
	{
		to: "/vehicles",
		search: { category: "scooter" },
		label: "Scooters",
		description: "Automatic everyday mobility",
		icon: Bike
	},
	{
		to: "/products/ev",
		label: "EV",
		description: "Electric scooters and battery solutions",
		icon: PlugZap
	},
	{
		to: "/products/accessories",
		label: "Accessories",
		description: "Model-wise protection, utility and riding gear",
		icon: PackageOpen
	},
	{
		to: "/products/lubes",
		label: "Genuine Lubes & Chemicals",
		description: "Engine oils and care products",
		icon: Droplets
	}
];
var NAV = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/offers",
		label: "Offers"
	},
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden bg-ink text-ink-foreground md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page flex h-9 items-center justify-between text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "opacity-80",
						children: SHOWROOM.tagline
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${SHOWROOM.phone}`,
								className: "hover:text-primary",
								children: SHOWROOM.phoneDisplay
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "opacity-40",
								children: "|"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "opacity-80",
								children: [SHOWROOM.hours[0].time, " (Mon–Sat)"]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page flex h-16 items-center justify-between gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-3",
						"aria-label": `${SHOWROOM.name} home`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-9 w-9 items-center justify-center rounded-md bg-primary font-display text-lg font-bold text-primary-foreground",
							children: "H"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "leading-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-xl font-bold uppercase tracking-wide",
								children: SHOWROOM.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
								children: "Two-Wheelers"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenu, {
						className: "hidden md:flex",
						"aria-label": "Main navigation",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavigationMenuList, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuLink, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									activeOptions: { exact: true },
									activeProps: { className: "text-primary" },
									className: "rounded-md px-3 py-2 font-display text-[15px] font-semibold uppercase text-foreground/80 transition-colors hover:text-primary",
									children: "Home"
								})
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavigationMenuItem, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuTrigger, {
								className: "font-display text-[15px] font-semibold uppercase text-foreground/80",
								children: "Products"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid w-[620px] grid-cols-2 gap-2 p-4",
								children: PRODUCT_LINKS.map((item) => {
									const Icon = item.icon;
									const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-display text-sm font-bold uppercase",
										children: item.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-xs leading-snug text-muted-foreground",
										children: item.description
									})] })] });
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuLink, {
										asChild: true,
										children: "search" in item ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/vehicles",
											search: item.search,
											className: "group flex gap-3 rounded-md border border-transparent p-3 transition-colors hover:border-border hover:bg-secondary",
											children: content
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: item.to,
											className: "group flex gap-3 rounded-md border border-transparent p-3 transition-colors hover:border-border hover:bg-secondary",
											children: content
										})
									}, item.label);
								})
							}) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavigationMenuItem, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuTrigger, {
								className: "font-display text-[15px] font-semibold uppercase text-foreground/80",
								children: "Resources"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-[310px] p-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuLink, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/resources/video-gallery",
										className: "flex gap-3 rounded-md p-3 transition-colors hover:bg-secondary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex size-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-display text-sm font-bold uppercase",
											children: "Video Gallery"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-xs text-muted-foreground",
											children: "Product films, maintenance and riding tips"
										})] })]
									})
								})
							}) })] }),
							NAV.slice(1).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavigationMenuLink, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: item.to,
									activeProps: { className: "text-primary" },
									className: "rounded-md px-3 py-2 font-display text-[15px] font-semibold uppercase text-foreground/80 transition-colors hover:text-primary",
									children: item.label
								})
							}) }, item.to))
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `tel:${SHOWROOM.phone}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}), " Call Showroom"]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => setOpen((v) => !v),
						variant: "outline",
						size: "icon",
						className: "md:hidden",
						"aria-label": open ? "Close menu" : "Open menu",
						"aria-expanded": open,
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})
				]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "border-t border-border bg-background md:hidden",
				"aria-label": "Mobile navigation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page flex flex-col py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							onClick: () => setOpen(false),
							activeOptions: { exact: true },
							activeProps: { className: "text-primary" },
							className: "border-b border-border/60 py-3.5 font-display text-lg font-semibold uppercase",
							children: "Home"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pt-4 font-display text-xs font-bold uppercase text-muted-foreground",
							children: "Products"
						}),
						PRODUCT_LINKS.map((item) => "search" in item ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vehicles",
							search: item.search,
							onClick: () => setOpen(false),
							activeProps: { className: "text-primary" },
							className: "border-b border-border/60 py-3 font-display text-base font-semibold uppercase",
							children: item.label
						}, item.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							onClick: () => setOpen(false),
							activeProps: { className: "text-primary" },
							className: "border-b border-border/60 py-3 font-display text-base font-semibold uppercase",
							children: item.label
						}, item.label)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pt-4 font-display text-xs font-bold uppercase text-muted-foreground",
							children: "Resources"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/resources/video-gallery",
							onClick: () => setOpen(false),
							activeProps: { className: "text-primary" },
							className: "border-b border-border/60 py-3 font-display text-base font-semibold uppercase",
							children: "Video Gallery"
						}),
						NAV.slice(1).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							onClick: () => setOpen(false),
							activeProps: { className: "text-primary" },
							className: "border-b border-border/60 py-3.5 font-display text-lg font-semibold uppercase last:border-0",
							children: item.label
						}, item.to))
					]
				})
			})
		]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-20 bg-ink text-ink-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-page grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-bold uppercase tracking-wide",
						children: SHOWROOM.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xs text-sm opacity-75",
						children: SHOWROOM.shortDescription
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs uppercase tracking-[0.16em] text-primary",
						children: "Demo content"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-sm font-bold uppercase tracking-[0.16em] opacity-60",
					children: "Browse"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vehicles",
							className: "opacity-85 hover:text-primary",
							children: "All Products"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vehicles",
							search: { category: "scooter" },
							className: "opacity-85 hover:text-primary",
							children: "Scooters"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vehicles",
							search: { category: "motorcycle" },
							className: "opacity-85 hover:text-primary",
							children: "Motorcycles"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/products/ev",
							className: "opacity-85 hover:text-primary",
							children: "EV"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/products/accessories",
							className: "opacity-85 hover:text-primary",
							children: "Accessories"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/products/lubes",
							className: "opacity-85 hover:text-primary",
							children: "Lubes & Chemicals"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/offers",
							className: "opacity-85 hover:text-primary",
							children: "Current Offers"
						}) })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-sm font-bold uppercase tracking-[0.16em] opacity-60",
						children: "Showroom"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								className: "opacity-85 hover:text-primary",
								children: "About Us"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								className: "opacity-85 hover:text-primary",
								children: "Contact & Enquiry"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/resources/video-gallery",
								className: "opacity-85 hover:text-primary",
								children: "Video Gallery"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/admin",
								className: "opacity-60 hover:text-primary",
								children: "Staff Login"
							}) })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 space-y-1 text-sm opacity-75",
						children: SHOWROOM.hours.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							h.days,
							": ",
							h.time
						] }, h.days))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-sm font-bold uppercase tracking-[0.16em] opacity-60",
					children: "Reach Us"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("address", {
								className: "not-italic opacity-85",
								children: SHOWROOM.addressLines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block",
									children: line
								}, line))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${SHOWROOM.phone}`,
								className: "opacity-85 hover:text-primary",
								children: SHOWROOM.phoneDisplay
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: waLink("Hello, I would like to know more about Honda two-wheelers."),
								target: "_blank",
								rel: "noreferrer",
								className: "opacity-85 hover:text-primary",
								children: "WhatsApp us"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${SHOWROOM.email}`,
								className: "opacity-85 hover:text-primary",
								children: SHOWROOM.email
							})]
						})
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-white/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page flex flex-col gap-2 py-5 text-xs opacity-60 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ",
					SHOWROOM.name,
					". Independent authorised dealership (demo site)."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "All vehicles, prices and offers shown are demo data." })]
			})
		})]
	});
}
/** Sticky call / WhatsApp actions — mobile only. */
function MobileContactBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-x-0 bottom-0 z-50 grid grid-cols-2 border-t border-border bg-background/95 backdrop-blur md:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: `tel:${SHOWROOM.phone}`,
			className: "flex min-h-14 items-center justify-center gap-2 font-display text-base font-semibold uppercase tracking-wide text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 text-primary" }), " Call"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: waLink(`Hello ${SHOWROOM.name}, I have an enquiry about a Honda two-wheeler.`),
			target: "_blank",
			rel: "noreferrer",
			className: "flex min-h-14 items-center justify-center gap-2 bg-primary font-display text-base font-semibold uppercase tracking-wide text-primary-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), " WhatsApp"]
		})]
	});
}
//#endregion
export { SiteFooter as n, SiteHeader as r, MobileContactBar as t };
