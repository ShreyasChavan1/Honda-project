//#region node_modules/.nitro/vite/services/ssr/assets/resources.video-gallery-C6DDxbnZ.js
var DESCRIPTION = "Browse demo Honda product films, maintenance guides, riding tips and road-safety videos.";
//#endregion
export { DESCRIPTION as t };
