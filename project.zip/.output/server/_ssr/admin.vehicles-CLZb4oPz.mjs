import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.vehicles-CLZb4oPz.js
var $$splitComponentImporter = () => import("./admin.vehicles-D9w_WW1O.mjs");
var Route = createFileRoute("/admin/vehicles")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var parseSpecs = (value) => {
	const specs = {};
	for (const line of value.split("\n")) {
		const index = line.indexOf(":");
		if (index === -1) continue;
		const key = line.slice(0, index).trim();
		const val = line.slice(index + 1).trim();
		if (key) specs[key] = val;
	}
	return specs;
};
//#endregion
export { parseSpecs as n, Route as t };
