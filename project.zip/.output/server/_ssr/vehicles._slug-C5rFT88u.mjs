import { r as SHOWROOM } from "./showroom-qI0FNTtp.mjs";
import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._slug-C5rFT88u.js
var $$splitComponentImporter = () => import("./vehicles._slug-D01y-ESo.mjs");
var Route = createFileRoute("/vehicles/$slug")({
	head: ({ params }) => {
		const model = params.slug.split("-").map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
		const title = `Honda ${model} — Price, Variants & Availability | ${SHOWROOM.name}`;
		const description = `Honda ${model} details at ${SHOWROOM.name}: starting price, variants, colours, key specifications and current showroom availability.`;
		return { meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: description
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
