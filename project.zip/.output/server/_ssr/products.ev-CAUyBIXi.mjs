import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as ProductCategoryPage } from "./product-category-page-vzCWckyV.mjs";
import { t as DESCRIPTION } from "./products.ev-Dib9FsJi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.ev-CAUyBIXi.js
var import_jsx_runtime = require_jsx_runtime();
var ev_showroom_default = "/assets/ev-showroom-BOkTnJcS.jpg";
function EvPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCategoryPage, {
		eyebrow: "Electric mobility",
		title: "Honda EV",
		description: DESCRIPTION,
		image: ev_showroom_default,
		imageAlt: "Red electric scooter displayed in a modern showroom",
		features: [
			{
				title: "Electric scooters",
				description: "Discover city-focused electric mobility designed for smooth, quiet and practical everyday travel."
			},
			{
				title: "Battery solutions",
				description: "Learn about fixed-battery and battery-swapping approaches available across the Honda EV ecosystem."
			},
			{
				title: "Connected riding",
				description: "Explore intelligent displays, charging information and connected features offered on selected models."
			}
		],
		note: "Demo content for development. Models, specifications, prices, range and local availability will be replaced with verified showroom information."
	});
}
//#endregion
export { EvPage as component };
