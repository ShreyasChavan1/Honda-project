import { n as __toESM } from "../_runtime.mjs";
import { a as categoryLabel, o as formatPrice, t as CATEGORIES } from "./showroom-qI0FNTtp.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { H as ArrowDown, S as Layers, a as Trash2, m as Pencil, u as Plus, z as ArrowUp } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-DsxaCInS.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { l as vehiclesQuery, s as variantsQuery } from "./catalogue-3zYAaxMW.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { t as Switch } from "./switch-CCza_WcE.mjs";
import { t as AvailabilityBadge } from "./availability-badge-BdM1dhm1.mjs";
import { t as ImageManager } from "./image-manager-D5F3lsVZ.mjs";
import { n as parseSpecs } from "./admin.vehicles-C6BWAq3w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.vehicles-B3nevR2V.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY = {
	slug: "",
	name: "",
	category: "scooter",
	short_description: "",
	description: "",
	price_from: "",
	images: [],
	is_available: true,
	is_featured: false,
	sort_order: "0",
	video_url: "",
	info_context: "",
	brochure_url: ""
};
var toDraft = (vehicle) => ({
	id: vehicle.id,
	slug: vehicle.slug,
	name: vehicle.name,
	category: vehicle.category,
	short_description: vehicle.short_description,
	description: vehicle.description,
	price_from: vehicle.price_from == null ? "" : String(vehicle.price_from),
	images: [vehicle.image_url, ...vehicle.gallery].filter(Boolean),
	is_available: vehicle.is_available,
	is_featured: vehicle.is_featured,
	sort_order: String(vehicle.sort_order),
	video_url: vehicle.video_url ?? "",
	info_context: vehicle.info_context ?? "",
	brochure_url: vehicle.brochure_url ?? ""
});
var specsToText = (specs) => Object.entries(specs).map(([key, value]) => `${key}: ${value}`).join("\n");
var slugify = (value) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
function AdminVehicles() {
	const { data, isLoading, isError } = useQuery(vehiclesQuery);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [openVariants, setOpenVariants] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const queryClient = useQueryClient();
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["vehicles"] });
		queryClient.invalidateQueries({ queryKey: ["vehicle"] });
	};
	const save = useMutation({
		mutationFn: async (values) => {
			const payload = {
				slug: values.slug || slugify(values.name),
				name: values.name,
				category: values.category,
				short_description: values.short_description,
				description: values.description,
				price_from: values.price_from ? Number(values.price_from) : null,
				image_url: values.images[0] ?? "",
				gallery: values.images.slice(1),
				is_available: values.is_available,
				is_featured: values.is_featured,
				sort_order: Number(values.sort_order) || 0,
				video_url: values.video_url.trim() || null,
				info_context: values.info_context,
				brochure_url: values.brochure_url.trim() || null
			};
			const { error: saveError, data: saveData } = await (values.id ? supabase.from("vehicles").update(payload).eq("id", values.id).select("id") : supabase.from("vehicles").insert(payload).select("id"));
			if (saveError) throw new Error(saveError.message);
			if (values.id && (!saveData || saveData.length === 0)) throw new Error("Nothing was saved — you may have lost admin access. Please refresh and sign in again.");
		},
		onSuccess: () => {
			setDraft(null);
			setError(null);
			invalidate();
		},
		onError: (e) => setError(e.message)
	});
	const toggleAvailability = useMutation({
		mutationFn: async (vehicle) => {
			const { error: e, data } = await supabase.from("vehicles").update({ is_available: !vehicle.is_available }).eq("id", vehicle.id).select("id");
			if (e) throw new Error(e.message);
			if (!data || data.length === 0) throw new Error("Nothing was updated — you may have lost admin access. Please refresh and sign in again.");
		},
		onSuccess: invalidate
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error: e } = await supabase.from("vehicles").delete().eq("id", id);
			if (e) throw new Error(e.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-bold uppercase tracking-tight",
					children: "Vehicles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Add models, then manage their variants, colours and gallery images."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setDraft({ ...EMPTY }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add vehicle"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" }),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-muted-foreground",
				children: "Could not load vehicles. Please refresh the page."
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleForm, {
				draft,
				onChange: setDraft,
				onCancel: () => {
					setDraft(null);
					setError(null);
				},
				onSave: () => save.mutate(draft),
				saving: save.isPending,
				error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: (data ?? []).map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: vehicle.image_url,
								alt: vehicle.name,
								loading: "lazy",
								className: "h-20 w-28 rounded-lg object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-40 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl font-bold uppercase tracking-wide",
										children: vehicle.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground",
										children: [
											categoryLabel(vehicle.category),
											" · ",
											formatPrice(vehicle.price_from),
											vehicle.is_featured ? " · Featured" : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityBadge, { available: vehicle.is_available })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 pr-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											id: `available-${vehicle.id}`,
											checked: vehicle.is_available,
											onCheckedChange: () => toggleAvailability.mutate(vehicle)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: `available-${vehicle.id}`,
											className: "text-xs",
											children: "In stock"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: openVariants === vehicle.id ? "default" : "outline",
										onClick: () => setOpenVariants(openVariants === vehicle.id ? null : vehicle.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {}), " Variants"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setDraft(toDraft(vehicle)),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Edit"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (window.confirm(`Delete ${vehicle.name}? This cannot be undone.`)) remove.mutate(vehicle.id);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
									})
								]
							})
						]
					}), openVariants === vehicle.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantsPanel, { vehicle })]
				}, vehicle.id))
			}),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-card p-8 text-sm text-muted-foreground",
				children: "No vehicles yet. Use “Add vehicle” to list your first model."
			})
		]
	});
}
function VehicleForm({ draft, onChange, onCancel, onSave, saving, error }) {
	const set = (key, value) => onChange({
		...draft,
		[key]: value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			onSave();
		},
		className: "space-y-4 rounded-xl border border-primary/40 bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-bold uppercase tracking-wide",
				children: draft.id ? `Edit ${draft.name}` : "Add a vehicle"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "name",
							children: "Model name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "name",
							required: true,
							value: draft.name,
							onChange: (e) => set("name", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "slug",
							children: "Web address (slug)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "slug",
							value: draft.slug,
							placeholder: slugify(draft.name) || "activa-6g",
							onChange: (e) => set("slug", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "category",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "category",
							value: draft.category,
							onChange: (e) => set("category", e.target.value),
							className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
							children: CATEGORIES.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: category.value,
								children: category.label
							}, category.value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "price",
							children: "Starting price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "price",
							inputMode: "numeric",
							value: draft.price_from,
							onChange: (e) => set("price_from", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
							label: "Main vehicle images",
							hint: "The first image is used on cards and as the default gallery image.",
							images: draft.images,
							onChange: (images) => set("images", images)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "short",
							children: "Short description (shown on cards)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "short",
							value: draft.short_description,
							onChange: (e) => set("short_description", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "description",
							children: "Full description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "description",
							rows: 3,
							value: draft.description,
							onChange: (e) => set("description", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "video_url",
								children: "Video gallery link (YouTube/Vimeo URL)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "video_url",
								type: "url",
								placeholder: "https://www.youtube.com/watch?v=...",
								value: draft.video_url,
								onChange: (e) => set("video_url", e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Shown as a video on the model page and as a play icon on its card. Leave blank to hide."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "brochure",
								children: "Vehicle brochure URL"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Enter the direct URL of the PDF brochure. Visitors can download it from the vehicle page."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "brochure",
								type: "url",
								placeholder: "https://example.com/brochure.pdf",
								value: draft.brochure_url,
								onChange: (e) => set("brochure_url", e.target.value)
							}),
							draft.brochure_url && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: draft.brochure_url,
									target: "_blank",
									rel: "noreferrer",
									className: "min-w-0 flex-1 truncate text-sm font-medium text-primary hover:underline",
									children: "View current brochure"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									onClick: () => set("brochure_url", ""),
									children: "Remove"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "info_context",
							children: "Info / context (shown on card)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "info_context",
							rows: 2,
							placeholder: "e.g. Limited stock, launch offer, or any extra context to highlight on the card",
							value: draft.info_context,
							onChange: (e) => set("info_context", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "sort",
							children: "Display order"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "sort",
							inputMode: "numeric",
							value: draft.sort_order,
							onChange: (e) => set("sort_order", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								id: "available",
								checked: draft.is_available,
								onCheckedChange: (checked) => set("is_available", checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "available",
								children: "Available at showroom"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								id: "featured",
								checked: draft.is_featured,
								onCheckedChange: (checked) => set("is_featured", checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "featured",
								children: "Featured on home"
							})]
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: saving,
					children: saving ? "Saving…" : "Save vehicle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: onCancel,
					children: "Cancel"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Variants, variant prices, specifications and colour galleries are managed with the “Variants” button on the model below."
			})
		]
	});
}
function VariantsPanel({ vehicle }) {
	const queryClient = useQueryClient();
	const { data, isLoading } = useQuery(variantsQuery(vehicle.id));
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["variants", vehicle.id] });
		queryClient.invalidateQueries({ queryKey: ["vehicle"] });
	};
	const addVariant = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("vehicle_variants").insert({
				vehicle_id: vehicle.id,
				name: "New variant",
				price: vehicle.price_from,
				specs: {},
				is_available: true,
				sort_order: data?.length ?? 0
			});
			if (error) throw new Error(error.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-4 rounded-lg border border-border bg-secondary/40 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground",
					children: ["Variants of ", vehicle.name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => addVariant.mutate(),
					disabled: addVariant.isPending,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add variant"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full rounded-lg" }),
			(data ?? []).map((variant) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantCard, {
				variant,
				onChanged: invalidate
			}, variant.id)),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No variants yet. Add one to set variant prices, specifications and colours."
			})
		]
	});
}
function VariantCard({ variant, onChanged }) {
	const [name, setName] = (0, import_react.useState)(variant.name);
	const [price, setPrice] = (0, import_react.useState)(variant.ex_showroom_price == null ? "" : String(variant.ex_showroom_price));
	const [onRoad, setOnRoad] = (0, import_react.useState)(variant.on_road_price == null ? "" : String(variant.on_road_price));
	const [emi, setEmi] = (0, import_react.useState)(variant.emi_options.map((option) => ({
		months: String(option.months),
		rate: String(option.rate)
	})));
	const [specs, setSpecs] = (0, import_react.useState)(specsToText(variant.specs));
	const [available, setAvailable] = (0, import_react.useState)(variant.is_available);
	const [error, setError] = (0, import_react.useState)(null);
	const setEmiField = (index, key, value) => setEmi(emi.map((row, i) => i === index ? {
		...row,
		[key]: value
	} : row));
	const moveEmi = (index, direction) => {
		const target = index + direction;
		if (target < 0 || target >= emi.length) return;
		const next = [...emi];
		const [row] = next.splice(index, 1);
		next.splice(target, 0, row);
		setEmi(next);
	};
	const save = useMutation({
		mutationFn: async () => {
			const emiOptions = emi.map((row) => ({
				months: Number(row.months) || 0,
				rate: Number(row.rate) || 0
			})).filter((row) => row.months > 0);
			const exShowroom = price ? Number(price) : null;
			const { error: e, data } = await supabase.from("vehicle_variants").update({
				name,
				price: exShowroom,
				ex_showroom_price: exShowroom,
				on_road_price: onRoad ? Number(onRoad) : null,
				emi_options: emiOptions,
				specs: parseSpecs(specs),
				is_available: available
			}).eq("id", variant.id).select("id");
			if (e) throw new Error(e.message);
			if (!data || data.length === 0) throw new Error("Nothing was saved — you may have lost admin access. Please refresh and sign in again.");
		},
		onSuccess: () => {
			setError(null);
			onChanged();
		},
		onError: (e) => setError(e.message)
	});
	const remove = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("vehicle_variants").delete().eq("id", variant.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	const addColour = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("variant_colours").insert({
				variant_id: variant.id,
				name: "New colour",
				images: [],
				sort_order: variant.colours.length
			});
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vname-${variant.id}`,
							children: "Variant name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vname-${variant.id}`,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Standard, Deluxe, DLX…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vprice-${variant.id}`,
							children: "Ex-showroom price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vprice-${variant.id}`,
							inputMode: "numeric",
							value: price,
							onChange: (e) => setPrice(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vonroad-${variant.id}`,
							children: "On-road price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vonroad-${variant.id}`,
							inputMode: "numeric",
							value: onRoad,
							onChange: (e) => setOnRoad(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 sm:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "EMI settings — loan tenures and interest rates" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									variant: "outline",
									onClick: () => setEmi([...emi, {
										months: "12",
										rate: "9.5"
									}]),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add tenure"]
								})]
							}),
							emi.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28 space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Months"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "numeric",
											value: row.months,
											onChange: (e) => setEmiField(index, "months", e.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28 space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Interest %"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "decimal",
											value: row.rate,
											onChange: (e) => setEmiField(index, "rate", e.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Move up",
										onClick: () => moveEmi(index, -1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Move down",
										onClick: () => moveEmi(index, 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Remove tenure",
										onClick: () => setEmi(emi.filter((_, i) => i !== index)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								]
							}, index)),
							emi.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No tenure options yet. Add one, e.g. 12 months at 9.5%."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Visitors pick a tenure on the model page; the interest rate you set here is applied automatically and cannot be changed by them."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vspecs-${variant.id}`,
							children: "Specifications (one per line, e.g. Engine: 110 cc)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: `vspecs-${variant.id}`,
							rows: 5,
							value: specs,
							onChange: (e) => setSpecs(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: `vavail-${variant.id}`,
							checked: available,
							onCheckedChange: setAvailable
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vavail-${variant.id}`,
							children: "Available at showroom"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => save.mutate(),
						disabled: save.isPending,
						children: save.isPending ? "Saving…" : "Save variant"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => addColour.mutate(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add colour"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							if (window.confirm(`Delete variant “${variant.name}” and its colours?`)) remove.mutate();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete variant"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground",
						children: "Colours"
					}),
					variant.colours.map((colour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColourCard, {
						colour,
						onChanged
					}, colour.id)),
					variant.colours.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No colours yet for this variant. Use “Add colour”."
					})
				]
			})
		]
	});
}
function ColourCard({ colour, onChanged }) {
	const [name, setName] = (0, import_react.useState)(colour.name);
	const [images, setImages] = (0, import_react.useState)(colour.images);
	const save = useMutation({
		mutationFn: async (next) => {
			const { error: e, data } = await supabase.from("variant_colours").update({
				name,
				images: next ?? images
			}).eq("id", colour.id).select("id");
			if (e) throw new Error(e.message);
			if (!data || data.length === 0) throw new Error("Nothing was saved — you may have lost admin access. Please refresh and sign in again.");
		},
		onSuccess: onChanged
	});
	const remove = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("variant_colours").delete().eq("id", colour.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-lg border border-border bg-background p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-48 flex-1 space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: `cname-${colour.id}`,
						children: "Colour name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: `cname-${colour.id}`,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Pearl White"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => save.mutate(void 0),
					disabled: save.isPending,
					children: save.isPending ? "Saving…" : "Save colour"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => {
						if (window.confirm(`Delete colour “${colour.name}”?`)) remove.mutate();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
			label: "Gallery images for this colour",
			hint: "Shown when a visitor selects this variant and colour.",
			images,
			folder: "variants",
			onChange: (next) => {
				setImages(next);
				save.mutate(next);
			}
		})]
	});
}
//#endregion
export { AdminVehicles as component };
