import { a as waLink, n as SHOWROOM } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { T as Clock, _ as Mail, d as Phone, g as MapPin, m as MessageCircle } from "../_libs/lucide-react.mjs";
import { n as SiteFooter, r as SiteHeader, t as MobileContactBar } from "./mobile-contact-bar-Du0E7NVK.mjs";
import { t as EnquiryForm } from "./enquiry-form-DQIFAR0K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-0DpSgQ85.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen pb-14 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-b border-border bg-secondary py-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-page",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Contact us"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-2 font-display text-4xl font-bold uppercase leading-tight tracking-tight sm:text-5xl",
								children: "Talk to our showroom team"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-2xl text-muted-foreground",
								children: "Call, message or send an enquiry — we reply during showroom hours. Contact details below are demo data."
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "container-page grid gap-10 py-12 lg:grid-cols-[1fr_1.1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactTile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" }),
								label: "Phone",
								value: SHOWROOM.phoneDisplay,
								href: `tel:${SHOWROOM.phone}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactTile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" }),
								label: "WhatsApp",
								value: "Chat with us instantly",
								href: waLink(`Hello ${SHOWROOM.name}, I have an enquiry.`),
								external: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactTile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" }),
								label: "Email",
								value: SHOWROOM.email,
								href: `mailto:${SHOWROOM.email}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border bg-card p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-lg font-bold uppercase tracking-wide",
										children: "Address"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("address", {
									className: "mt-3 not-italic text-sm text-muted-foreground",
									children: SHOWROOM.addressLines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block",
										children: line
									}, line))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border bg-card p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-lg font-bold uppercase tracking-wide",
										children: "Business hours"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-3 space-y-1.5 text-sm",
									children: SHOWROOM.hours.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted-foreground",
											children: h.days
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-semibold",
											children: h.time
										})]
									}, h.days))
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-card sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-bold uppercase tracking-wide",
								children: "Send an enquiry"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Tell us which model you are interested in and we will get back to you."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryForm, {})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "container-page pb-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-bold uppercase tracking-wide",
						children: "Find the showroom"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 overflow-hidden rounded-2xl border border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							title: `Map showing ${SHOWROOM.name} location`,
							src: `https://www.google.com/maps?q=${encodeURIComponent(SHOWROOM.mapEmbedQuery)}&output=embed`,
							loading: "lazy",
							referrerPolicy: "no-referrer-when-downgrade",
							className: "h-80 w-full border-0 sm:h-[26rem]"
						})
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileContactBar, {})
		]
	});
}
function ContactTile({ icon, label, value, href, external }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		...external ? {
			target: "_blank",
			rel: "noreferrer"
		} : {},
		className: "flex items-center gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block font-display text-lg font-bold uppercase tracking-wide",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm text-muted-foreground",
			children: value
		})] })]
	});
}
//#endregion
export { ContactPage as component };
