import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { D as CircleAlert, E as CircleCheck, s as Send } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-4t218RNL.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { s as vehiclesQuery } from "./catalogue-CvvAtD1R.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { i as unionType, n as objectType, r as stringType, t as literalType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enquiry-form-DQIFAR0K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var schema = objectType({
	name: stringType().trim().min(2, "Please enter your name").max(100),
	phone: stringType().trim().min(7, "Please enter a valid phone number").max(20, "Phone number is too long").regex(/^[0-9+\-\s()]+$/, "Phone number can only contain digits and + - ( )"),
	email: unionType([stringType().trim().email("Enter a valid email").max(255), literalType("")]),
	vehicle_interest: stringType().trim().max(120),
	message: stringType().trim().max(1e3)
});
var EMPTY = {
	name: "",
	phone: "",
	email: "",
	vehicle_interest: "",
	message: ""
};
function EnquiryForm({ defaultVehicle }) {
	const [fields, setFields] = (0, import_react.useState)({
		...EMPTY,
		vehicle_interest: defaultVehicle ?? ""
	});
	const [errors, setErrors] = (0, import_react.useState)({});
	const { data: vehicles } = useQuery(vehiclesQuery);
	const mutation = useMutation({
		mutationFn: async (values) => {
			const { error } = await supabase.from("enquiries").insert({
				name: values.name,
				phone: values.phone,
				email: values.email || null,
				vehicle_interest: values.vehicle_interest || null,
				message: values.message
			});
			if (error) throw new Error(error.message);
		},
		onSuccess: () => setFields({
			...EMPTY,
			vehicle_interest: defaultVehicle ?? ""
		})
	});
	const set = (key) => (value) => {
		setFields((prev) => ({
			...prev,
			[key]: value
		}));
		setErrors((prev) => ({
			...prev,
			[key]: void 0
		}));
	};
	const onSubmit = (event) => {
		event.preventDefault();
		const parsed = schema.safeParse(fields);
		if (!parsed.success) {
			const next = {};
			for (const issue of parsed.error.issues) next[issue.path[0]] = issue.message;
			setErrors(next);
			return;
		}
		mutation.mutate(parsed.data);
	};
	if (mutation.isSuccess) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-success/30 bg-success/8 p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-10 text-success" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-2xl font-bold uppercase tracking-wide",
				children: "Enquiry sent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Thank you. Our team will get back to you shortly during showroom hours."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-6",
				onClick: () => mutation.reset(),
				children: "Send another enquiry"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "name",
					label: "Your name",
					error: errors.name,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						value: fields.name,
						onChange: (e) => set("name")(e.target.value),
						placeholder: "Rahul Sharma",
						autoComplete: "name",
						className: "h-12"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "phone",
					label: "Phone number",
					error: errors.phone,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "phone",
						value: fields.phone,
						onChange: (e) => set("phone")(e.target.value),
						placeholder: "+91 98765 43210",
						inputMode: "tel",
						autoComplete: "tel",
						className: "h-12"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "email",
					label: "Email (optional)",
					error: errors.email,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						value: fields.email,
						onChange: (e) => set("email")(e.target.value),
						placeholder: "you@example.com",
						inputMode: "email",
						autoComplete: "email",
						className: "h-12"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "vehicle_interest",
					label: "Interested vehicle",
					error: errors.vehicle_interest,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "vehicle_interest",
						value: fields.vehicle_interest,
						onChange: (e) => set("vehicle_interest")(e.target.value),
						className: "h-12 w-full rounded-md border border-input bg-background px-3 text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Not decided yet"
						}), (vehicles ?? []).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: v.name,
							children: v.name
						}, v.id))]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "message",
				label: "Message",
				error: errors.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "message",
					value: fields.message,
					onChange: (e) => set("message")(e.target.value),
					rows: 4,
					placeholder: "Tell us what you would like to know — price, availability, test ride, finance…"
				})
			}),
			mutation.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), "We could not send your enquiry. Please try again or call the showroom."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				size: "lg",
				className: "w-full",
				disabled: mutation.isPending,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}),
					" ",
					mutation.isPending ? "Sending…" : "Send Enquiry"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "We use your details only to respond to this enquiry. No account is created."
			})
		]
	});
}
function Field({ id, label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: id,
				children: label
			}),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
//#endregion
export { EnquiryForm as t };
