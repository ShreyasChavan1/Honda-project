import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Inbox, I as ArrowRight, N as Bike, P as BadgePercent, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { i as offersQuery, r as enquiriesQuery, s as vehiclesQuery } from "./catalogue-DhpYB_2x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-CjBCOwqf.js
var import_jsx_runtime = require_jsx_runtime();
function AdminDashboard() {
	const vehicles = useQuery(vehiclesQuery);
	const offers = useQuery(offersQuery);
	const enquiries = useQuery(enquiriesQuery);
	const stats = [
		{
			label: "Vehicles listed",
			value: vehicles.data?.length,
			icon: Bike
		},
		{
			label: "Available now",
			value: vehicles.data?.filter((v) => v.is_available).length,
			icon: CircleCheck
		},
		{
			label: "Active offers",
			value: offers.data?.filter((o) => o.is_active).length,
			icon: BadgePercent
		},
		{
			label: "Enquiries received",
			value: enquiries.data?.length,
			icon: Inbox
		}
	];
	const recent = (enquiries.data ?? []).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl font-bold uppercase tracking-tight",
				children: "Dashboard"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Everything you change here updates the public website immediately."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(stat.icon, { className: "size-5 text-primary" }),
						stat.value === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-3 h-9 w-16" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-4xl font-bold",
							children: stat.value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs uppercase tracking-[0.12em] text-muted-foreground",
							children: stat.label
						})
					]
				}, stat.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/admin/vehicles",
						label: "Manage vehicles",
						description: "Add models, update prices and availability."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/admin/offers",
						label: "Manage offers",
						description: "Create, edit or deactivate promotions."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/admin/enquiries",
						label: "View enquiries",
						description: "See what customers have asked for."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 border-b border-border p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-bold uppercase tracking-wide",
							children: "Latest enquiries"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/admin/enquiries",
								children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						})]
					}),
					enquiries.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full" })
					}),
					!enquiries.isLoading && recent.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-5 text-sm text-muted-foreground",
						children: "No enquiries yet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: recent.map((enquiry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center justify-between gap-3 p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: enquiry.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [enquiry.phone, enquiry.vehicle_interest ? ` · ${enquiry.vehicle_interest}` : ""]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: new Date(enquiry.created_at).toLocaleString("en-IN")
							})]
						}, enquiry.id))
					})
				]
			})
		]
	});
}
function QuickLink({ to, label, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl font-bold uppercase tracking-wide",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary",
				children: ["Open ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
			})
		]
	});
}
//#endregion
export { AdminDashboard as component };
