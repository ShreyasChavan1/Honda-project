import { t as CATEGORIES } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteFooter, r as SiteHeader, t as MobileContactBar } from "./mobile-contact-bar-Du0E7NVK.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { s as vehiclesQuery } from "./catalogue-DhpYB_2x.mjs";
import { t as Route } from "./vehicles.index-CUo6yFPh.mjs";
import { t as VehicleCard } from "./vehicle-card-CIT_BFlq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles.index-BeC1DHmh.js
var import_jsx_runtime = require_jsx_runtime();
function VehiclesPage() {
	const { category } = Route.useSearch();
	const navigate = useNavigate({ from: "/vehicles/" });
	const { data, isLoading, isError } = useQuery(vehiclesQuery);
	const vehicles = (data ?? []).filter((v) => !category || v.category === category);
	const setCategory = (value) => navigate({ search: value ? { category: value } : {} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen pb-14 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-border bg-secondary py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Our catalogue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-4xl font-bold uppercase leading-tight tracking-tight sm:text-5xl",
							children: "Honda vehicles at our showroom"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-2xl text-muted-foreground",
							children: "Demo catalogue for development. Availability shown here is maintained manually by our showroom team — call us to confirm before you visit."
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "container-page py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						role: "group",
						"aria-label": "Filter by category",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: !category,
							onClick: () => setCategory(void 0),
							children: "All Vehicles"
						}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: category === c.value,
							onClick: () => setCategory(c.value),
							children: c.label
						}, c.value))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-muted-foreground",
						children: isLoading ? "Loading models…" : `${vehicles.length} model${vehicles.length === 1 ? "" : "s"} listed`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
						children: [isLoading && Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-[26rem] rounded-xl" }, i)), vehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCard, { vehicle }, vehicle.id))]
					}),
					isError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-destructive/30 bg-destructive/5 p-8 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-bold uppercase",
							children: "Could not load the catalogue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Please refresh the page or call the showroom for model details."
						})]
					}),
					!isLoading && !isError && vehicles.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-card p-10 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl font-bold uppercase",
								children: "No vehicles in this category"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Try another category or view the full catalogue."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-6",
								onClick: () => setCategory(void 0),
								children: "View all vehicles"
							})
						]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileContactBar, {})
		]
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: "min-h-11 rounded-full border px-5 font-display text-sm font-semibold uppercase tracking-wide transition-colors " + (active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:border-primary hover:text-primary"),
		children
	});
}
//#endregion
export { VehiclesPage as component };
