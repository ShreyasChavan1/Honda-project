import { n as SHOWROOM, t as CATEGORIES } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as ArrowRight, P as BadgePercent, c as ShieldCheck, n as Wrench, o as Star, p as Phone, v as MapPin } from "../_libs/lucide-react.mjs";
import { n as SiteFooter, r as SiteHeader, t as MobileContactBar } from "./mobile-contact-bar-Du0E7NVK.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { i as offersQuery, s as vehiclesQuery } from "./catalogue-DhpYB_2x.mjs";
import { t as VehicleCard } from "./vehicle-card-CIT_BFlq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BLrJj8Po.js
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	const vehicles = useQuery(vehiclesQuery);
	const offers = useQuery(offersQuery);
	const featured = (vehicles.data ?? []).filter((v) => v.is_featured).slice(0, 4);
	const activeOffers = (offers.data ?? []).filter((o) => o.is_active).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen pb-14 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative isolate overflow-hidden bg-ink text-ink-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/images/demo/hero-showroom.jpg",
							alt: "Red Honda scooter on display inside the showroom",
							width: 1920,
							height: 1088,
							className: "absolute inset-0 h-full w-full object-cover object-right opacity-70"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/20" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "container-page relative flex min-h-[78vh] flex-col justify-center py-20",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: SHOWROOM.tagline
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-4 max-w-2xl font-display text-5xl font-bold uppercase leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl",
									children: "Find your perfect Honda two-wheeler"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-xl text-base opacity-85 sm:text-lg",
									children: SHOWROOM.shortDescription
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-9 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/vehicles",
											children: ["Explore Vehicles ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										variant: "outline",
										className: "border-white/40 bg-transparent text-ink-foreground hover:bg-white/10 hover:text-ink-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/contact",
											children: "Contact Us"
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-14 grid max-w-2xl grid-cols-2 gap-6 border-t border-white/15 pt-8 sm:grid-cols-4",
									children: SHOWROOM.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "sr-only",
										children: stat.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-display text-3xl font-bold",
										children: stat.value
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-xs uppercase tracking-[0.12em] opacity-70",
										children: stat.label
									})] })] }, stat.label))
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "container-page py-16 sm:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						eyebrow: "Featured line-up",
						title: "Popular models at our showroom",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/vehicles",
								children: ["View all vehicles ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
						children: [
							vehicles.isLoading && Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-[26rem] rounded-xl" }, i)),
							vehicles.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-destructive",
								children: "Could not load vehicles right now. Please refresh the page."
							}),
							featured.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCard, { vehicle }, vehicle.id))
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-secondary py-16 sm:py-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-page",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
							eyebrow: "Browse by category",
							title: "Scooters or motorcycles?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-6 md:grid-cols-2",
							children: CATEGORIES.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/vehicles",
								search: { category: category.value },
								className: "group relative isolate overflow-hidden rounded-2xl bg-ink text-ink-foreground shadow-card",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: category.image,
										alt: `Honda ${category.label.toLowerCase()} at the showroom`,
										loading: "lazy",
										width: 1200,
										height: 900,
										className: "absolute inset-0 h-full w-full object-cover opacity-55 transition-transform duration-500 group-hover:scale-105"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink via-ink/60 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex min-h-64 flex-col justify-end p-7",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-3xl font-bold uppercase tracking-wide",
												children: category.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 max-w-sm text-sm opacity-80",
												children: category.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-4 inline-flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-wide text-primary",
												children: [
													"Browse ",
													category.label,
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
												]
											})
										]
									})
								]
							}, category.value))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "container-page py-16 sm:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						eyebrow: "Current offers",
						title: "Running promotions at the showroom",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/offers",
								children: ["All offers ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid gap-6 md:grid-cols-3",
						children: [
							offers.isLoading && Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-52 rounded-xl" }, i)),
							activeOffers.map((offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "flex flex-col rounded-xl border border-border bg-card p-6 shadow-card",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgePercent, { className: "size-6 text-primary" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-display text-2xl font-bold uppercase tracking-wide",
										children: offer.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 line-clamp-3 text-sm text-muted-foreground",
										children: offer.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 font-display text-lg font-semibold text-primary",
										children: offer.benefit
									})
								]
							}, offer.id)),
							!offers.isLoading && activeOffers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No offers are running right now. Please check back soon."
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-secondary py-16 sm:py-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-page",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
							eyebrow: "Why choose us",
							title: "A dealership that stays with you"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
							children: SHOWROOM.whyChooseUs.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border bg-card p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" }, "a"),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-5" }, "b"),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-5" }, "c")
										][index % 3]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-display text-xl font-bold uppercase tracking-wide",
										children: item.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted-foreground",
										children: item.description
									})
								]
							}, item.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "container-page grid items-center gap-10 py-16 sm:py-20 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/demo/showroom-interior.jpg",
						alt: `Inside the ${SHOWROOM.name} showroom`,
						loading: "lazy",
						width: 1600,
						height: 1e3,
						className: "rounded-2xl object-cover shadow-card"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "About the showroom"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-3 font-display text-4xl font-bold uppercase leading-tight tracking-tight",
							children: [
								SHOWROOM.name,
								", serving riders since ",
								SHOWROOM.established
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted-foreground",
							children: SHOWROOM.about.intro
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-muted-foreground",
							children: SHOWROOM.about.promise
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/about",
									children: ["About our showroom ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/contact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {}), " Find us"]
								})
							})]
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "container-page flex flex-col items-start gap-6 py-14 md:flex-row md:items-center md:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl font-bold uppercase leading-tight tracking-tight",
							children: "Ready for a test ride?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl opacity-90",
							children: "Call or message us and we will keep the model you like ready at the showroom."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `tel:${SHOWROOM.phone}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}),
										" ",
										SHOWROOM.phoneDisplay
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								className: "border-white/50 bg-transparent text-primary-foreground hover:bg-white/15 hover:text-primary-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									children: "Send an enquiry"
								})
							})]
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileContactBar, {})
		]
	});
}
function SectionHead({ eyebrow, title, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "eyebrow",
			children: eyebrow
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 max-w-xl font-display text-4xl font-bold uppercase leading-tight tracking-tight",
			children: title
		})] }), action]
	});
}
//#endregion
export { HomePage as component };
