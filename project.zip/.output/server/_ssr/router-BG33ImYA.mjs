import { r as __toESM } from "../_runtime.mjs";
import { n as SHOWROOM } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Route$13 } from "./admin.vehicles-BEMghX9P.mjs";
import { t as DESCRIPTION$4 } from "./products.accessories-BWuDVFpw.mjs";
import { t as DESCRIPTION$5 } from "./products.ev-Dib9FsJi.mjs";
import { t as DESCRIPTION$6 } from "./products.lubes-Co5uoGr8.mjs";
import { t as DESCRIPTION$7 } from "./resources.video-gallery-C6DDxbnZ.mjs";
import { t as Route$14 } from "./vehicles.index-CUo6yFPh.mjs";
import { t as Route$15 } from "./vehicles._slug-B37e-3N5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BG33ImYA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BC3Ba7SB.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$12 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Sai Honda — Honda Two-Wheeler Showroom" },
			{
				name: "description",
				content: "Honda scooters and motorcycles at our showroom — models, prices, availability and offers."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&family=Barlow+Condensed:wght@500;600;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$12.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$11 = () => import("./routes-BLrJj8Po.mjs");
var TITLE$7 = `${SHOWROOM.name} — Honda Scooters & Motorcycles Showroom`;
var DESCRIPTION$3 = "Explore Honda scooters and motorcycles available at our showroom. Check models, variants, prices and live availability, then contact our team.";
var Route$11 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: TITLE$7 },
		{
			name: "description",
			content: DESCRIPTION$3
		},
		{
			property: "og:title",
			content: TITLE$7
		},
		{
			property: "og:description",
			content: DESCRIPTION$3
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./about-DCQzf73d.mjs");
var TITLE$6 = `About ${SHOWROOM.name} — Honda Two-Wheeler Dealership`;
var DESCRIPTION$2 = `Learn about ${SHOWROOM.name}, an authorised Honda two-wheeler dealership serving riders since ${SHOWROOM.established} with sales, service and finance under one roof.`;
var Route$10 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: TITLE$6 },
		{
			name: "description",
			content: DESCRIPTION$2
		},
		{
			property: "og:title",
			content: TITLE$6
		},
		{
			property: "og:description",
			content: DESCRIPTION$2
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./admin-CsQXBkho.mjs");
var Route$9 = createFileRoute("/admin")({
	ssr: false,
	head: () => ({ meta: [
		{ title: `Staff Admin — ${SHOWROOM.name}` },
		{
			name: "description",
			content: "Showroom staff area for managing vehicles, offers and enquiries."
		},
		{
			name: "robots",
			content: "noindex, nofollow"
		},
		{
			property: "og:title",
			content: `Staff Admin — ${SHOWROOM.name}`
		},
		{
			property: "og:description",
			content: "Showroom staff area."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./contact-Cxk0IPAZ.mjs");
var TITLE$5 = `Contact ${SHOWROOM.name} — Phone, WhatsApp & Enquiry Form`;
var DESCRIPTION$1 = `Contact our Honda showroom by phone, WhatsApp or email, check business hours and location, or send an enquiry about any model.`;
var Route$8 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: TITLE$5 },
		{
			name: "description",
			content: DESCRIPTION$1
		},
		{
			property: "og:title",
			content: TITLE$5
		},
		{
			property: "og:description",
			content: DESCRIPTION$1
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./offers-BXX3nHR0.mjs");
var TITLE$4 = `Current Honda Offers & Finance Deals — ${SHOWROOM.name}`;
var DESCRIPTION = "See the offers running at our Honda showroom: seasonal benefits, exchange bonus, low down payment finance and free first service.";
var Route$7 = createFileRoute("/offers")({
	head: () => ({ meta: [
		{ title: TITLE$4 },
		{
			name: "description",
			content: DESCRIPTION
		},
		{
			property: "og:title",
			content: TITLE$4
		},
		{
			property: "og:description",
			content: DESCRIPTION
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./admin.index-CjBCOwqf.mjs");
var Route$6 = createFileRoute("/admin/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./admin.enquiries-DnxMhnfi.mjs");
var Route$5 = createFileRoute("/admin/enquiries")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.offers-Odl0MYqO.mjs");
var Route$4 = createFileRoute("/admin/offers")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./products.accessories-Dz8nV0H-.mjs");
var TITLE$3 = `Honda Accessories — ${SHOWROOM.name}`;
var Route$3 = createFileRoute("/products/accessories")({
	head: () => ({ meta: [
		{ title: TITLE$3 },
		{
			name: "description",
			content: DESCRIPTION$4
		},
		{
			property: "og:title",
			content: TITLE$3
		},
		{
			property: "og:description",
			content: DESCRIPTION$4
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./products.ev-CAUyBIXi.mjs");
var TITLE$2 = `Honda EV Range — ${SHOWROOM.name}`;
var Route$2 = createFileRoute("/products/ev")({
	head: () => ({ meta: [
		{ title: TITLE$2 },
		{
			name: "description",
			content: DESCRIPTION$5
		},
		{
			property: "og:title",
			content: TITLE$2
		},
		{
			property: "og:description",
			content: DESCRIPTION$5
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./products.lubes-CWcxC24H.mjs");
var TITLE$1 = `Genuine Lubes & Chemicals — ${SHOWROOM.name}`;
var Route$1 = createFileRoute("/products/lubes")({
	head: () => ({ meta: [
		{ title: TITLE$1 },
		{
			name: "description",
			content: DESCRIPTION$6
		},
		{
			property: "og:title",
			content: TITLE$1
		},
		{
			property: "og:description",
			content: DESCRIPTION$6
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./resources.video-gallery-B1gHcsfh.mjs");
var TITLE = `Honda Video Gallery — ${SHOWROOM.name}`;
var Route = createFileRoute("/resources/video-gallery")({
	head: () => ({ meta: [
		{ title: TITLE },
		{
			name: "description",
			content: DESCRIPTION$7
		},
		{
			property: "og:title",
			content: TITLE
		},
		{
			property: "og:description",
			content: DESCRIPTION$7
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$11.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$12
});
var AboutRoute = Route$10.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$12
});
var AdminRoute = Route$9.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$12
});
var ContactRoute = Route$8.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$12
});
var OffersRoute = Route$7.update({
	id: "/offers",
	path: "/offers",
	getParentRoute: () => Route$12
});
var AdminIndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminEnquiriesRoute = Route$5.update({
	id: "/enquiries",
	path: "/enquiries",
	getParentRoute: () => AdminRoute
});
var AdminOffersRoute = Route$4.update({
	id: "/offers",
	path: "/offers",
	getParentRoute: () => AdminRoute
});
var AdminVehiclesRoute = Route$13.update({
	id: "/vehicles",
	path: "/vehicles",
	getParentRoute: () => AdminRoute
});
var ProductsAccessoriesRoute = Route$3.update({
	id: "/products/accessories",
	path: "/products/accessories",
	getParentRoute: () => Route$12
});
var ProductsEvRoute = Route$2.update({
	id: "/products/ev",
	path: "/products/ev",
	getParentRoute: () => Route$12
});
var ProductsLubesRoute = Route$1.update({
	id: "/products/lubes",
	path: "/products/lubes",
	getParentRoute: () => Route$12
});
var ResourcesVideoGalleryRoute = Route.update({
	id: "/resources/video-gallery",
	path: "/resources/video-gallery",
	getParentRoute: () => Route$12
});
var VehiclesIndexRoute = Route$14.update({
	id: "/vehicles/",
	path: "/vehicles/",
	getParentRoute: () => Route$12
});
var VehiclesSlugRoute = Route$15.update({
	id: "/vehicles/$slug",
	path: "/vehicles/$slug",
	getParentRoute: () => Route$12
});
var AdminRouteChildren = {
	AdminEnquiriesRoute,
	AdminOffersRoute,
	AdminVehiclesRoute,
	AdminIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	ContactRoute,
	OffersRoute,
	ProductsAccessoriesRoute,
	ProductsEvRoute,
	ProductsLubesRoute,
	ResourcesVideoGalleryRoute,
	VehiclesSlugRoute,
	VehiclesIndexRoute
};
var routeTree = Route$12._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
