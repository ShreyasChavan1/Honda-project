import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { E as ImagePlus, t as X } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-DsxaCInS.mjs";
import { n as Label } from "./label-CmIE8x5o.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/image-manager-D5F3lsVZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VEHICLE_BUCKET = "vehicle-images";
/** ~10 years, so stored URLs stay valid for the life of the listing. */
var SIGNED_URL_TTL = 3600 * 24 * 365 * 10;
var extensionOf = (name) => {
	const parts = name.split(".");
	return parts.length > 1 ? parts.pop().toLowerCase() : "jpg";
};
/** Largest stored width; taller/wider originals are scaled down proportionally. */
var MAX_WIDTH = 1600;
var WEBP_QUALITY = .82;
var supportsWebp = () => {
	try {
		return document.createElement("canvas").toDataURL("image/webp").startsWith("data:image/webp");
	} catch {
		return false;
	}
};
/**
* Resizes to at most MAX_WIDTH and re-encodes as WebP. Falls back to the
* original file whenever the browser can't decode/encode it (e.g. SVG, HEIC).
*/
async function optimiseImage(file) {
	const fallback = {
		blob: file,
		extension: extensionOf(file.name)
	};
	if (typeof document === "undefined" || !file.type.startsWith("image/")) return fallback;
	if (file.type === "image/svg+xml" || file.type === "image/gif" || !supportsWebp()) return fallback;
	try {
		const bitmap = await createImageBitmap(file);
		const scale = Math.min(1, MAX_WIDTH / bitmap.width);
		const width = Math.max(1, Math.round(bitmap.width * scale));
		const height = Math.max(1, Math.round(bitmap.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const context = canvas.getContext("2d");
		if (!context) return fallback;
		context.drawImage(bitmap, 0, 0, width, height);
		bitmap.close?.();
		const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", WEBP_QUALITY));
		if (!blob || blob.size === 0) return fallback;
		return {
			blob,
			extension: "webp"
		};
	} catch {
		return fallback;
	}
}
/**
* Uploads one image to Cloud storage and returns a long-lived URL that can be
* stored in the database and rendered directly in an <img> tag.
*/
async function uploadVehicleImage(file, folder = "vehicles") {
	const { blob, extension } = await optimiseImage(file);
	const path = `${folder}/${crypto.randomUUID()}.${extension}`;
	const { error } = await supabase.storage.from(VEHICLE_BUCKET).upload(path, blob, {
		cacheControl: "31536000",
		contentType: blob.type || file.type || "image/webp",
		upsert: false
	});
	if (error) throw new Error(error.message);
	const { data, error: signError } = await supabase.storage.from(VEHICLE_BUCKET).createSignedUrl(path, SIGNED_URL_TTL);
	if (signError || !data) throw new Error(signError?.message ?? "Could not create image URL");
	return data.signedUrl;
}
async function uploadVehicleImages(files, folder = "vehicles") {
	const urls = [];
	for (const file of files) urls.push(await uploadVehicleImage(file, folder));
	return urls;
}
/** Uploads a PDF brochure and returns a long-lived signed URL. */
/**
* Reusable uploader used across the admin panel: multiple images, preview grid,
* remove, and add more later. Values are stored URLs.
*/
function ImageManager({ label, hint, images, onChange, folder = "vehicles" }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const handleFiles = async (files) => {
		if (!files || files.length === 0) return;
		setBusy(true);
		setError(null);
		try {
			const uploaded = await uploadVehicleImages(Array.from(files), folder);
			onChange([...images, ...uploaded]);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Upload failed");
		} finally {
			setBusy(false);
			if (inputRef.current) inputRef.current.value = "";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					disabled: busy,
					onClick: () => inputRef.current?.click(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}),
						" ",
						busy ? "Uploading…" : "Upload images"
					]
				})]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*",
				multiple: true,
				className: "hidden",
				onChange: (event) => void handleFiles(event.target.files)
			}),
			images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-3",
				children: images.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative h-20 w-28 overflow-hidden rounded-lg border border-border bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "",
						className: "h-full w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Remove image",
						onClick: () => onChange(images.filter((_, i) => i !== index)),
						className: "absolute right-1 top-1 rounded-full bg-background/90 p-1 text-foreground shadow-card hover:bg-destructive hover:text-destructive-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, `${image}-${index}`))
			}),
			images.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-dashed border-border p-4 text-xs text-muted-foreground",
				children: "No images yet."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
//#endregion
export { ImageManager as t };
