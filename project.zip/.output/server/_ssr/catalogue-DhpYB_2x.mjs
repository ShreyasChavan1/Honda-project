import { t as supabase } from "./client-DsxaCInS.mjs";
import { n as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue-DhpYB_2x.js
var normaliseEmiOptions = (value) => (Array.isArray(value) ? value : []).map((item) => {
	const row = item ?? {};
	return {
		months: Number(row["months"]) || 0,
		rate: Number(row["rate"]) || 0
	};
}).filter((option) => option.months > 0);
/** Standard reducing-balance EMI. */
var calculateEmi = (principal, annualRate, months) => {
	if (principal <= 0 || months <= 0) return 0;
	const monthly = annualRate / 12 / 100;
	if (monthly === 0) return principal / months;
	const factor = Math.pow(1 + monthly, months);
	return principal * monthly * factor / (factor - 1);
};
var EMI_DISCLAIMER = "EMI and on-road price are indicative and may vary based on lender, insurance, RTO charges, offers and other applicable charges.";
var asVehicle = (row) => ({
	...row,
	price_from: row["price_from"] == null ? null : Number(row["price_from"]),
	specs: row["specs"] ?? {}
});
var asVariant = (row) => ({
	...row,
	price: row["price"] == null ? null : Number(row["price"]),
	ex_showroom_price: row["ex_showroom_price"] == null ? row["price"] == null ? null : Number(row["price"]) : Number(row["ex_showroom_price"]),
	on_road_price: row["on_road_price"] == null ? null : Number(row["on_road_price"]),
	emi_options: normaliseEmiOptions(row["emi_options"]),
	specs: row["specs"] ?? {},
	colours: (row["variant_colours"] ?? []).map((colour) => colour).sort((a, b) => a.sort_order - b.sort_order)
});
var variantsQuery = (vehicleId) => queryOptions({
	queryKey: ["variants", vehicleId ?? "none"],
	enabled: Boolean(vehicleId),
	queryFn: async () => {
		if (!vehicleId) return [];
		const { data, error } = await supabase.from("vehicle_variants").select("*, variant_colours(*)").eq("vehicle_id", vehicleId).order("sort_order", { ascending: true });
		if (error) throw new Error(error.message);
		return (data ?? []).map(asVariant);
	}
});
var vehiclesQuery = queryOptions({
	queryKey: ["vehicles"],
	queryFn: async () => {
		const { data, error } = await supabase.from("vehicles").select("*").order("sort_order", { ascending: true });
		if (error) throw new Error(error.message);
		return (data ?? []).map(asVehicle);
	}
});
var vehicleQuery = (slug) => queryOptions({
	queryKey: ["vehicle", slug],
	queryFn: async () => {
		const { data, error } = await supabase.from("vehicles").select("*").eq("slug", slug).maybeSingle();
		if (error) throw new Error(error.message);
		return data ? asVehicle(data) : null;
	}
});
var offersQuery = queryOptions({
	queryKey: ["offers"],
	queryFn: async () => {
		const { data, error } = await supabase.from("offers").select("*").order("sort_order", { ascending: true });
		if (error) throw new Error(error.message);
		return data ?? [];
	}
});
var enquiriesQuery = queryOptions({
	queryKey: ["enquiries"],
	queryFn: async () => {
		const { data, error } = await supabase.from("enquiries").select("*").order("created_at", { ascending: false });
		if (error) throw new Error(error.message);
		return data ?? [];
	}
});
//#endregion
export { variantsQuery as a, offersQuery as i, calculateEmi as n, vehicleQuery as o, enquiriesQuery as r, vehiclesQuery as s, EMI_DISCLAIMER as t };
