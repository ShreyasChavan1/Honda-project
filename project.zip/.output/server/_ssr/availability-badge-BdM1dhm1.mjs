import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn } from "./button-DRsC1qZi.mjs";
import { E as CircleCheck, T as Clock } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/availability-badge-BdM1dhm1.js
var import_jsx_runtime = require_jsx_runtime();
function AvailabilityBadge({ available, size = "sm", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full font-display font-semibold uppercase tracking-wide", size === "sm" ? "px-2.5 py-1 text-xs" : "px-4 py-2 text-sm", available ? "bg-success/12 text-success" : "bg-muted text-muted-foreground", className),
		children: [available ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }), available ? "Available at Showroom" : "Currently Unavailable"]
	});
}
//#endregion
export { AvailabilityBadge as t };
