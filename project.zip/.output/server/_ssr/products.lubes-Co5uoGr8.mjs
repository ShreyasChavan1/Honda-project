//#region node_modules/.nitro/vite/services/ssr/assets/products.lubes-Co5uoGr8.js
var DESCRIPTION = "Explore demo information about genuine engine oils, lubricants and maintenance chemicals for Honda two-wheelers.";
//#endregion
export { DESCRIPTION as t };
