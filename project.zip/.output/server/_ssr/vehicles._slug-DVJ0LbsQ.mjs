import { n as __toESM } from "../_runtime.mjs";
import { a as waLink, i as formatPrice, n as SHOWROOM, r as categoryLabel } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as ArrowLeft, d as Phone, m as MessageCircle } from "../_libs/lucide-react.mjs";
import { n as SiteFooter, r as SiteHeader, t as MobileContactBar } from "./mobile-contact-bar-Du0E7NVK.mjs";
import { n as Label } from "./label-CmIE8x5o.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { a as variantsQuery, n as calculateEmi, o as vehicleQuery, t as EMI_DISCLAIMER } from "./catalogue-CvvAtD1R.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as AvailabilityBadge } from "./availability-badge-BdM1dhm1.mjs";
import { t as EnquiryForm } from "./enquiry-form-DQIFAR0K.mjs";
import { t as Route } from "./vehicles._slug-DDCxlpkE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._slug-DVJ0LbsQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" })]
}));
Slider.displayName = Slider$1.displayName;
function VehicleDetailPage() {
	const { slug } = Route.useParams();
	const { data: vehicle, isLoading, isError } = useQuery(vehicleQuery(slug));
	const { data: variants } = useQuery(variantsQuery(vehicle?.id));
	const [activeImage, setActiveImage] = (0, import_react.useState)(null);
	const [variantId, setVariantId] = (0, import_react.useState)(null);
	const [colourId, setColourId] = (0, import_react.useState)(null);
	const variantList = variants ?? [];
	const variant = variantList.find((item) => item.id === variantId) ?? variantList[0] ?? null;
	const colours = variant?.colours ?? [];
	const colour = colours.find((item) => item.id === colourId) ?? colours[0] ?? null;
	const generalImages = vehicle ? [vehicle.image_url, ...vehicle.gallery].filter(Boolean) : [];
	const images = colour && colour.images.length > 0 ? colour.images.filter(Boolean) : generalImages;
	const shown = activeImage && images.includes(activeImage) ? activeImage : images[0];
	const exShowroom = variant ? variant.ex_showroom_price ?? variant.price : vehicle?.price_from ?? null;
	const onRoad = variant?.on_road_price ?? null;
	const specs = variant && Object.keys(variant.specs).length > 0 ? variant.specs : vehicle?.specs ?? {};
	const available = variant ? variant.is_available : Boolean(vehicle?.is_available);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen pb-14 md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "container-page py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/vehicles",
						className: "inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back to catalogue"]
					}),
					isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-10 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-4/3 rounded-2xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-2/3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-40" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full" })
							]
						})]
					}),
					isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 rounded-xl border border-destructive/30 bg-destructive/5 p-8 text-center text-sm text-muted-foreground",
						children: "We could not load this model. Please refresh or call the showroom."
					}),
					!isLoading && !isError && !vehicle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 rounded-xl border border-border bg-card p-10 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-3xl font-bold uppercase",
								children: "Model not found"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "This model is not listed at our showroom."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/vehicles",
									children: "Browse all vehicles"
								})
							})
						]
					}),
					vehicle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-10 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-2xl border border-border bg-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: shown,
									alt: `Honda ${vehicle.name} — ${categoryLabel(vehicle.category)}`,
									width: 1200,
									height: 900,
									className: "aspect-4/3 w-full object-cover"
								})
							}), images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex gap-3",
								children: images.map((image) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setActiveImage(image),
									className: "h-20 w-24 overflow-hidden rounded-lg border-2 " + (shown === image ? "border-primary" : "border-border"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: image,
										alt: `${vehicle.name} photo`,
										loading: "lazy",
										className: "h-full w-full object-cover"
									})
								}, image))
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: categoryLabel(vehicle.category)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-2 font-display text-5xl font-bold uppercase leading-none tracking-tight",
									children: ["Honda ", vehicle.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityBadge, {
										available,
										size: "lg"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-muted-foreground",
									children: vehicle.short_description
								}),
								variantList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground",
										children: "Variants"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex flex-wrap gap-2",
										children: variantList.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setVariantId(item.id);
												setColourId(null);
												setActiveImage(null);
											},
											className: "rounded-full border px-4 py-2 text-sm font-semibold transition-colors " + (variant?.id === item.id ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card hover:border-primary"),
											children: item.name
										}, item.id))
									})]
								}),
								colours.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground",
										children: "Available colours"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex flex-wrap gap-2",
										children: colours.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setColourId(item.id);
												setActiveImage(null);
											},
											className: "rounded-full border px-4 py-2 text-sm font-medium transition-colors " + (colour?.id === item.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-card hover:border-primary"),
											children: item.name
										}, item.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 rounded-xl border border-border bg-card p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
											children: "Ex-showroom price"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-4xl font-bold",
											children: formatPrice(exShowroom)
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
											children: "On-road price"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-4xl font-bold",
											children: formatPrice(onRoad)
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-xs text-muted-foreground",
										children: "EMI and on-road price are indicative and may vary based on lender, insurance, RTO charges, offers and other applicable charges."
									})]
								}),
								variant && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmiCalculator, {
									onRoadPrice: onRoad,
									options: variant.emi_options
								}, variant.id),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 grid gap-3 sm:grid-cols-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: `tel:${SHOWROOM.phone}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}), " Call"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											variant: "secondary",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: waLink(`Hello ${SHOWROOM.name}, I am interested in the Honda ${vehicle.name}${variant ? ` ${variant.name}` : ""}${colour ? ` in ${colour.name}` : ""}. Is it available?`),
												target: "_blank",
												rel: "noreferrer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {}), " WhatsApp"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											variant: "outline",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "#enquire",
												children: "Enquire"
											})
										})
									]
								})
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-14 grid gap-10 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-bold uppercase tracking-wide",
								children: "About this model"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-muted-foreground",
								children: vehicle.description
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-bold uppercase tracking-wide",
								children: "Key specifications"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 divide-y divide-border rounded-xl border border-border bg-card",
								children: [Object.entries(specs).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-6 px-5 py-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: key
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-right font-semibold",
										children: String(value)
									})]
								}, key)), Object.keys(specs).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-5 py-4 text-sm text-muted-foreground",
									children: "Specifications will be updated shortly."
								})]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "enquire",
							className: "mt-16 rounded-2xl border border-border bg-secondary p-6 sm:p-10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Enquire about this model"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-2 font-display text-3xl font-bold uppercase tracking-wide",
									children: ["Ask us about the Honda ", vehicle.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-2xl text-sm text-muted-foreground",
									children: "Send us your details and our team will call you back with price, availability and test ride options."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 max-w-3xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryForm, { defaultVehicle: variant ? `${vehicle.name} ${variant.name}` : vehicle.name })
								})
							]
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileContactBar, {})
		]
	});
}
function EmiCalculator({ onRoadPrice, options }) {
	const [downPayment, setDownPayment] = (0, import_react.useState)(0);
	const [tenureIndex, setTenureIndex] = (0, import_react.useState)(0);
	const [interestRate, setInterestRate] = (0, import_react.useState)(options[0]?.rate ?? 10);
	const selected = options[tenureIndex] ?? options[0];
	if (!onRoadPrice || !selected) return null;
	const loanAmount = Math.max(onRoadPrice - downPayment, 0);
	const emi = calculateEmi(loanAmount, interestRate, selected.months);
	const downPaymentStep = Math.max(500, Math.round(onRoadPrice / 100 / 500) * 500);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground",
				children: "EMI calculator"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-6 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "emi-down",
								children: "Down payment"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("output", {
								className: "font-display text-lg font-bold text-primary",
								children: formatPrice(downPayment)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							id: "emi-down",
							"aria-label": "Down payment",
							min: 0,
							max: onRoadPrice,
							step: downPaymentStep,
							value: [downPayment],
							onValueChange: (value) => setDownPayment(Math.min(value[0] ?? 0, onRoadPrice))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-[11px] text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatPrice(0) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatPrice(onRoadPrice) })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "emi-tenure",
								children: "Loan tenure"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("output", {
								className: "font-display text-lg font-bold text-primary",
								children: [selected.months, " months"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							id: "emi-tenure",
							"aria-label": "Loan tenure",
							min: 0,
							max: options.length - 1,
							step: 1,
							value: [tenureIndex],
							onValueChange: (value) => {
								const nextIndex = value[0] ?? 0;
								const nextOption = options[nextIndex];
								setTenureIndex(nextIndex);
								if (nextOption) setInterestRate(nextOption.rate);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-[11px] text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [options[0]?.months, " mo"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [options[options.length - 1]?.months, " mo"] })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "emi-interest",
							children: "Interest rate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("output", {
							className: "font-display text-lg font-bold text-primary",
							children: [interestRate.toFixed(1), "% p.a."]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						id: "emi-interest",
						"aria-label": "Interest rate",
						min: 1,
						max: 24,
						step: .1,
						value: [interestRate],
						onValueChange: (value) => setInterestRate(value[0] ?? selected.rate)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-[11px] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1%" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "24%" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground",
						children: "Defaults to the showroom rate for the selected tenure. Adjust it to compare estimates."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border bg-secondary px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
							children: "Loan amount"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-display text-xl font-bold",
							children: formatPrice(loanAmount)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border bg-secondary px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
								children: "Interest rate"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "font-display text-xl font-bold",
								children: [interestRate.toFixed(1), "% p.a."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "User-selected estimate"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-primary/40 bg-primary/5 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
							children: "Estimated EMI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-display text-xl font-bold text-primary",
							children: `${formatPrice(Math.round(emi))}/mo`
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted-foreground",
				children: EMI_DISCLAIMER
			})
		]
	});
}
//#endregion
export { VehicleDetailPage as component };
