import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as DESCRIPTION } from "./products.accessories-BWuDVFpw.mjs";
import { t as ProductCategoryPage } from "./product-category-page-vzCWckyV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.accessories-Dz8nV0H-.js
var import_jsx_runtime = require_jsx_runtime();
var accessories_default = "/assets/accessories-ISdcnwFd.jpg";
function AccessoriesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCategoryPage, {
		eyebrow: "Personalise your ride",
		title: "Accessories",
		description: DESCRIPTION,
		image: accessories_default,
		imageAlt: "A selection of two-wheeler riding and vehicle accessories",
		features: [
			{
				title: "Model-wise fitment",
				description: "Choose accessories designed around the fit, finish and everyday use of individual Honda models."
			},
			{
				title: "Protection & utility",
				description: "Explore guards, covers, storage solutions and practical additions for daily riding."
			},
			{
				title: "Riding essentials",
				description: "Ask our team about helmets, gloves and other essentials for comfort and responsible riding."
			}
		],
		note: "Demo content for development. Product range, compatibility and prices must be confirmed with the showroom before purchase."
	});
}
//#endregion
export { AccessoriesPage as component };
