//#region node_modules/.nitro/vite/services/ssr/assets/products.lubes-C0oK6QOi.js
var DESCRIPTION = "Genuine engine oils, lubricants and maintenance chemicals for Honda two-wheelers, managed by our showroom team.";
//#endregion
export { DESCRIPTION as t };
