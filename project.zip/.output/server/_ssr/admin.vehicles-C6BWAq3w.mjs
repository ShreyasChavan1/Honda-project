import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.vehicles-C6BWAq3w.js
var $$splitComponentImporter = () => import("./admin.vehicles-B3nevR2V.mjs");
var Route = createFileRoute("/admin/vehicles")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var parseSpecs = (value) => {
	const specs = {};
	for (const line of value.split("\n")) {
		const index = line.indexOf(":");
		if (index === -1) continue;
		const key = line.slice(0, index).trim();
		const val = line.slice(index + 1).trim();
		if (key) specs[key] = val;
	}
	return specs;
};
//#endregion
export { parseSpecs as n, Route as t };
