import { n as __toESM } from "../_runtime.mjs";
import { o as formatPrice } from "./showroom-qI0FNTtp.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { a as Trash2, m as Pencil, u as Plus } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-DsxaCInS.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { o as productsQuery } from "./catalogue-3zYAaxMW.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { t as Switch } from "./switch-CCza_WcE.mjs";
import { t as AvailabilityBadge } from "./availability-badge-BdM1dhm1.mjs";
import { t as ImageManager } from "./image-manager-D5F3lsVZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.products-rerQP55d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [{
	value: "lubes",
	label: "Genuine Lubes & Chemicals"
}, {
	value: "accessories",
	label: "Accessories"
}];
var emptyDraft = (category) => ({
	category,
	name: "",
	short_description: "",
	description: "",
	price: "",
	images: [],
	is_available: true,
	is_featured: false,
	sort_order: "0"
});
var toDraft = (product) => ({
	id: product.id,
	category: product.category,
	name: product.name,
	short_description: product.short_description,
	description: product.description,
	price: product.price == null ? "" : String(product.price),
	images: [product.image_url, ...product.gallery].filter(Boolean),
	is_available: product.is_available,
	is_featured: product.is_featured,
	sort_order: String(product.sort_order)
});
function AdminProducts() {
	const [tab, setTab] = (0, import_react.useState)("lubes");
	const { data, isLoading, isError } = useQuery(productsQuery(tab));
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const queryClient = useQueryClient();
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["products"] });
	};
	const save = useMutation({
		mutationFn: async (values) => {
			const payload = {
				category: values.category,
				name: values.name,
				short_description: values.short_description,
				description: values.description,
				price: values.price ? Number(values.price) : null,
				image_url: values.images[0] ?? "",
				gallery: values.images.slice(1),
				is_available: values.is_available,
				is_featured: values.is_featured,
				sort_order: Number(values.sort_order) || 0
			};
			const { error: saveError, data: saveData } = await (values.id ? supabase.from("products").update(payload).eq("id", values.id).select("id") : supabase.from("products").insert(payload).select("id"));
			if (saveError) throw new Error(saveError.message);
			if (values.id && (!saveData || saveData.length === 0)) throw new Error("Nothing was saved — you may have lost admin access. Please refresh and sign in again.");
		},
		onSuccess: () => {
			setDraft(null);
			setError(null);
			invalidate();
		},
		onError: (e) => setError(e.message)
	});
	const toggleAvailability = useMutation({
		mutationFn: async (product) => {
			const { error: e, data } = await supabase.from("products").update({ is_available: !product.is_available }).eq("id", product.id).select("id");
			if (e) throw new Error(e.message);
			if (!data || data.length === 0) throw new Error("Nothing was updated — you may have lost admin access. Please refresh and sign in again.");
		},
		onSuccess: invalidate
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error: e } = await supabase.from("products").delete().eq("id", id);
			if (e) throw new Error(e.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-bold uppercase tracking-tight",
					children: "Products"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Manage Genuine Lubes & Chemicals and Accessories shown under Products on the website."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setDraft(emptyDraft(tab));
						setError(null);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}),
						" Add ",
						TABS.find((t) => t.value === tab)?.label
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Product category",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === t.value,
					onClick: () => {
						setTab(t.value);
						setDraft(null);
						setError(null);
					},
					className: "min-h-10 rounded-full border px-4 font-display text-sm font-semibold uppercase tracking-wide transition-colors " + (tab === t.value ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:border-primary hover:text-primary"),
					children: t.label
				}, t.value))
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" }),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-muted-foreground",
				children: "Could not load products. Please refresh the page."
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => {
					event.preventDefault();
					save.mutate(draft);
				},
				className: "space-y-4 rounded-xl border border-primary/40 bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-bold uppercase tracking-wide",
						children: draft.id ? `Edit ${draft.name}` : `Add to ${TABS.find((t) => t.value === draft.category)?.label}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-name",
									children: "Product name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-name",
									required: true,
									value: draft.name,
									onChange: (e) => setDraft({
										...draft,
										name: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-category",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "p-category",
									value: draft.category,
									onChange: (e) => setDraft({
										...draft,
										category: e.target.value
									}),
									className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
									children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: t.value,
										children: t.label
									}, t.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-price",
									children: "Price (₹, optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-price",
									inputMode: "numeric",
									value: draft.price,
									onChange: (e) => setDraft({
										...draft,
										price: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-sort",
									children: "Display order"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-sort",
									inputMode: "numeric",
									value: draft.sort_order,
									onChange: (e) => setDraft({
										...draft,
										sort_order: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
									label: "Product images",
									hint: "The first image is used on the product card.",
									images: draft.images,
									folder: "products",
									onChange: (images) => setDraft({
										...draft,
										images
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-short",
									children: "Short description (shown on card)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-short",
									value: draft.short_description,
									onChange: (e) => setDraft({
										...draft,
										short_description: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-description",
									children: "Full description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "p-description",
									rows: 3,
									value: draft.description,
									onChange: (e) => setDraft({
										...draft,
										description: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-end gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "p-available",
										checked: draft.is_available,
										onCheckedChange: (checked) => setDraft({
											...draft,
											is_available: checked
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-available",
										children: "In stock"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "p-featured",
										checked: draft.is_featured,
										onCheckedChange: (checked) => setDraft({
											...draft,
											is_featured: checked
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-featured",
										children: "Featured"
									})]
								})]
							})
						]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: save.isPending,
							children: save.isPending ? "Saving…" : "Save product"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => {
								setDraft(null);
								setError(null);
							},
							children: "Cancel"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: (data ?? []).map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center gap-4 rounded-xl border border-border bg-card p-4",
					children: [
						product.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: product.image_url,
							alt: product.name,
							loading: "lazy",
							className: "h-20 w-28 rounded-lg object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-20 w-28 items-center justify-center rounded-lg bg-secondary text-xs text-muted-foreground",
							children: "No image"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-40 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-xl font-bold uppercase tracking-wide",
									children: product.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [formatPrice(product.price), product.is_featured ? " · Featured" : ""]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityBadge, { available: product.is_available })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 pr-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: `p-avail-${product.id}`,
										checked: product.is_available,
										onCheckedChange: () => toggleAvailability.mutate(product)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: `p-avail-${product.id}`,
										className: "text-xs",
										children: "In stock"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setDraft(toDraft(product)),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Edit"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => {
										if (window.confirm(`Delete ${product.name}? This cannot be undone.`)) remove.mutate(product.id);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
								})
							]
						})
					]
				}, product.id))
			}),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-card p-8 text-sm text-muted-foreground",
				children: "No products yet in this category. Use “Add” to list your first item."
			})
		]
	});
}
//#endregion
export { AdminProducts as component };
