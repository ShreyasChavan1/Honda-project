//#region node_modules/.nitro/vite/services/ssr/assets/resources.video-gallery-DHEq7Ihb.js
var DESCRIPTION = "Browse Honda product films, maintenance guides, riding tips and road-safety videos.";
//#endregion
export { DESCRIPTION as t };
