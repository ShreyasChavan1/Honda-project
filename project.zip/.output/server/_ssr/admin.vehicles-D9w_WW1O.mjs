import { n as __toESM } from "../_runtime.mjs";
import { i as formatPrice, r as categoryLabel, t as CATEGORIES } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { F as ArrowDown, M as ArrowUp, S as ImagePlus, b as Layers, c as Plus, f as Pencil, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-4t218RNL.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { a as variantsQuery, s as vehiclesQuery } from "./catalogue-CvvAtD1R.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { t as Switch } from "./switch-CCza_WcE.mjs";
import { n as parseSpecs } from "./admin.vehicles-CLZb4oPz.mjs";
import { t as AvailabilityBadge } from "./availability-badge-BdM1dhm1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.vehicles-D9w_WW1O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VEHICLE_BUCKET = "vehicle-images";
/** ~10 years, so stored URLs stay valid for the life of the listing. */
var SIGNED_URL_TTL = 3600 * 24 * 365 * 10;
var extensionOf = (name) => {
	const parts = name.split(".");
	return parts.length > 1 ? parts.pop().toLowerCase() : "jpg";
};
/** Largest stored width; taller/wider originals are scaled down proportionally. */
var MAX_WIDTH = 1600;
var WEBP_QUALITY = .82;
var supportsWebp = () => {
	try {
		return document.createElement("canvas").toDataURL("image/webp").startsWith("data:image/webp");
	} catch {
		return false;
	}
};
/**
* Resizes to at most MAX_WIDTH and re-encodes as WebP. Falls back to the
* original file whenever the browser can't decode/encode it (e.g. SVG, HEIC).
*/
async function optimiseImage(file) {
	const fallback = {
		blob: file,
		extension: extensionOf(file.name)
	};
	if (typeof document === "undefined" || !file.type.startsWith("image/")) return fallback;
	if (file.type === "image/svg+xml" || file.type === "image/gif" || !supportsWebp()) return fallback;
	try {
		const bitmap = await createImageBitmap(file);
		const scale = Math.min(1, MAX_WIDTH / bitmap.width);
		const width = Math.max(1, Math.round(bitmap.width * scale));
		const height = Math.max(1, Math.round(bitmap.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const context = canvas.getContext("2d");
		if (!context) return fallback;
		context.drawImage(bitmap, 0, 0, width, height);
		bitmap.close?.();
		const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", WEBP_QUALITY));
		if (!blob || blob.size === 0) return fallback;
		return {
			blob,
			extension: "webp"
		};
	} catch {
		return fallback;
	}
}
/**
* Uploads one image to Cloud storage and returns a long-lived URL that can be
* stored in the database and rendered directly in an <img> tag.
*/
async function uploadVehicleImage(file, folder = "vehicles") {
	const { blob, extension } = await optimiseImage(file);
	const path = `${folder}/${crypto.randomUUID()}.${extension}`;
	const { error } = await supabase.storage.from(VEHICLE_BUCKET).upload(path, blob, {
		cacheControl: "31536000",
		contentType: blob.type || file.type || "image/webp",
		upsert: false
	});
	if (error) throw new Error(error.message);
	const { data, error: signError } = await supabase.storage.from(VEHICLE_BUCKET).createSignedUrl(path, SIGNED_URL_TTL);
	if (signError || !data) throw new Error(signError?.message ?? "Could not create image URL");
	return data.signedUrl;
}
async function uploadVehicleImages(files, folder = "vehicles") {
	const urls = [];
	for (const file of files) urls.push(await uploadVehicleImage(file, folder));
	return urls;
}
/**
* Reusable uploader used across the admin panel: multiple images, preview grid,
* remove, and add more later. Values are stored URLs.
*/
function ImageManager({ label, hint, images, onChange, folder = "vehicles" }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const handleFiles = async (files) => {
		if (!files || files.length === 0) return;
		setBusy(true);
		setError(null);
		try {
			const uploaded = await uploadVehicleImages(Array.from(files), folder);
			onChange([...images, ...uploaded]);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Upload failed");
		} finally {
			setBusy(false);
			if (inputRef.current) inputRef.current.value = "";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					disabled: busy,
					onClick: () => inputRef.current?.click(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}),
						" ",
						busy ? "Uploading…" : "Upload images"
					]
				})]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*",
				multiple: true,
				className: "hidden",
				onChange: (event) => void handleFiles(event.target.files)
			}),
			images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-3",
				children: images.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative h-20 w-28 overflow-hidden rounded-lg border border-border bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "",
						className: "h-full w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Remove image",
						onClick: () => onChange(images.filter((_, i) => i !== index)),
						className: "absolute right-1 top-1 rounded-full bg-background/90 p-1 text-foreground shadow-card hover:bg-destructive hover:text-destructive-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, `${image}-${index}`))
			}),
			images.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-dashed border-border p-4 text-xs text-muted-foreground",
				children: "No images yet."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
var EMPTY = {
	slug: "",
	name: "",
	category: "scooter",
	short_description: "",
	description: "",
	price_from: "",
	images: [],
	is_available: true,
	is_featured: false,
	sort_order: "0"
};
var toDraft = (vehicle) => ({
	id: vehicle.id,
	slug: vehicle.slug,
	name: vehicle.name,
	category: vehicle.category,
	short_description: vehicle.short_description,
	description: vehicle.description,
	price_from: vehicle.price_from == null ? "" : String(vehicle.price_from),
	images: [vehicle.image_url, ...vehicle.gallery].filter(Boolean),
	is_available: vehicle.is_available,
	is_featured: vehicle.is_featured,
	sort_order: String(vehicle.sort_order)
});
var specsToText = (specs) => Object.entries(specs).map(([key, value]) => `${key}: ${value}`).join("\n");
var slugify = (value) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
function AdminVehicles() {
	const { data, isLoading, isError } = useQuery(vehiclesQuery);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [openVariants, setOpenVariants] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const queryClient = useQueryClient();
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["vehicles"] });
		queryClient.invalidateQueries({ queryKey: ["vehicle"] });
	};
	const save = useMutation({
		mutationFn: async (values) => {
			const payload = {
				slug: values.slug || slugify(values.name),
				name: values.name,
				category: values.category,
				short_description: values.short_description,
				description: values.description,
				price_from: values.price_from ? Number(values.price_from) : null,
				image_url: values.images[0] ?? "",
				gallery: values.images.slice(1),
				is_available: values.is_available,
				is_featured: values.is_featured,
				sort_order: Number(values.sort_order) || 0
			};
			const { error: saveError } = await (values.id ? supabase.from("vehicles").update(payload).eq("id", values.id) : supabase.from("vehicles").insert(payload));
			if (saveError) throw new Error(saveError.message);
		},
		onSuccess: () => {
			setDraft(null);
			setError(null);
			invalidate();
		},
		onError: (e) => setError(e.message)
	});
	const toggleAvailability = useMutation({
		mutationFn: async (vehicle) => {
			const { error: e } = await supabase.from("vehicles").update({ is_available: !vehicle.is_available }).eq("id", vehicle.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: invalidate
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error: e } = await supabase.from("vehicles").delete().eq("id", id);
			if (e) throw new Error(e.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-bold uppercase tracking-tight",
					children: "Vehicles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Add models, then manage their variants, colours and gallery images."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setDraft({ ...EMPTY }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add vehicle"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" }),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-muted-foreground",
				children: "Could not load vehicles. Please refresh the page."
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleForm, {
				draft,
				onChange: setDraft,
				onCancel: () => {
					setDraft(null);
					setError(null);
				},
				onSave: () => save.mutate(draft),
				saving: save.isPending,
				error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: (data ?? []).map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: vehicle.image_url,
								alt: vehicle.name,
								loading: "lazy",
								className: "h-20 w-28 rounded-lg object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-40 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl font-bold uppercase tracking-wide",
										children: vehicle.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground",
										children: [
											categoryLabel(vehicle.category),
											" · ",
											formatPrice(vehicle.price_from),
											vehicle.is_featured ? " · Featured" : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityBadge, { available: vehicle.is_available })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 pr-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											id: `available-${vehicle.id}`,
											checked: vehicle.is_available,
											onCheckedChange: () => toggleAvailability.mutate(vehicle)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: `available-${vehicle.id}`,
											className: "text-xs",
											children: "In stock"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: openVariants === vehicle.id ? "default" : "outline",
										onClick: () => setOpenVariants(openVariants === vehicle.id ? null : vehicle.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {}), " Variants"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setDraft(toDraft(vehicle)),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Edit"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (window.confirm(`Delete ${vehicle.name}? This cannot be undone.`)) remove.mutate(vehicle.id);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
									})
								]
							})
						]
					}), openVariants === vehicle.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantsPanel, { vehicle })]
				}, vehicle.id))
			}),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-card p-8 text-sm text-muted-foreground",
				children: "No vehicles yet. Use “Add vehicle” to list your first model."
			})
		]
	});
}
function VehicleForm({ draft, onChange, onCancel, onSave, saving, error }) {
	const set = (key, value) => onChange({
		...draft,
		[key]: value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			onSave();
		},
		className: "space-y-4 rounded-xl border border-primary/40 bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-bold uppercase tracking-wide",
				children: draft.id ? `Edit ${draft.name}` : "Add a vehicle"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "name",
							children: "Model name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "name",
							required: true,
							value: draft.name,
							onChange: (e) => set("name", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "slug",
							children: "Web address (slug)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "slug",
							value: draft.slug,
							placeholder: slugify(draft.name) || "activa-6g",
							onChange: (e) => set("slug", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "category",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "category",
							value: draft.category,
							onChange: (e) => set("category", e.target.value),
							className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
							children: CATEGORIES.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: category.value,
								children: category.label
							}, category.value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "price",
							children: "Starting price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "price",
							inputMode: "numeric",
							value: draft.price_from,
							onChange: (e) => set("price_from", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
							label: "Main vehicle images",
							hint: "The first image is used on cards and as the default gallery image.",
							images: draft.images,
							onChange: (images) => set("images", images)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "short",
							children: "Short description (shown on cards)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "short",
							value: draft.short_description,
							onChange: (e) => set("short_description", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "description",
							children: "Full description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "description",
							rows: 3,
							value: draft.description,
							onChange: (e) => set("description", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "sort",
							children: "Display order"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "sort",
							inputMode: "numeric",
							value: draft.sort_order,
							onChange: (e) => set("sort_order", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								id: "available",
								checked: draft.is_available,
								onCheckedChange: (checked) => set("is_available", checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "available",
								children: "Available at showroom"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								id: "featured",
								checked: draft.is_featured,
								onCheckedChange: (checked) => set("is_featured", checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "featured",
								children: "Featured on home"
							})]
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: saving,
					children: saving ? "Saving…" : "Save vehicle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: onCancel,
					children: "Cancel"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Variants, variant prices, specifications and colour galleries are managed with the “Variants” button on the model below."
			})
		]
	});
}
function VariantsPanel({ vehicle }) {
	const queryClient = useQueryClient();
	const { data, isLoading } = useQuery(variantsQuery(vehicle.id));
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["variants", vehicle.id] });
		queryClient.invalidateQueries({ queryKey: ["vehicle"] });
	};
	const addVariant = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("vehicle_variants").insert({
				vehicle_id: vehicle.id,
				name: "New variant",
				price: vehicle.price_from,
				specs: {},
				is_available: true,
				sort_order: data?.length ?? 0
			});
			if (error) throw new Error(error.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-4 rounded-lg border border-border bg-secondary/40 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground",
					children: ["Variants of ", vehicle.name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => addVariant.mutate(),
					disabled: addVariant.isPending,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add variant"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full rounded-lg" }),
			(data ?? []).map((variant) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantCard, {
				variant,
				onChanged: invalidate
			}, variant.id)),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No variants yet. Add one to set variant prices, specifications and colours."
			})
		]
	});
}
function VariantCard({ variant, onChanged }) {
	const [name, setName] = (0, import_react.useState)(variant.name);
	const [price, setPrice] = (0, import_react.useState)(variant.ex_showroom_price == null ? "" : String(variant.ex_showroom_price));
	const [onRoad, setOnRoad] = (0, import_react.useState)(variant.on_road_price == null ? "" : String(variant.on_road_price));
	const [emi, setEmi] = (0, import_react.useState)(variant.emi_options.map((option) => ({
		months: String(option.months),
		rate: String(option.rate)
	})));
	const [specs, setSpecs] = (0, import_react.useState)(specsToText(variant.specs));
	const [available, setAvailable] = (0, import_react.useState)(variant.is_available);
	const [error, setError] = (0, import_react.useState)(null);
	const setEmiField = (index, key, value) => setEmi(emi.map((row, i) => i === index ? {
		...row,
		[key]: value
	} : row));
	const moveEmi = (index, direction) => {
		const target = index + direction;
		if (target < 0 || target >= emi.length) return;
		const next = [...emi];
		const [row] = next.splice(index, 1);
		next.splice(target, 0, row);
		setEmi(next);
	};
	const save = useMutation({
		mutationFn: async () => {
			const emiOptions = emi.map((row) => ({
				months: Number(row.months) || 0,
				rate: Number(row.rate) || 0
			})).filter((row) => row.months > 0);
			const exShowroom = price ? Number(price) : null;
			const { error: e } = await supabase.from("vehicle_variants").update({
				name,
				price: exShowroom,
				ex_showroom_price: exShowroom,
				on_road_price: onRoad ? Number(onRoad) : null,
				emi_options: emiOptions,
				specs: parseSpecs(specs),
				is_available: available
			}).eq("id", variant.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: () => {
			setError(null);
			onChanged();
		},
		onError: (e) => setError(e.message)
	});
	const remove = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("vehicle_variants").delete().eq("id", variant.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	const addColour = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("variant_colours").insert({
				variant_id: variant.id,
				name: "New colour",
				images: [],
				sort_order: variant.colours.length
			});
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vname-${variant.id}`,
							children: "Variant name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vname-${variant.id}`,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Standard, Deluxe, DLX…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vprice-${variant.id}`,
							children: "Ex-showroom price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vprice-${variant.id}`,
							inputMode: "numeric",
							value: price,
							onChange: (e) => setPrice(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vonroad-${variant.id}`,
							children: "On-road price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vonroad-${variant.id}`,
							inputMode: "numeric",
							value: onRoad,
							onChange: (e) => setOnRoad(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 sm:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "EMI settings — loan tenures and interest rates" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									variant: "outline",
									onClick: () => setEmi([...emi, {
										months: "12",
										rate: "9.5"
									}]),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add tenure"]
								})]
							}),
							emi.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28 space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Months"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "numeric",
											value: row.months,
											onChange: (e) => setEmiField(index, "months", e.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28 space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Interest %"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "decimal",
											value: row.rate,
											onChange: (e) => setEmiField(index, "rate", e.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Move up",
										onClick: () => moveEmi(index, -1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Move down",
										onClick: () => moveEmi(index, 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Remove tenure",
										onClick: () => setEmi(emi.filter((_, i) => i !== index)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								]
							}, index)),
							emi.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No tenure options yet. Add one, e.g. 12 months at 9.5%."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Visitors pick a tenure on the model page; the interest rate you set here is applied automatically and cannot be changed by them."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vspecs-${variant.id}`,
							children: "Specifications (one per line, e.g. Engine: 110 cc)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: `vspecs-${variant.id}`,
							rows: 5,
							value: specs,
							onChange: (e) => setSpecs(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: `vavail-${variant.id}`,
							checked: available,
							onCheckedChange: setAvailable
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vavail-${variant.id}`,
							children: "Available at showroom"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => save.mutate(),
						disabled: save.isPending,
						children: save.isPending ? "Saving…" : "Save variant"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => addColour.mutate(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add colour"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							if (window.confirm(`Delete variant “${variant.name}” and its colours?`)) remove.mutate();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete variant"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground",
						children: "Colours"
					}),
					variant.colours.map((colour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColourCard, {
						colour,
						onChanged
					}, colour.id)),
					variant.colours.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No colours yet for this variant. Use “Add colour”."
					})
				]
			})
		]
	});
}
function ColourCard({ colour, onChanged }) {
	const [name, setName] = (0, import_react.useState)(colour.name);
	const [images, setImages] = (0, import_react.useState)(colour.images);
	const save = useMutation({
		mutationFn: async (next) => {
			const { error: e } = await supabase.from("variant_colours").update({
				name,
				images: next ?? images
			}).eq("id", colour.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	const remove = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("variant_colours").delete().eq("id", colour.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-lg border border-border bg-background p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-48 flex-1 space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: `cname-${colour.id}`,
						children: "Colour name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: `cname-${colour.id}`,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Pearl White"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => save.mutate(void 0),
					disabled: save.isPending,
					children: save.isPending ? "Saving…" : "Save colour"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => {
						if (window.confirm(`Delete colour “${colour.name}”?`)) remove.mutate();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
			label: "Gallery images for this colour",
			hint: "Shown when a visitor selects this variant and colour.",
			images,
			folder: "variants",
			onChange: (next) => {
				setImages(next);
				save.mutate(next);
			}
		})]
	});
}
//#endregion
export { AdminVehicles as component };
