import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as ProductCategoryPage } from "./product-category-page-vzCWckyV.mjs";
import { t as DESCRIPTION } from "./products.lubes-Co5uoGr8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.lubes-CWcxC24H.js
var import_jsx_runtime = require_jsx_runtime();
var lubes_chemicals_default = "/assets/lubes-chemicals-BRqesYht.jpg";
function LubesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCategoryPage, {
		eyebrow: "Care for your Honda",
		title: "Genuine Lubes & Chemicals",
		description: DESCRIPTION,
		image: lubes_chemicals_default,
		imageAlt: "Engine oils and maintenance products in a two-wheeler workshop",
		features: [
			{
				title: "Engine oils",
				description: "Select the recommended grade for smooth performance, protection and dependable daily riding."
			},
			{
				title: "Maintenance chemicals",
				description: "Specialist cleaners, lubricants and care products help protect important parts over time."
			},
			{
				title: "Service guidance",
				description: "Our service team can recommend the right product and replacement interval for your model."
			}
		],
		note: "Demo content for development. Product suitability, pack sizes, specifications and stock will be confirmed by the showroom service team."
	});
}
//#endregion
export { LubesPage as component };
