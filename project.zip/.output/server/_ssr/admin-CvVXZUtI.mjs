import { n as __toESM } from "../_runtime.mjs";
import { n as SHOWROOM } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { _ as useRouter, d as Outlet, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Bike, j as BadgePercent, o as ShieldCheck, v as LogOut, x as Inbox, y as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-4t218RNL.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { a as useQueryClient } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CvVXZUtI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useAdminAuth() {
	const [session, setSession] = (0, import_react.useState)(null);
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let active = true;
		const check = async (next) => {
			if (!active) return;
			setSession(next);
			if (!next) {
				setIsAdmin(false);
				setLoading(false);
				return;
			}
			const { data } = await supabase.from("user_roles").select("role").eq("user_id", next.user.id).eq("role", "admin").maybeSingle();
			if (!active) return;
			setIsAdmin(Boolean(data));
			setLoading(false);
		};
		supabase.auth.getSession().then(({ data }) => check(data.session));
		const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
			check(next);
		});
		return () => {
			active = false;
			sub.subscription.unsubscribe();
		};
	}, []);
	const refreshRole = async () => {
		const { data: sessionData } = await supabase.auth.getSession();
		const uid = sessionData.session?.user.id;
		if (!uid) return;
		const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid).eq("role", "admin").maybeSingle();
		setIsAdmin(Boolean(data));
	};
	return {
		session,
		isAdmin,
		loading,
		refreshRole
	};
}
var NAV = [
	{
		to: "/admin",
		label: "Dashboard",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/admin/vehicles",
		label: "Vehicles",
		icon: Bike,
		exact: false
	},
	{
		to: "/admin/offers",
		label: "Offers",
		icon: BadgePercent,
		exact: false
	},
	{
		to: "/admin/enquiries",
		label: "Enquiries",
		icon: Inbox,
		exact: false
	}
];
function AdminLayout() {
	const { session, isAdmin, loading, refreshRole } = useAdminAuth();
	const queryClient = useQueryClient();
	const router = useRouter();
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center text-sm text-muted-foreground",
		children: "Checking your access…"
	});
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginCard, {});
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimAccessCard, {
		email: session.user.email ?? "",
		onClaimed: refreshRole
	});
	const signOut = async () => {
		await queryClient.cancelQueries();
		queryClient.clear();
		await supabase.auth.signOut();
		router.navigate({
			to: "/",
			replace: true
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "bg-ink text-ink-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page flex h-16 items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display text-xl font-bold uppercase tracking-wide",
					children: [
						SHOWROOM.name,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "Admin"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs opacity-70 sm:inline",
						children: session.user.email
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: signOut,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {}), " Sign out"]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "border-t border-white/10",
				"aria-label": "Admin navigation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "container-page flex gap-1 overflow-x-auto",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						activeOptions: { exact: item.exact },
						activeProps: { className: "border-primary text-ink-foreground" },
						className: "flex shrink-0 items-center gap-2 border-b-2 border-transparent px-4 py-3 font-display text-sm font-semibold uppercase tracking-wide opacity-90 hover:text-primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }),
							" ",
							item.label
						]
					}, item.to))
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "container-page py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		})]
	});
}
function AuthShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-secondary px-5 py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-11 items-center justify-center rounded-lg bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
			}), children]
		})
	});
}
function LoginCard() {
	const [mode, setMode] = (0, import_react.useState)("signin");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const submit = async (event) => {
		event.preventDefault();
		setError(null);
		setNotice(null);
		setBusy(true);
		if (mode === "signin") {
			const { error: signInError } = await supabase.auth.signInWithPassword({
				email,
				password
			});
			if (signInError) setError(signInError.message);
		} else {
			const { data, error: signUpError } = await supabase.auth.signUp({
				email,
				password,
				options: { emailRedirectTo: `${window.location.origin}/admin` }
			});
			if (signUpError) setError(signUpError.message);
			else if (!data.session) setNotice("Account created. Confirm your email address, then sign in here.");
		}
		setBusy(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-5 font-display text-3xl font-bold uppercase tracking-wide",
			children: mode === "signin" ? "Staff sign in" : "Create staff account"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: [
				"This area is for ",
				SHOWROOM.name,
				" staff only. Website visitors do not need an account."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-6 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "email",
						children: "Work email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						type: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value),
						autoComplete: "email",
						className: "h-12"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "password",
						children: "Password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "password",
						type: "password",
						required: true,
						minLength: 8,
						value: password,
						onChange: (e) => setPassword(e.target.value),
						autoComplete: mode === "signin" ? "current-password" : "new-password",
						className: "h-12"
					})]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
					children: error
				}),
				notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-md bg-success/10 p-3 text-sm text-success",
					children: notice
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					className: "w-full",
					disabled: busy,
					children: busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => {
				setMode(mode === "signin" ? "signup" : "signin");
				setError(null);
				setNotice(null);
			},
			className: "mt-5 text-sm font-semibold text-primary hover:underline",
			children: mode === "signin" ? "First time here? Create a staff account" : "Already have an account? Sign in"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-6 block text-sm text-muted-foreground hover:text-primary",
			children: "← Back to website"
		})
	] });
}
function ClaimAccessCard({ email, onClaimed }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	const claim = async () => {
		setBusy(true);
		setMessage(null);
		const { data, error } = await supabase.rpc("claim_admin");
		if (error) setMessage(error.message);
		else if (data) onClaimed();
		else setMessage("An administrator already exists. Ask them to grant you access.");
		setBusy(false);
	};
	const signOut = async () => {
		await supabase.auth.signOut();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-5 font-display text-3xl font-bold uppercase tracking-wide",
			children: "Access required"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: [
				"You are signed in as ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: email }),
				" but this account is not an administrator yet. If this is the showroom's first staff account, claim admin access below."
			]
		}),
		message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 rounded-md bg-muted p-3 text-sm text-muted-foreground",
			children: message
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-6 w-full",
			size: "lg",
			onClick: claim,
			disabled: busy,
			children: busy ? "Checking…" : "Claim admin access"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			className: "mt-3 w-full",
			onClick: signOut,
			children: "Sign out"
		})
	] });
}
//#endregion
export { AdminLayout as component };
