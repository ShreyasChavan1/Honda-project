import { i as formatPrice, r as categoryLabel } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as AvailabilityBadge } from "./availability-badge-BdM1dhm1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicle-card-CIT_BFlq.js
var import_jsx_runtime = require_jsx_runtime();
function VehicleCard({ vehicle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lift",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/vehicles/$slug",
			params: { slug: vehicle.slug },
			className: "relative block aspect-4/3 overflow-hidden bg-secondary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: vehicle.image_url,
				alt: `Honda ${vehicle.name} ${categoryLabel(vehicle.category).toLowerCase()}`,
				loading: "lazy",
				width: 1200,
				height: 900,
				className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute left-3 top-3 rounded-full bg-ink/85 px-2.5 py-1 font-display text-xs font-semibold uppercase tracking-wide text-ink-foreground",
				children: categoryLabel(vehicle.category)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-3 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-start justify-between gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl font-bold uppercase leading-none tracking-wide",
						children: vehicle.name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityBadge, {
					available: vehicle.is_available,
					className: "self-start"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-2 text-sm text-muted-foreground",
					children: vehicle.short_description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex items-end justify-between gap-3 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
						children: "Starting from"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-bold",
						children: formatPrice(vehicle.price_from)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/vehicles/$slug",
							params: { slug: vehicle.slug },
							children: ["View Details ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})]
				})
			]
		})]
	});
}
//#endregion
export { VehicleCard as t };
