import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { c as Plus, f as Pencil, r as Trash2 } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-4t218RNL.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { i as offersQuery } from "./catalogue-CvvAtD1R.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { t as Switch } from "./switch-CCza_WcE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.offers--j4V7k8B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY = {
	title: "",
	description: "",
	applicable_vehicles: "",
	benefit: "",
	valid_until: "",
	is_active: true,
	sort_order: "0"
};
var toDraft = (offer) => ({
	id: offer.id,
	title: offer.title,
	description: offer.description,
	applicable_vehicles: offer.applicable_vehicles,
	benefit: offer.benefit,
	valid_until: offer.valid_until ?? "",
	is_active: offer.is_active,
	sort_order: String(offer.sort_order)
});
function AdminOffers() {
	const { data, isLoading, isError } = useQuery(offersQuery);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const queryClient = useQueryClient();
	const invalidate = () => queryClient.invalidateQueries({ queryKey: ["offers"] });
	const save = useMutation({
		mutationFn: async (values) => {
			const payload = {
				title: values.title,
				description: values.description,
				applicable_vehicles: values.applicable_vehicles,
				benefit: values.benefit,
				valid_until: values.valid_until || null,
				is_active: values.is_active,
				sort_order: Number(values.sort_order) || 0
			};
			const { error: saveError } = await (values.id ? supabase.from("offers").update(payload).eq("id", values.id) : supabase.from("offers").insert(payload));
			if (saveError) throw new Error(saveError.message);
		},
		onSuccess: () => {
			setDraft(null);
			setError(null);
			invalidate();
		},
		onError: (e) => setError(e.message)
	});
	const toggleActive = useMutation({
		mutationFn: async (offer) => {
			const { error: e } = await supabase.from("offers").update({ is_active: !offer.is_active }).eq("id", offer.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: () => void invalidate()
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error: e } = await supabase.from("offers").delete().eq("id", id);
			if (e) throw new Error(e.message);
		},
		onSuccess: () => void invalidate()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-bold uppercase tracking-tight",
					children: "Offers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Create promotions and switch them on or off for the public website."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setDraft({ ...EMPTY }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add offer"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-52 w-full rounded-xl" }),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-muted-foreground",
				children: "Could not load offers. Please refresh the page."
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => {
					event.preventDefault();
					save.mutate(draft);
				},
				className: "space-y-4 rounded-xl border border-primary/40 bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-bold uppercase tracking-wide",
						children: draft.id ? "Edit offer" : "Add an offer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "title",
									children: "Offer title"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "title",
									required: true,
									value: draft.title,
									onChange: (e) => setDraft({
										...draft,
										title: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "description",
									children: "Short description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "description",
									rows: 3,
									value: draft.description,
									onChange: (e) => setDraft({
										...draft,
										description: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "vehicles",
									children: "Applicable vehicles"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "vehicles",
									placeholder: "Activa 6G, Dio",
									value: draft.applicable_vehicles,
									onChange: (e) => setDraft({
										...draft,
										applicable_vehicles: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "benefit",
									children: "Benefit / discount"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "benefit",
									placeholder: "Up to ₹5,000 benefits",
									value: draft.benefit,
									onChange: (e) => setDraft({
										...draft,
										benefit: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "valid",
									children: "Valid until"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "valid",
									type: "date",
									value: draft.valid_until,
									onChange: (e) => setDraft({
										...draft,
										valid_until: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "order",
									children: "Display order"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "order",
									inputMode: "numeric",
									value: draft.sort_order,
									onChange: (e) => setDraft({
										...draft,
										sort_order: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									id: "active",
									checked: draft.is_active,
									onCheckedChange: (checked) => setDraft({
										...draft,
										is_active: checked
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "active",
									children: "Show on website"
								})]
							})
						]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: save.isPending,
							children: save.isPending ? "Saving…" : "Save offer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => {
								setDraft(null);
								setError(null);
							},
							children: "Cancel"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: (data ?? []).map((offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center gap-4 rounded-xl border border-border bg-card p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-48 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-bold uppercase tracking-wide",
							children: offer.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								offer.benefit || "No benefit set",
								" · ",
								offer.applicable_vehicles || "Selected models",
								offer.valid_until ? ` · until ${offer.valid_until}` : ""
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 pr-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									id: `active-${offer.id}`,
									checked: offer.is_active,
									onCheckedChange: () => toggleActive.mutate(offer)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `active-${offer.id}`,
									className: "text-xs",
									children: "Active"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setDraft(toDraft(offer)),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Edit"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									if (window.confirm(`Delete the offer “${offer.title}”?`)) remove.mutate(offer.id);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
							})
						]
					})]
				}, offer.id))
			}),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-card p-8 text-sm text-muted-foreground",
				children: "No offers yet. Add your first promotion to show it on the website."
			})
		]
	});
}
//#endregion
export { AdminOffers as component };
