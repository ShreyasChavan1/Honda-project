import { r as __toESM } from "../_runtime.mjs";
import { i as formatPrice, r as categoryLabel, t as CATEGORIES } from "./showroom-CqPng2Ay.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { E as FileSpreadsheet, F as ArrowUp, R as ArrowDown, S as Layers, a as Trash2, i as TriangleAlert, m as Pencil, r as Upload, t as X, u as Plus, w as ImagePlus } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-DsxaCInS.mjs";
import { n as Label, t as Input } from "./label-CmIE8x5o.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Skeleton } from "./skeleton-wE5XVTSu.mjs";
import { a as variantsQuery, s as vehiclesQuery } from "./catalogue-DhpYB_2x.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { t as Switch } from "./switch-CCza_WcE.mjs";
import { n as parseSpecs } from "./admin.vehicles-BEMghX9P.mjs";
import { t as AvailabilityBadge } from "./availability-badge-BdM1dhm1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.vehicles-DTfkZHIC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VEHICLE_BUCKET = "vehicle-images";
/** ~10 years, so stored URLs stay valid for the life of the listing. */
var SIGNED_URL_TTL = 3600 * 24 * 365 * 10;
var extensionOf = (name) => {
	const parts = name.split(".");
	return parts.length > 1 ? parts.pop().toLowerCase() : "jpg";
};
/** Largest stored width; taller/wider originals are scaled down proportionally. */
var MAX_WIDTH = 1600;
var WEBP_QUALITY = .82;
var supportsWebp = () => {
	try {
		return document.createElement("canvas").toDataURL("image/webp").startsWith("data:image/webp");
	} catch {
		return false;
	}
};
/**
* Resizes to at most MAX_WIDTH and re-encodes as WebP. Falls back to the
* original file whenever the browser can't decode/encode it (e.g. SVG, HEIC).
*/
async function optimiseImage(file) {
	const fallback = {
		blob: file,
		extension: extensionOf(file.name)
	};
	if (typeof document === "undefined" || !file.type.startsWith("image/")) return fallback;
	if (file.type === "image/svg+xml" || file.type === "image/gif" || !supportsWebp()) return fallback;
	try {
		const bitmap = await createImageBitmap(file);
		const scale = Math.min(1, MAX_WIDTH / bitmap.width);
		const width = Math.max(1, Math.round(bitmap.width * scale));
		const height = Math.max(1, Math.round(bitmap.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const context = canvas.getContext("2d");
		if (!context) return fallback;
		context.drawImage(bitmap, 0, 0, width, height);
		bitmap.close?.();
		const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", WEBP_QUALITY));
		if (!blob || blob.size === 0) return fallback;
		return {
			blob,
			extension: "webp"
		};
	} catch {
		return fallback;
	}
}
/**
* Uploads one image to Cloud storage and returns a long-lived URL that can be
* stored in the database and rendered directly in an <img> tag.
*/
async function uploadVehicleImage(file, folder = "vehicles") {
	const { blob, extension } = await optimiseImage(file);
	const path = `${folder}/${crypto.randomUUID()}.${extension}`;
	const { error } = await supabase.storage.from(VEHICLE_BUCKET).upload(path, blob, {
		cacheControl: "31536000",
		contentType: blob.type || file.type || "image/webp",
		upsert: false
	});
	if (error) throw new Error(error.message);
	const { data, error: signError } = await supabase.storage.from(VEHICLE_BUCKET).createSignedUrl(path, SIGNED_URL_TTL);
	if (signError || !data) throw new Error(signError?.message ?? "Could not create image URL");
	return data.signedUrl;
}
async function uploadVehicleImages(files, folder = "vehicles") {
	const urls = [];
	for (const file of files) urls.push(await uploadVehicleImage(file, folder));
	return urls;
}
/**
* Reusable uploader used across the admin panel: multiple images, preview grid,
* remove, and add more later. Values are stored URLs.
*/
function ImageManager({ label, hint, images, onChange, folder = "vehicles" }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const handleFiles = async (files) => {
		if (!files || files.length === 0) return;
		setBusy(true);
		setError(null);
		try {
			const uploaded = await uploadVehicleImages(Array.from(files), folder);
			onChange([...images, ...uploaded]);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Upload failed");
		} finally {
			setBusy(false);
			if (inputRef.current) inputRef.current.value = "";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					disabled: busy,
					onClick: () => inputRef.current?.click(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}),
						" ",
						busy ? "Uploading…" : "Upload images"
					]
				})]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*",
				multiple: true,
				className: "hidden",
				onChange: (event) => void handleFiles(event.target.files)
			}),
			images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-3",
				children: images.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative h-20 w-28 overflow-hidden rounded-lg border border-border bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "",
						className: "h-full w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Remove image",
						onClick: () => onChange(images.filter((_, i) => i !== index)),
						className: "absolute right-1 top-1 rounded-full bg-background/90 p-1 text-foreground shadow-card hover:bg-destructive hover:text-destructive-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, `${image}-${index}`))
			}),
			images.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-dashed border-border p-4 text-xs text-muted-foreground",
				children: "No images yet."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var HEADER_ALIASES = {
	category: "category",
	model: "model",
	variant: "variant",
	"reference ex-showroom": "referenceExShowroom",
	"reference exshowroom": "referenceExShowroom",
	"on-road price": "onRoadPrice",
	"on road price": "onRoadPrice",
	colours: "colours",
	colors: "colours",
	"variant specs": "variantSpecs",
	specs: "variantSpecs",
	"key features": "keyFeatures",
	features: "keyFeatures",
	availability: "availability",
	source: "source"
};
/** Maps raw sheet_to_json rows (keyed by header text) onto our fixed field names. */
function normaliseRows(rawRows) {
	return rawRows.map((raw) => {
		const out = {};
		for (const [key, value] of Object.entries(raw)) {
			const field = HEADER_ALIASES[key.trim().toLowerCase().replace(/\s+/g, " ")];
			if (field) out[field] = String(value ?? "").trim();
		}
		return {
			category: out.category ?? "",
			model: out.model ?? "",
			variant: out.variant ?? "",
			referenceExShowroom: out.referenceExShowroom ?? "",
			onRoadPrice: out.onRoadPrice ?? "",
			colours: out.colours ?? "",
			variantSpecs: out.variantSpecs ?? "",
			keyFeatures: out.keyFeatures ?? "",
			availability: out.availability ?? "",
			source: out.source ?? ""
		};
	});
}
var slugifyModel = (value) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
/** Same "Key: Value" per line format used by the manual variant specs textarea. */
function parseSpecsBlock(value) {
	const specs = {};
	for (const line of value.split("\n")) {
		const index = line.indexOf(":");
		if (index === -1) continue;
		const key = line.slice(0, index).trim();
		const val = line.slice(index + 1).trim();
		if (key) specs[key] = val;
	}
	return specs;
}
/** Splits on ";" when present (colour names occasionally contain commas), else on ",". */
function splitList(value) {
	if (!value.trim()) return [];
	return (value.includes(";") ? value.split(";") : value.split(",")).map((p) => p.trim()).filter(Boolean);
}
/** Extracts every ₹-prefixed amount in a string, e.g. "₹83,080 / ₹85,878 reference" → [83080, 85878]. */
function parsePrices(value) {
	return [...value.matchAll(/₹\s*([\d,]+)/g)].map((m) => Number(m[1].replace(/,/g, ""))).filter((n) => Number.isFinite(n) && n > 0);
}
/** A single plain or ₹-prefixed number, for the On-road Price column. Returns null for placeholders like "MANUAL" or "TBA". */
function parseSingleNumber(value) {
	const nums = parsePrices(value);
	if (nums.length > 0) return nums[0];
	const bare = value.replace(/,/g, "").trim();
	if (/^\d+(\.\d+)?$/.test(bare)) return Number(bare);
	return null;
}
var UNAVAILABLE_KEYWORDS = [
	"pre-book",
	"prebook",
	"upcoming",
	"tba",
	"sold out",
	"discontinued",
	"not available",
	"out of stock",
	"coming soon"
];
var isAvailableText = (value) => {
	const lower = value.toLowerCase();
	return !UNAVAILABLE_KEYWORDS.some((keyword) => lower.includes(keyword));
};
/**
* Groups rows by Model (→ vehicle), validates them, and resolves the
* "Reference Ex-showroom" column's multi-price format (e.g. "₹83,080 /
* ₹85,878 reference") positionally across the variant rows that share it.
*/
function parseVariantDataRows(rows) {
	const rowErrors = [];
	const order = [];
	const groupsBySlug = /* @__PURE__ */ new Map();
	rows.forEach((row, index) => {
		const rowNumber = index + 2;
		const model = row.model.trim();
		const variantName = row.variant.trim();
		if (!model) {
			rowErrors.push({
				row: rowNumber,
				message: "Missing Model — row skipped"
			});
			return;
		}
		if (!variantName) {
			rowErrors.push({
				row: rowNumber,
				message: `Missing Variant for "${model}" — row skipped`
			});
			return;
		}
		const slug = slugifyModel(model);
		if (!slug) {
			rowErrors.push({
				row: rowNumber,
				message: `Could not derive a web address from "${model}" — row skipped`
			});
			return;
		}
		if (!groupsBySlug.has(slug)) {
			groupsBySlug.set(slug, {
				name: model,
				category: row.category.trim(),
				rows: []
			});
			order.push(slug);
		}
		groupsBySlug.get(slug).rows.push({
			row,
			rowNumber
		});
	});
	return {
		groups: order.map((slug) => {
			const group = groupsBySlug.get(slug);
			const warnings = [];
			const total = group.rows.length;
			const variants = group.rows.map(({ row, rowNumber }, index) => {
				const rowWarnings = [];
				const nums = parsePrices(row.referenceExShowroom);
				let price = null;
				if (nums.length === 0) {
					if (row.referenceExShowroom.trim()) rowWarnings.push("No ₹ reference price recognised — price left blank");
				} else if (nums.length === 1) price = nums[0];
				else if (nums.length === total) price = nums[index];
				else {
					price = nums[Math.min(index, nums.length - 1)];
					rowWarnings.push(`Reference price lists ${nums.length} amount(s) for ${total} variant row(s) of "${group.name}" — verify this price manually`);
				}
				const onRoadPrice = parseSingleNumber(row.onRoadPrice);
				const specs = parseSpecsBlock(row.variantSpecs);
				if (row.keyFeatures.trim()) specs["Key Features"] = splitList(row.keyFeatures).join("; ");
				return {
					rowNumber,
					name: row.variant.trim(),
					price,
					onRoadPrice,
					specs,
					colours: splitList(row.colours),
					isAvailable: row.availability.trim() ? isAvailableText(row.availability) : true,
					warnings: rowWarnings
				};
			});
			const byName = /* @__PURE__ */ new Map();
			for (const variant of variants) {
				const key = variant.name.toLowerCase();
				if (byName.has(key)) warnings.push(`Duplicate variant "${variant.name}" in the sheet for "${group.name}" — using the last row (row ${variant.rowNumber})`);
				byName.set(key, variant);
			}
			const category = group.category ? group.category.toLowerCase() : "scooter";
			if (category !== "scooter" && category !== "motorcycle" && category !== "ev") warnings.push(`Unrecognised category "${group.category}" — imported as-is; it won't appear in the category filter on the website`);
			return {
				slug,
				name: group.name,
				category,
				variants: [...byName.values()],
				warnings
			};
		}),
		rowErrors
	};
}
function buildImportPlan(groups, rowErrors, existingVehicles, existingVariantsBySlug) {
	const existingBySlug = new Map(existingVehicles.map((v) => [v.slug, v]));
	return {
		vehicles: groups.map((group) => {
			const existingVehicle = existingBySlug.get(group.slug);
			const existingVariants = existingVariantsBySlug.get(group.slug) ?? [];
			const existingVariantByName = new Map(existingVariants.map((v) => [v.name.trim().toLowerCase(), v]));
			const prices = group.variants.map((v) => v.price).filter((p) => p != null);
			const priceFrom = prices.length > 0 ? Math.min(...prices) : existingVehicle?.price_from ?? null;
			const isAvailable = group.variants.some((v) => v.isAvailable);
			const variants = group.variants.map((variant) => {
				const existing = existingVariantByName.get(variant.name.trim().toLowerCase());
				const existingColourNames = new Set((existing?.colours ?? []).map((c) => c.name.trim().toLowerCase()));
				const colours = variant.colours.map((name) => ({
					name,
					status: existingColourNames.has(name.trim().toLowerCase()) ? "existing" : "new"
				}));
				return {
					status: existing ? "update" : "create",
					existingId: existing?.id,
					name: variant.name,
					price: variant.price,
					onRoadPrice: variant.onRoadPrice,
					specs: variant.specs,
					isAvailable: variant.isAvailable,
					colours,
					warnings: variant.warnings
				};
			});
			return {
				slug: group.slug,
				status: existingVehicle ? "update" : "create",
				existingId: existingVehicle?.id,
				name: group.name,
				category: group.category,
				priceFrom,
				isAvailable,
				variants,
				warnings: group.warnings
			};
		}),
		rowErrors
	};
}
var DEFAULT_EMI_OPTIONS = [
	{
		months: 12,
		rate: 9.5
	},
	{
		months: 24,
		rate: 10
	},
	{
		months: 36,
		rate: 10.5
	},
	{
		months: 48,
		rate: 11
	}
];
async function executeImportPlan(plan, existingVehicleCount) {
	const result = {
		vehiclesCreated: 0,
		vehiclesUpdated: 0,
		variantsCreated: 0,
		variantsUpdated: 0,
		coloursCreated: 0,
		errors: []
	};
	const vehicleIdBySlug = /* @__PURE__ */ new Map();
	const toCreate = plan.vehicles.filter((v) => v.status === "create");
	const toUpdate = plan.vehicles.filter((v) => v.status === "update");
	if (toCreate.length > 0) {
		const rows = toCreate.map((v, i) => ({
			slug: v.slug,
			name: v.name,
			category: v.category,
			price_from: v.priceFrom,
			is_available: v.isAvailable,
			sort_order: existingVehicleCount + i
		}));
		const { data, error } = await supabase.from("vehicles").insert(rows).select("id, slug");
		if (error) result.errors.push(`Could not create vehicles: ${error.message}`);
		else {
			for (const row of data ?? []) vehicleIdBySlug.set(row.slug, row.id);
			result.vehiclesCreated += data?.length ?? 0;
		}
	}
	await Promise.all(toUpdate.map(async (v) => {
		if (!v.existingId) return;
		vehicleIdBySlug.set(v.slug, v.existingId);
		const payload = {
			name: v.name,
			category: v.category,
			is_available: v.isAvailable
		};
		if (v.priceFrom != null) payload.price_from = v.priceFrom;
		const { error } = await supabase.from("vehicles").update(payload).eq("id", v.existingId);
		if (error) result.errors.push(`Could not update "${v.name}": ${error.message}`);
		else result.vehiclesUpdated += 1;
	}));
	const newVariantRows = [];
	const newVariantMeta = [];
	const updateVariantJobs = [];
	for (const vehicle of plan.vehicles) {
		const vehicleId = vehicleIdBySlug.get(vehicle.slug);
		if (!vehicleId) continue;
		let nextSortOrder = 0;
		for (const variant of vehicle.variants) {
			const newColours = variant.colours.filter((c) => c.status === "new").map((c) => c.name);
			if (variant.status === "create") {
				newVariantRows.push({
					vehicle_id: vehicleId,
					name: variant.name,
					price: variant.price,
					ex_showroom_price: variant.price,
					on_road_price: variant.onRoadPrice,
					specs: variant.specs,
					is_available: variant.isAvailable,
					sort_order: nextSortOrder++,
					emi_options: DEFAULT_EMI_OPTIONS
				});
				newVariantMeta.push({
					slug: vehicle.slug,
					name: variant.name,
					colours: newColours
				});
			} else if (variant.existingId) {
				const existingId = variant.existingId;
				updateVariantJobs.push(async () => {
					const payload = { is_available: variant.isAvailable };
					if (variant.price != null) {
						payload.price = variant.price;
						payload.ex_showroom_price = variant.price;
					}
					if (variant.onRoadPrice != null) payload.on_road_price = variant.onRoadPrice;
					if (Object.keys(variant.specs).length > 0) payload.specs = variant.specs;
					const { error } = await supabase.from("vehicle_variants").update(payload).eq("id", existingId);
					if (error) return {
						id: existingId,
						colours: newColours,
						error: error.message
					};
					return {
						id: existingId,
						colours: newColours
					};
				});
			}
		}
	}
	const newColourRows = [];
	if (newVariantRows.length > 0) {
		const { data, error } = await supabase.from("vehicle_variants").insert(newVariantRows).select("id, vehicle_id, name");
		if (error) result.errors.push(`Could not create variants: ${error.message}`);
		else {
			result.variantsCreated += data?.length ?? 0;
			for (const row of data ?? []) newVariantMeta.find((m) => m.name === row.name && vehicleIdBySlug.get(m.slug) === row.vehicle_id)?.colours.forEach((name, i) => {
				newColourRows.push({
					variant_id: row.id,
					name,
					images: [],
					sort_order: i
				});
			});
		}
	}
	if (updateVariantJobs.length > 0) (await Promise.all(updateVariantJobs.map((job) => job()))).forEach((r, i) => {
		if (r.error) result.errors.push(`Could not update a variant: ${r.error}`);
		else {
			result.variantsUpdated += 1;
			r.colours.forEach((name, ci) => {
				newColourRows.push({
					variant_id: r.id,
					name,
					images: [],
					sort_order: 1e3 + i * 100 + ci
				});
			});
		}
	});
	if (newColourRows.length > 0) {
		const { data, error } = await supabase.from("variant_colours").insert(newColourRows).select("id");
		if (error) result.errors.push(`Could not add colours: ${error.message}`);
		else result.coloursCreated += data?.length ?? 0;
	}
	return result;
}
function VehicleBulkImportDialog({ open, onOpenChange, onImported }) {
	const [stage, setStage] = (0, import_react.useState)("pick");
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [plan, setPlan] = (0, import_react.useState)(null);
	const [existingVehicleCount, setExistingVehicleCount] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const fileInput = (0, import_react.useRef)(null);
	const reset = () => {
		setStage("pick");
		setFileName("");
		setPlan(null);
		setError(null);
		setResult(null);
	};
	const close = (next) => {
		if (!next) reset();
		onOpenChange(next);
	};
	const handleFile = async (file) => {
		setFileName(file.name);
		setStage("parsing");
		setError(null);
		try {
			const XLSX = await import("../_libs/xlsx.mjs").then((n) => n.t);
			const buffer = await file.arrayBuffer();
			const workbook = XLSX.read(buffer, { type: "array" });
			const sheetName = workbook.SheetNames.find((n) => n.trim().toLowerCase() === "variant data");
			if (!sheetName) throw new Error("Could not find a \"Variant Data\" sheet in this workbook.");
			const sheet = workbook.Sheets[sheetName];
			const rawRows = XLSX.utils.sheet_to_json(sheet, {
				defval: "",
				raw: false
			});
			if (rawRows.length === 0) throw new Error("The \"Variant Data\" sheet has no rows to import.");
			const { groups, rowErrors } = parseVariantDataRows(normaliseRows(rawRows));
			const slugs = groups.map((g) => g.slug);
			const { data: existingVehicles, error: vehiclesError } = await supabase.from("vehicles").select("id, slug, name, price_from, is_available").in("slug", slugs.length > 0 ? slugs : ["__none__"]);
			if (vehiclesError) throw new Error(vehiclesError.message);
			const { count: totalVehicleCount } = await supabase.from("vehicles").select("id", {
				count: "exact",
				head: true
			});
			const vehicleIds = (existingVehicles ?? []).map((v) => v.id);
			const existingVariantsBySlug = /* @__PURE__ */ new Map();
			if (vehicleIds.length > 0) {
				const { data: existingVariants, error: variantsError } = await supabase.from("vehicle_variants").select("id, vehicle_id, name, variant_colours(id, name)").in("vehicle_id", vehicleIds);
				if (variantsError) throw new Error(variantsError.message);
				const slugByVehicleId = new Map((existingVehicles ?? []).map((v) => [v.id, v.slug]));
				for (const raw of existingVariants ?? []) {
					const vehicleId = raw["vehicle_id"];
					const slug = slugByVehicleId.get(vehicleId);
					if (!slug) continue;
					const list = existingVariantsBySlug.get(slug) ?? [];
					list.push({
						id: raw["id"],
						name: raw["name"],
						colours: (raw["variant_colours"] ?? []).map((c) => ({
							id: c.id,
							name: c.name
						}))
					});
					existingVariantsBySlug.set(slug, list);
				}
			}
			const builtPlan = buildImportPlan(groups, rowErrors, existingVehicles ?? [], existingVariantsBySlug);
			setPlan(builtPlan);
			setExistingVehicleCount(totalVehicleCount ?? 0);
			setStage("preview");
		} catch (e) {
			setError(e instanceof Error ? e.message : "Could not read this file.");
			setStage("pick");
		}
	};
	const confirmImport = async () => {
		if (!plan) return;
		setStage("importing");
		setError(null);
		try {
			const outcome = await executeImportPlan(plan, existingVehicleCount);
			setResult(outcome);
			setStage("done");
			onImported();
		} catch (e) {
			setError(e instanceof Error ? e.message : "Import failed.");
			setStage("preview");
		}
	};
	const vehiclesToCreate = plan?.vehicles.filter((v) => v.status === "create").length ?? 0;
	const vehiclesToUpdate = plan?.vehicles.filter((v) => v.status === "update").length ?? 0;
	const variantsToCreate = plan?.vehicles.flatMap((v) => v.variants).filter((v) => v.status === "create").length ?? 0;
	const variantsToUpdate = plan?.vehicles.flatMap((v) => v.variants).filter((v) => v.status === "update").length ?? 0;
	const totalWarnings = (plan?.vehicles.flatMap((v) => v.warnings).length ?? 0) + (plan?.vehicles.flatMap((v) => v.variants.flatMap((variant) => variant.warnings)).length ?? 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: close,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[85vh] max-w-3xl overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Import vehicles from Excel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Upload the Honda vehicle workbook — the \"Variant Data\" sheet will be parsed and matched against existing vehicles and variants by name." })] }),
				stage === "pick" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileInput,
							type: "file",
							accept: ".xlsx",
							className: "hidden",
							onChange: (e) => {
								const file = e.target.files?.[0];
								if (file) handleFile(file);
								e.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => fileInput.current?.click(),
							className: "flex w-full flex-col items-center gap-2 rounded-xl border-2 border-dashed border-border p-10 text-center transition-colors hover:border-primary/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-8 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-sm font-bold uppercase tracking-wide",
									children: "Choose an .xlsx file"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "Must contain a \"Variant Data\" sheet"
								})
							]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
							children: error
						})
					]
				}),
				stage === "parsing" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: [
						"Reading ",
						fileName,
						"…"
					]
				}),
				stage === "preview" && plan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "secondary",
									children: [vehiclesToCreate, " vehicle(s) to create"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "secondary",
									children: [vehiclesToUpdate, " vehicle(s) to update"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "secondary",
									children: [variantsToCreate, " variant(s) to create"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "secondary",
									children: [variantsToUpdate, " variant(s) to update"]
								}),
								totalWarnings > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									children: [totalWarnings, " warning(s) — review below"]
								}),
								plan.rowErrors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "destructive",
									children: [plan.rowErrors.length, " row(s) skipped"]
								})
							]
						}),
						plan.rowErrors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 rounded-lg border border-destructive/30 bg-destructive/5 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm font-semibold text-destructive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }), " Rows skipped"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "list-disc space-y-0.5 pl-5 text-sm text-muted-foreground",
								children: plan.rowErrors.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"Row ",
									e.row,
									": ",
									e.message
								] }, i))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: plan.vehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border bg-card p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-lg font-bold uppercase tracking-wide",
											children: vehicle.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												vehicle.category,
												" · ",
												vehicle.priceFrom != null ? `From ₹${vehicle.priceFrom.toLocaleString("en-IN")}` : "No reference price"
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: vehicle.status === "create" ? "default" : "secondary",
											children: vehicle.status === "create" ? "New vehicle" : "Update existing"
										})]
									}),
									vehicle.warnings.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 flex items-start gap-1.5 text-xs text-amber-600 dark:text-amber-500",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-3 shrink-0" }),
											" ",
											w
										]
									}, i)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 space-y-2",
										children: vehicle.variants.map((variant) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "rounded-lg border border-border bg-secondary/40 p-3 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-semibold",
														children: variant.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs text-muted-foreground",
															children: variant.price != null ? `₹${variant.price.toLocaleString("en-IN")}` : "No price"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
															variant: variant.status === "create" ? "default" : "secondary",
															children: variant.status === "create" ? "New" : "Update"
														})]
													})]
												}),
												variant.colours.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 text-xs text-muted-foreground",
													children: [
														"Colours:",
														" ",
														variant.colours.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
															c.name,
															c.status === "new" ? " (new)" : "",
															i < variant.colours.length - 1 ? ", " : ""
														] }, c.name))
													]
												}),
												variant.warnings.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 flex items-start gap-1.5 text-xs text-amber-600 dark:text-amber-500",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-3 shrink-0" }),
														" ",
														w
													]
												}, i))
											]
										}, variant.name))
									})
								]
							}, vehicle.slug))
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
							children: error
						})
					]
				}),
				stage === "importing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: "Importing…"
				}),
				stage === "done" && result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Created ",
							result.vehiclesCreated,
							" vehicle(s) and updated ",
							result.vehiclesUpdated,
							". Created",
							" ",
							result.variantsCreated,
							" variant(s) and updated ",
							result.variantsUpdated,
							". Added ",
							result.coloursCreated,
							" ",
							"new colour(s)."
						]
					}), result.errors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 rounded-lg border border-destructive/30 bg-destructive/5 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-destructive",
							children: "Some items could not be saved"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc space-y-0.5 pl-5 text-sm text-muted-foreground",
							children: result.errors.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: e }, i))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [
					stage === "preview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: reset,
						children: "Choose a different file"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void confirmImport(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), " Confirm import"]
					})] }),
					stage === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => close(false),
						children: "Done"
					}),
					(stage === "pick" || stage === "parsing" || stage === "importing") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => close(false),
						disabled: stage === "parsing" || stage === "importing",
						children: "Cancel"
					})
				] })
			]
		})
	});
}
var EMPTY = {
	slug: "",
	name: "",
	category: "scooter",
	short_description: "",
	description: "",
	price_from: "",
	images: [],
	is_available: true,
	is_featured: false,
	sort_order: "0"
};
var toDraft = (vehicle) => ({
	id: vehicle.id,
	slug: vehicle.slug,
	name: vehicle.name,
	category: vehicle.category,
	short_description: vehicle.short_description,
	description: vehicle.description,
	price_from: vehicle.price_from == null ? "" : String(vehicle.price_from),
	images: [vehicle.image_url, ...vehicle.gallery].filter(Boolean),
	is_available: vehicle.is_available,
	is_featured: vehicle.is_featured,
	sort_order: String(vehicle.sort_order)
});
var specsToText = (specs) => Object.entries(specs).map(([key, value]) => `${key}: ${value}`).join("\n");
var slugify = (value) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
function AdminVehicles() {
	const { data, isLoading, isError } = useQuery(vehiclesQuery);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [openVariants, setOpenVariants] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [importOpen, setImportOpen] = (0, import_react.useState)(false);
	const queryClient = useQueryClient();
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["vehicles"] });
		queryClient.invalidateQueries({ queryKey: ["vehicle"] });
	};
	const save = useMutation({
		mutationFn: async (values) => {
			const payload = {
				slug: values.slug || slugify(values.name),
				name: values.name,
				category: values.category,
				short_description: values.short_description,
				description: values.description,
				price_from: values.price_from ? Number(values.price_from) : null,
				image_url: values.images[0] ?? "",
				gallery: values.images.slice(1),
				is_available: values.is_available,
				is_featured: values.is_featured,
				sort_order: Number(values.sort_order) || 0
			};
			const { error: saveError } = await (values.id ? supabase.from("vehicles").update(payload).eq("id", values.id) : supabase.from("vehicles").insert(payload));
			if (saveError) throw new Error(saveError.message);
		},
		onSuccess: () => {
			setDraft(null);
			setError(null);
			invalidate();
		},
		onError: (e) => setError(e.message)
	});
	const toggleAvailability = useMutation({
		mutationFn: async (vehicle) => {
			const { error: e } = await supabase.from("vehicles").update({ is_available: !vehicle.is_available }).eq("id", vehicle.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: invalidate
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error: e } = await supabase.from("vehicles").delete().eq("id", id);
			if (e) throw new Error(e.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-bold uppercase tracking-tight",
					children: "Vehicles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Add models, then manage their variants, colours and gallery images."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setImportOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), " Import from Excel"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setDraft({ ...EMPTY }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add vehicle"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleBulkImportDialog, {
				open: importOpen,
				onOpenChange: setImportOpen,
				onImported: invalidate
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" }),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-muted-foreground",
				children: "Could not load vehicles. Please refresh the page."
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleForm, {
				draft,
				onChange: setDraft,
				onCancel: () => {
					setDraft(null);
					setError(null);
				},
				onSave: () => save.mutate(draft),
				saving: save.isPending,
				error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: (data ?? []).map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: vehicle.image_url,
								alt: vehicle.name,
								loading: "lazy",
								className: "h-20 w-28 rounded-lg object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-40 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl font-bold uppercase tracking-wide",
										children: vehicle.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground",
										children: [
											categoryLabel(vehicle.category),
											" · ",
											formatPrice(vehicle.price_from),
											vehicle.is_featured ? " · Featured" : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityBadge, { available: vehicle.is_available })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 pr-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											id: `available-${vehicle.id}`,
											checked: vehicle.is_available,
											onCheckedChange: () => toggleAvailability.mutate(vehicle)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: `available-${vehicle.id}`,
											className: "text-xs",
											children: "In stock"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: openVariants === vehicle.id ? "default" : "outline",
										onClick: () => setOpenVariants(openVariants === vehicle.id ? null : vehicle.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {}), " Variants"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setDraft(toDraft(vehicle)),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Edit"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (window.confirm(`Delete ${vehicle.name}? This cannot be undone.`)) remove.mutate(vehicle.id);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
									})
								]
							})
						]
					}), openVariants === vehicle.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantsPanel, { vehicle })]
				}, vehicle.id))
			}),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-card p-8 text-sm text-muted-foreground",
				children: "No vehicles yet. Use “Add vehicle” to list your first model."
			})
		]
	});
}
function VehicleForm({ draft, onChange, onCancel, onSave, saving, error }) {
	const set = (key, value) => onChange({
		...draft,
		[key]: value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			onSave();
		},
		className: "space-y-4 rounded-xl border border-primary/40 bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-bold uppercase tracking-wide",
				children: draft.id ? `Edit ${draft.name}` : "Add a vehicle"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "name",
							children: "Model name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "name",
							required: true,
							value: draft.name,
							onChange: (e) => set("name", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "slug",
							children: "Web address (slug)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "slug",
							value: draft.slug,
							placeholder: slugify(draft.name) || "activa-6g",
							onChange: (e) => set("slug", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "category",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "category",
							value: draft.category,
							onChange: (e) => set("category", e.target.value),
							className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
							children: CATEGORIES.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: category.value,
								children: category.label
							}, category.value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "price",
							children: "Starting price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "price",
							inputMode: "numeric",
							value: draft.price_from,
							onChange: (e) => set("price_from", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
							label: "Main vehicle images",
							hint: "The first image is used on cards and as the default gallery image.",
							images: draft.images,
							onChange: (images) => set("images", images)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "short",
							children: "Short description (shown on cards)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "short",
							value: draft.short_description,
							onChange: (e) => set("short_description", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "description",
							children: "Full description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "description",
							rows: 3,
							value: draft.description,
							onChange: (e) => set("description", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "sort",
							children: "Display order"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "sort",
							inputMode: "numeric",
							value: draft.sort_order,
							onChange: (e) => set("sort_order", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								id: "available",
								checked: draft.is_available,
								onCheckedChange: (checked) => set("is_available", checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "available",
								children: "Available at showroom"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								id: "featured",
								checked: draft.is_featured,
								onCheckedChange: (checked) => set("is_featured", checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "featured",
								children: "Featured on home"
							})]
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: saving,
					children: saving ? "Saving…" : "Save vehicle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: onCancel,
					children: "Cancel"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Variants, variant prices, specifications and colour galleries are managed with the “Variants” button on the model below."
			})
		]
	});
}
function VariantsPanel({ vehicle }) {
	const queryClient = useQueryClient();
	const { data, isLoading } = useQuery(variantsQuery(vehicle.id));
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["variants", vehicle.id] });
		queryClient.invalidateQueries({ queryKey: ["vehicle"] });
	};
	const addVariant = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("vehicle_variants").insert({
				vehicle_id: vehicle.id,
				name: "New variant",
				price: vehicle.price_from,
				specs: {},
				is_available: true,
				sort_order: data?.length ?? 0,
				emi_options: [
					{
						months: 12,
						rate: 9.5
					},
					{
						months: 24,
						rate: 10
					},
					{
						months: 36,
						rate: 10.5
					},
					{
						months: 48,
						rate: 11
					}
				]
			});
			if (error) throw new Error(error.message);
		},
		onSuccess: invalidate
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-4 rounded-lg border border-border bg-secondary/40 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground",
					children: ["Variants of ", vehicle.name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => addVariant.mutate(),
					disabled: addVariant.isPending,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add variant"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full rounded-lg" }),
			(data ?? []).map((variant) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantCard, {
				variant,
				onChanged: invalidate
			}, variant.id)),
			!isLoading && (data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No variants yet. Add one to set variant prices, specifications and colours."
			})
		]
	});
}
function VariantCard({ variant, onChanged }) {
	const [name, setName] = (0, import_react.useState)(variant.name);
	const [price, setPrice] = (0, import_react.useState)(variant.ex_showroom_price == null ? "" : String(variant.ex_showroom_price));
	const [onRoad, setOnRoad] = (0, import_react.useState)(variant.on_road_price == null ? "" : String(variant.on_road_price));
	const [emi, setEmi] = (0, import_react.useState)(variant.emi_options.map((option) => ({
		months: String(option.months),
		rate: String(option.rate)
	})));
	const [specs, setSpecs] = (0, import_react.useState)(specsToText(variant.specs));
	const [available, setAvailable] = (0, import_react.useState)(variant.is_available);
	const [error, setError] = (0, import_react.useState)(null);
	const setEmiField = (index, key, value) => setEmi(emi.map((row, i) => i === index ? {
		...row,
		[key]: value
	} : row));
	const moveEmi = (index, direction) => {
		const target = index + direction;
		if (target < 0 || target >= emi.length) return;
		const next = [...emi];
		const [row] = next.splice(index, 1);
		next.splice(target, 0, row);
		setEmi(next);
	};
	const save = useMutation({
		mutationFn: async () => {
			const emiOptions = emi.map((row) => ({
				months: Number(row.months) || 0,
				rate: Number(row.rate) || 0
			})).filter((row) => row.months > 0);
			const exShowroom = price ? Number(price) : null;
			const { error: e } = await supabase.from("vehicle_variants").update({
				name,
				price: exShowroom,
				ex_showroom_price: exShowroom,
				on_road_price: onRoad ? Number(onRoad) : null,
				emi_options: emiOptions,
				specs: parseSpecs(specs),
				is_available: available
			}).eq("id", variant.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: () => {
			setError(null);
			onChanged();
		},
		onError: (e) => setError(e.message)
	});
	const remove = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("vehicle_variants").delete().eq("id", variant.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	const addColour = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("variant_colours").insert({
				variant_id: variant.id,
				name: "New colour",
				images: [],
				sort_order: variant.colours.length
			});
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vname-${variant.id}`,
							children: "Variant name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vname-${variant.id}`,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Standard, Deluxe, DLX…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vprice-${variant.id}`,
							children: "Ex-showroom price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vprice-${variant.id}`,
							inputMode: "numeric",
							value: price,
							onChange: (e) => setPrice(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vonroad-${variant.id}`,
							children: "On-road price (₹)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `vonroad-${variant.id}`,
							inputMode: "numeric",
							value: onRoad,
							onChange: (e) => setOnRoad(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 sm:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "EMI settings — loan tenures and interest rates (add at least 2 so the tenure slider has a range to move across)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									variant: "outline",
									onClick: () => setEmi([...emi, {
										months: "12",
										rate: "9.5"
									}]),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add tenure"]
								})]
							}),
							emi.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28 space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Months"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "numeric",
											value: row.months,
											onChange: (e) => setEmiField(index, "months", e.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28 space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Interest %"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "decimal",
											value: row.rate,
											onChange: (e) => setEmiField(index, "rate", e.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Move up",
										onClick: () => moveEmi(index, -1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Move down",
										onClick: () => moveEmi(index, 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										"aria-label": "Remove tenure",
										onClick: () => setEmi(emi.filter((_, i) => i !== index)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								]
							}, index)),
							emi.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No tenure options yet. Add one, e.g. 12 months at 9.5%."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Visitors pick a tenure on the model page; the interest rate you set here is applied automatically and cannot be changed by them."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vspecs-${variant.id}`,
							children: "Specifications (one per line, e.g. Engine: 110 cc)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: `vspecs-${variant.id}`,
							rows: 5,
							value: specs,
							onChange: (e) => setSpecs(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: `vavail-${variant.id}`,
							checked: available,
							onCheckedChange: setAvailable
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `vavail-${variant.id}`,
							children: "Available at showroom"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 p-3 text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => save.mutate(),
						disabled: save.isPending,
						children: save.isPending ? "Saving…" : "Save variant"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => addColour.mutate(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add colour"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							if (window.confirm(`Delete variant “${variant.name}” and its colours?`)) remove.mutate();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete variant"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground",
						children: "Colours"
					}),
					variant.colours.map((colour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColourCard, {
						colour,
						onChanged
					}, colour.id)),
					variant.colours.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No colours yet for this variant. Use “Add colour”."
					})
				]
			})
		]
	});
}
function ColourCard({ colour, onChanged }) {
	const [name, setName] = (0, import_react.useState)(colour.name);
	const [images, setImages] = (0, import_react.useState)(colour.images);
	const save = useMutation({
		mutationFn: async (next) => {
			const { error: e } = await supabase.from("variant_colours").update({
				name,
				images: next ?? images
			}).eq("id", colour.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	const remove = useMutation({
		mutationFn: async () => {
			const { error: e } = await supabase.from("variant_colours").delete().eq("id", colour.id);
			if (e) throw new Error(e.message);
		},
		onSuccess: onChanged
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-lg border border-border bg-background p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-48 flex-1 space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: `cname-${colour.id}`,
						children: "Colour name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: `cname-${colour.id}`,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Pearl White"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => save.mutate(void 0),
					disabled: save.isPending,
					children: save.isPending ? "Saving…" : "Save colour"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => {
						if (window.confirm(`Delete colour “${colour.name}”?`)) remove.mutate();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Delete"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageManager, {
			label: "Gallery images for this colour",
			hint: "Shown when a visitor selects this variant and colour.",
			images,
			folder: "variants",
			onChange: (next) => {
				setImages(next);
				save.mutate(next);
			}
		})]
	});
}
//#endregion
export { AdminVehicles as component };
