//#region node_modules/.nitro/vite/services/ssr/assets/products.accessories-CZ3i8rd4.js
var DESCRIPTION = "Model-specific Honda two-wheeler accessories, protection and riding essentials, managed by our showroom team.";
//#endregion
export { DESCRIPTION as t };
