import { r as SHOWROOM, t as CATEGORIES } from "./showroom-qI0FNTtp.mjs";
import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles.index-bbclF_OQ.js
var $$splitComponentImporter = () => import("./vehicles.index-C-u931e6.mjs");
var TITLE = `Honda Vehicles & Prices — ${SHOWROOM.name}`;
var DESCRIPTION = "Browse Honda scooters and motorcycles at our showroom, with starting prices, variants and current availability for each model.";
var Route = createFileRoute("/vehicles/")({
	validateSearch: (search) => {
		const category = typeof search["category"] === "string" ? search["category"] : void 0;
		return category && CATEGORIES.some((c) => c.value === category) ? { category } : {};
	},
	head: () => ({ meta: [
		{ title: TITLE },
		{
			name: "description",
			content: DESCRIPTION
		},
		{
			property: "og:title",
			content: TITLE
		},
		{
			property: "og:description",
			content: DESCRIPTION
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
