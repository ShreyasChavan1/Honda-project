import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as ProductListingPage } from "./product-listing-page-B-46-eGv.mjs";
import { t as DESCRIPTION } from "./products.lubes-C0oK6QOi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.lubes-ClqHrX21.js
var import_jsx_runtime = require_jsx_runtime();
var lubes_chemicals_default = "/assets/lubes-chemicals-nhf676ie.jpg";
function LubesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductListingPage, {
		category: "lubes",
		eyebrow: "Care for your Honda",
		title: "Genuine Lubes & Chemicals",
		description: DESCRIPTION,
		image: lubes_chemicals_default,
		imageAlt: "Engine oils and maintenance products in a two-wheeler workshop",
		note: "Product suitability, pack sizes and stock will be confirmed by the showroom service team."
	});
}
//#endregion
export { LubesPage as component };
