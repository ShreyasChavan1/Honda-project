//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D-eQVDK3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/contact",
			"/offers",
			"/products/accessories",
			"/products/ev",
			"/products/lubes",
			"/resources/video-gallery",
			"/vehicles/$slug",
			"/vehicles/"
		],
		preloads: [
			"/assets/index-6A66-ZSi.js",
			"/assets/jsx-runtime-DwuOsvnn.js",
			"/assets/react-dom-lIOC2FHc.js",
			"/assets/link-D5oWSvHX.js",
			"/assets/Match-BrBSzvlT.js",
			"/assets/matchContext-rwyVflaK.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-6A66-ZSi.js"
		} }]
	},
	"/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DCM_jhOj.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/arrow-right-B8TqEU9E.js",
			"/assets/badge-percent-DCPulaBE.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/phone-BkpnS6I9.js",
			"/assets/shield-check-C8fO0WMy.js",
			"/assets/wrench-CZE4mx5-.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/vehicle-card-Cf3l9FpW.js"
		]
	},
	"/about": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-zVeZGcyD.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/arrow-right-B8TqEU9E.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/phone-BkpnS6I9.js"
		]
	},
	"/admin": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.tsx",
		children: [
			"/admin/enquiries",
			"/admin/offers",
			"/admin/vehicles",
			"/admin/"
		],
		preloads: [
			"/assets/admin-C0T1t_aV.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/badge-percent-DCPulaBE.js",
			"/assets/bike-CLaq02f9.js",
			"/assets/inbox-CJWEGP_o.js",
			"/assets/shield-check-C8fO0WMy.js",
			"/assets/label-D9Qkdieb.js"
		]
	},
	"/contact": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CxC_6ZNZ.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/enquiry-form-CB-y1K6J.js",
			"/assets/clock-C24gDAYP.js",
			"/assets/phone-BkpnS6I9.js"
		]
	},
	"/offers": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-DW_eYHuQ.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/badge-percent-DCPulaBE.js",
			"/assets/bike-CLaq02f9.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/phone-BkpnS6I9.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/admin/enquiries": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.enquiries.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.enquiries-BPMEmw7-.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/useMutation-DJLuE8x2.js",
			"/assets/phone-BkpnS6I9.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/admin/offers": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.offers.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.offers-C70PvoR5.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/useMutation-DJLuE8x2.js",
			"/assets/switch-YfYGX0DS.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/textarea-Bad6Mw2d.js"
		]
	},
	"/admin/vehicles": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.vehicles.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.vehicles-CwYyv56P.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/useMutation-DJLuE8x2.js",
			"/assets/switch-YfYGX0DS.js",
			"/assets/dist-B22s1Ixe.js",
			"/assets/dist-1DjoKzri.js",
			"/assets/dist-ShCjtxfL.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/textarea-Bad6Mw2d.js",
			"/assets/availability-badge-9fat098s.js"
		]
	},
	"/products/accessories": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.accessories.tsx",
		children: void 0,
		preloads: ["/assets/products.accessories-Bz4lR8s4.js", "/assets/product-category-page-DIoWx--6.js"]
	},
	"/products/ev": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.ev.tsx",
		children: void 0,
		preloads: ["/assets/products.ev-U5Cu11NN.js", "/assets/product-category-page-DIoWx--6.js"]
	},
	"/products/lubes": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.lubes.tsx",
		children: void 0,
		preloads: ["/assets/products.lubes-BwaixE7l.js", "/assets/product-category-page-DIoWx--6.js"]
	},
	"/resources/video-gallery": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/resources.video-gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/resources.video-gallery-Zcdb6xA4.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/shield-check-C8fO0WMy.js",
			"/assets/wrench-CZE4mx5-.js"
		]
	},
	"/vehicles/$slug": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/vehicles.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles._slug-CWY3Fj2T.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/enquiry-form-CB-y1K6J.js",
			"/assets/phone-BkpnS6I9.js",
			"/assets/dist-1DjoKzri.js",
			"/assets/dist-ShCjtxfL.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/label-D9Qkdieb.js",
			"/assets/dist-Ci94ycMT.js",
			"/assets/availability-badge-9fat098s.js"
		]
	},
	"/admin/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CsPkBa5h.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/arrow-right-B8TqEU9E.js",
			"/assets/circle-check-CWLJlsxZ.js",
			"/assets/skeleton-B_v4DakP.js"
		]
	},
	"/vehicles/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/vehicles.index.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles.index-BLq_av7I.js",
			"/assets/catalogue-BQrwnliX.js",
			"/assets/button-DaRfW_X4.js",
			"/assets/mobile-contact-bar-CO4LHYJO.js",
			"/assets/skeleton-B_v4DakP.js",
			"/assets/vehicle-card-Cf3l9FpW.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
