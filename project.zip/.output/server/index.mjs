globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-10-01T16:01:14.178Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"f0a3-0wNQ84HletEaLIsnT5g5Cu08wPs\"",
		"mtime": "2026-10-01T16:01:14.129Z",
		"size": 61603,
		"path": "../public/favicon.ico"
	},
	"/assets/about-BgQ1NGla.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d4-tQoPqnRQYeNSO2h0epzUfeX6Q+M\"",
		"mtime": "2026-10-06T17:20:06.542Z",
		"size": 5076,
		"path": "../public/assets/about-BgQ1NGla.js"
	},
	"/assets/admin-B0Y1I0Bk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c9a-lOgIVn/tnk09GstlbFzqef7DwhM\"",
		"mtime": "2026-10-06T17:20:06.544Z",
		"size": 7322,
		"path": "../public/assets/admin-B0Y1I0Bk.js"
	},
	"/assets/accessories-ISdcnwFd.jpg": {
		"type": "image/jpeg",
		"etag": "\"17b94-QcbyJBUajrX+on7YbzEI9us8F1o\"",
		"mtime": "2026-10-06T17:20:06.781Z",
		"size": 97172,
		"path": "../public/assets/accessories-ISdcnwFd.jpg"
	},
	"/assets/admin.enquiries-gTQRexDo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12dd-P8OI+Oga9ZAJmTpIp6BsFsbFziA\"",
		"mtime": "2026-10-06T17:20:06.545Z",
		"size": 4829,
		"path": "../public/assets/admin.enquiries-gTQRexDo.js"
	},
	"/assets/admin.index-CI2FVc4f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f0d-eTYBzi4K2woWah5W2pvuvl5BiR0\"",
		"mtime": "2026-10-06T17:20:06.546Z",
		"size": 3853,
		"path": "../public/assets/admin.index-CI2FVc4f.js"
	},
	"/assets/admin.offers-CXWUr073.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18c7-Xfvok61eh/JNmvw0+WbNJfJ1PQk\"",
		"mtime": "2026-10-06T17:20:06.547Z",
		"size": 6343,
		"path": "../public/assets/admin.offers-CXWUr073.js"
	},
	"/assets/admin.products-EujClL_I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2078-f+ivjZQGF4vzd6Y7X6l7gdZyytM\"",
		"mtime": "2026-10-06T17:20:06.548Z",
		"size": 8312,
		"path": "../public/assets/admin.products-EujClL_I.js"
	},
	"/assets/admin.vehicles-hE8C-Tkm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"499d-u2p5TQcEn3kCrMPrhW09s6fm7ec\"",
		"mtime": "2026-10-06T17:20:06.550Z",
		"size": 18845,
		"path": "../public/assets/admin.vehicles-hE8C-Tkm.js"
	},
	"/assets/arrow-left-Cwsy3jPH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-EgmcXRXqmpJy7bJVVDLJ4ZZm9wI\"",
		"mtime": "2026-10-06T17:20:06.551Z",
		"size": 155,
		"path": "../public/assets/arrow-left-Cwsy3jPH.js"
	},
	"/assets/arrow-right-B8TqEU9E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-T0LghMA+hZ9AFvjzENRVRnEBk9M\"",
		"mtime": "2026-10-06T17:20:06.552Z",
		"size": 155,
		"path": "../public/assets/arrow-right-B8TqEU9E.js"
	},
	"/assets/availability-badge-9fat098s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"280-oz0iyfN/9OEk7skxirFHfCBRLUk\"",
		"mtime": "2026-10-06T17:20:06.553Z",
		"size": 640,
		"path": "../public/assets/availability-badge-9fat098s.js"
	},
	"/assets/badge-percent-DCPulaBE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17c-Cs7HqDhXacrRthjxtbpKDmWIL8U\"",
		"mtime": "2026-10-06T17:20:06.554Z",
		"size": 380,
		"path": "../public/assets/badge-percent-DCPulaBE.js"
	},
	"/assets/bike-CLaq02f9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116-xQMHsUd1SFF9p9JAdxMGOK0OqPM\"",
		"mtime": "2026-10-06T17:20:06.555Z",
		"size": 278,
		"path": "../public/assets/bike-CLaq02f9.js"
	},
	"/assets/button-DaRfW_X4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82be-2H8EkxDBRjYiXpdRlpHxLDDuyQI\"",
		"mtime": "2026-10-06T17:20:06.558Z",
		"size": 33470,
		"path": "../public/assets/button-DaRfW_X4.js"
	},
	"/assets/circle-check-CWLJlsxZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8-SDPHKweBkSKGNx64W2OXnSwyY4g\"",
		"mtime": "2026-10-06T17:20:06.565Z",
		"size": 168,
		"path": "../public/assets/circle-check-CWLJlsxZ.js"
	},
	"/assets/catalogue-IZcCGyeo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28de-uT5W/Kt6jT7dWhvfgAPGKeonpcY\"",
		"mtime": "2026-10-06T17:20:06.560Z",
		"size": 10462,
		"path": "../public/assets/catalogue-IZcCGyeo.js"
	},
	"/assets/clock-C24gDAYP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-KGBltAQciBQPkECRT3DQ9xlmRgY\"",
		"mtime": "2026-10-06T17:20:06.568Z",
		"size": 159,
		"path": "../public/assets/clock-C24gDAYP.js"
	},
	"/assets/contact-mswqCI-u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10b3-XYZ6mdmmQQO+O0GMNfiu1Z/4Q60\"",
		"mtime": "2026-10-06T17:20:06.570Z",
		"size": 4275,
		"path": "../public/assets/contact-mswqCI-u.js"
	},
	"/assets/dist-1DjoKzri.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1101-8JTTdoViIpg8IwFCUPOSuZFUpKI\"",
		"mtime": "2026-10-06T17:20:06.571Z",
		"size": 4353,
		"path": "../public/assets/dist-1DjoKzri.js"
	},
	"/assets/dist-BZjgKkGf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2bc-YdqT84kC7o3BmvYnYsAM8azrSg8\"",
		"mtime": "2026-10-06T17:20:06.571Z",
		"size": 700,
		"path": "../public/assets/dist-BZjgKkGf.js"
	},
	"/assets/dist-Ci94ycMT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27f-Zt0mRvYiCbcExROxdQP0RRcGHnU\"",
		"mtime": "2026-10-06T17:20:06.576Z",
		"size": 639,
		"path": "../public/assets/dist-Ci94ycMT.js"
	},
	"/assets/enquiry-form-DcCMCrQt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef12-zA2WvLCG7w56V25s5lAn/DeBVUc\"",
		"mtime": "2026-10-06T17:20:06.577Z",
		"size": 61202,
		"path": "../public/assets/enquiry-form-DcCMCrQt.js"
	},
	"/assets/image-manager-DFxZ-g0T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd1-vEUuF82aLnyfzFxAsg2fu1yGqeo\"",
		"mtime": "2026-10-06T17:20:06.580Z",
		"size": 3537,
		"path": "../public/assets/image-manager-DFxZ-g0T.js"
	},
	"/assets/inbox-CJWEGP_o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-rZDxDtZAW0LFhGoDKmQe8tcnb/E\"",
		"mtime": "2026-10-06T17:20:06.581Z",
		"size": 276,
		"path": "../public/assets/inbox-CJWEGP_o.js"
	},
	"/assets/jsx-runtime-DwuOsvnn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2230-bkegER1PxYsM3nuLQ1dQZp5l344\"",
		"mtime": "2026-10-06T17:20:06.582Z",
		"size": 8752,
		"path": "../public/assets/jsx-runtime-DwuOsvnn.js"
	},
	"/assets/label-vfCtvWu0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49e-xrH++RD34z4L+SXGRwcdpVQ2zg4\"",
		"mtime": "2026-10-06T17:20:06.587Z",
		"size": 1182,
		"path": "../public/assets/label-vfCtvWu0.js"
	},
	"/assets/link-YnfR2v_a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c2d-IE45OKmpJ+t30g8kEyIAke38Nsg\"",
		"mtime": "2026-10-06T17:20:06.594Z",
		"size": 11309,
		"path": "../public/assets/link-YnfR2v_a.js"
	},
	"/assets/Match-D4TgXLiq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1177-8AHxSAq9lHXAIoRAH3VLEMRAd3U\"",
		"mtime": "2026-10-06T17:20:06.539Z",
		"size": 4471,
		"path": "../public/assets/Match-D4TgXLiq.js"
	},
	"/assets/matchContext-CFXVncMh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-Maj6Dn5j5ZeLUqqp7wTjS5LSark\"",
		"mtime": "2026-10-06T17:20:06.596Z",
		"size": 162,
		"path": "../public/assets/matchContext-CFXVncMh.js"
	},
	"/assets/lubes-chemicals-nhf676ie.jpg": {
		"type": "image/jpeg",
		"etag": "\"b4b9-t8/LBqp+W+CQQIu2c0J+w9OGN9w\"",
		"mtime": "2026-10-06T17:20:06.782Z",
		"size": 46265,
		"path": "../public/assets/lubes-chemicals-nhf676ie.jpg"
	},
	"/assets/mobile-contact-bar-CsfT0dlh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc7c-x/dCk/b58ILvi+f7nqis1IYdj+4\"",
		"mtime": "2026-10-06T17:20:06.759Z",
		"size": 48252,
		"path": "../public/assets/mobile-contact-bar-CsfT0dlh.js"
	},
	"/assets/offers-9LDlJj6Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1165-fbxrfz3VghGCcDI5qm9xYi7femU\"",
		"mtime": "2026-10-06T17:20:06.760Z",
		"size": 4453,
		"path": "../public/assets/offers-9LDlJj6Q.js"
	},
	"/assets/package-open-D4fB9M6k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"239-DmEJmq1Vc7F/+2Y9VPRis5JCQWw\"",
		"mtime": "2026-10-06T17:20:06.761Z",
		"size": 569,
		"path": "../public/assets/package-open-D4fB9M6k.js"
	},
	"/assets/phone-Bv5op1u-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f4-aJ029+5vWx+V8pieduI4FKhaSh0\"",
		"mtime": "2026-10-06T17:20:06.762Z",
		"size": 500,
		"path": "../public/assets/phone-Bv5op1u-.js"
	},
	"/assets/play-DRa9I8bC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-hXCgp6d5KQvlExMnzu0C0s/Y2Q0\"",
		"mtime": "2026-10-06T17:20:06.763Z",
		"size": 180,
		"path": "../public/assets/play-DRa9I8bC.js"
	},
	"/assets/products.accessories-xFk0M1Hr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ff-WGBGQeDpuCPzOe95iOFzYEUhZjM\"",
		"mtime": "2026-10-06T17:20:06.766Z",
		"size": 511,
		"path": "../public/assets/products.accessories-xFk0M1Hr.js"
	},
	"/assets/products.lubes-5X_EHGlt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20b-qBY1BIBTC83UqhWAmLX3E/eRCao\"",
		"mtime": "2026-10-06T17:20:06.766Z",
		"size": 523,
		"path": "../public/assets/products.lubes-5X_EHGlt.js"
	},
	"/assets/product-listing-page-BhuuQ8Lk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1266-1dI1Fmuw8naR/2TcJ4USmV166bA\"",
		"mtime": "2026-10-06T17:20:06.764Z",
		"size": 4710,
		"path": "../public/assets/product-listing-page-BhuuQ8Lk.js"
	},
	"/assets/products._id-DbSpFA46.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e97-BVBGa+GE80lmn61xNoD0ZYmD9C4\"",
		"mtime": "2026-10-06T17:20:06.765Z",
		"size": 3735,
		"path": "../public/assets/products._id-DbSpFA46.js"
	},
	"/assets/resources.video-gallery-B-h7HmFi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dce-vkguGKORDUkxpIEo7k7Go/MC5UY\"",
		"mtime": "2026-10-06T17:20:06.767Z",
		"size": 3534,
		"path": "../public/assets/resources.video-gallery-B-h7HmFi.js"
	},
	"/assets/routes-D3KdZrQj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2424-rOGsIOWm6tjxwmMteOxqyFhg0I4\"",
		"mtime": "2026-10-06T17:20:06.768Z",
		"size": 9252,
		"path": "../public/assets/routes-D3KdZrQj.js"
	},
	"/assets/shield-check-C8fO0WMy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-Iji/y+uRQNthDkltUdgxlOZcACU\"",
		"mtime": "2026-10-06T17:20:06.769Z",
		"size": 310,
		"path": "../public/assets/shield-check-C8fO0WMy.js"
	},
	"/assets/skeleton-B_v4DakP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5-9uWrvYmERgSK5eAYNSxXIsQbcDM\"",
		"mtime": "2026-10-06T17:20:06.770Z",
		"size": 229,
		"path": "../public/assets/skeleton-B_v4DakP.js"
	},
	"/assets/switch-mDMw8PkT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132d-Zlq68LFvybxDuGkhD1hakLuVJAs\"",
		"mtime": "2026-10-06T17:20:06.771Z",
		"size": 4909,
		"path": "../public/assets/switch-mDMw8PkT.js"
	},
	"/assets/textarea-Bad6Mw2d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"208-4caPW+QPE83rqcfdVg88JbhKYWQ\"",
		"mtime": "2026-10-06T17:20:06.775Z",
		"size": 520,
		"path": "../public/assets/textarea-Bad6Mw2d.js"
	},
	"/assets/useMutation-mwU4pNE1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"927-CdZH4EGHe89v+6ibhS9l2QDwu7I\"",
		"mtime": "2026-10-06T17:20:06.776Z",
		"size": 2343,
		"path": "../public/assets/useMutation-mwU4pNE1.js"
	},
	"/assets/styles-pkP1rdqD.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17001-wIAnmkVRVkRraIjW48LLdEHjgK4\"",
		"mtime": "2026-10-06T17:20:06.783Z",
		"size": 94209,
		"path": "../public/assets/styles-pkP1rdqD.css"
	},
	"/assets/index-Buozkgqt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8cd59-hbCtsdt+7zBFtaT0+XJsHcI1zZ8\"",
		"mtime": "2026-10-06T17:20:06.538Z",
		"size": 576857,
		"path": "../public/assets/index-Buozkgqt.js"
	},
	"/assets/vehicle-card-BfrKgxhL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b00-MCbZ8RlQau2fRHPjlGTxUlFY7Sk\"",
		"mtime": "2026-10-06T17:20:06.777Z",
		"size": 2816,
		"path": "../public/assets/vehicle-card-BfrKgxhL.js"
	},
	"/assets/vehicles.index-198eVTIT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c94-7C0BQ2CidtKk3gATOUq/ppfYZm8\"",
		"mtime": "2026-10-06T17:20:06.779Z",
		"size": 3220,
		"path": "../public/assets/vehicles.index-198eVTIT.js"
	},
	"/assets/vehicles._slug-DJAoCeqX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5e21-zyxp19/2OCoZ6ddceUpdRaUPtik\"",
		"mtime": "2026-10-06T17:20:06.778Z",
		"size": 24097,
		"path": "../public/assets/vehicles._slug-DJAoCeqX.js"
	},
	"/assets/x-ZLK-pjRD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-PW3yV8qBdWLtonx3+Nh9i9rKv1w\"",
		"mtime": "2026-10-06T17:20:06.780Z",
		"size": 144,
		"path": "../public/assets/x-ZLK-pjRD.js"
	},
	"/assets/video-gallery-cover-COE9Pq-q.jpg": {
		"type": "image/jpeg",
		"etag": "\"28a10-qrIMFmSAPRUghLSMy0T6hFlumZk\"",
		"mtime": "2026-10-06T17:20:06.784Z",
		"size": 166416,
		"path": "../public/assets/video-gallery-cover-COE9Pq-q.jpg"
	},
	"/images/laxmi-motors-logo.png": {
		"type": "image/png",
		"etag": "\"14af0-10oyGg8A0MTF0e53gVBhkY7MGO4\"",
		"mtime": "2026-10-01T16:01:14.177Z",
		"size": 84720,
		"path": "../public/images/laxmi-motors-logo.png"
	},
	"/images/demo/activa-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"15873-9yPJULYyuZRxRPIgfkTow2/RWYE\"",
		"mtime": "2026-10-01T16:01:14.141Z",
		"size": 88179,
		"path": "../public/images/demo/activa-125.jpg"
	},
	"/images/demo/activa-6g.jpg": {
		"type": "image/jpeg",
		"etag": "\"b545-wnWewHEzowz8uiSll3vbMUGlabM\"",
		"mtime": "2026-10-01T16:01:14.143Z",
		"size": 46405,
		"path": "../public/images/demo/activa-6g.jpg"
	},
	"/images/demo/dio.jpg": {
		"type": "image/jpeg",
		"etag": "\"dd85-3Mp/nzRBmqlud5vU5Kyx2tSU9v8\"",
		"mtime": "2026-10-01T16:01:14.145Z",
		"size": 56709,
		"path": "../public/images/demo/dio.jpg"
	},
	"/images/demo/hero-showroom.jpg": {
		"type": "image/jpeg",
		"etag": "\"29c7a-zAlW5T0hx8yWNugetKie80I09IU\"",
		"mtime": "2026-10-01T16:01:14.151Z",
		"size": 171130,
		"path": "../public/images/demo/hero-showroom.jpg"
	},
	"/images/demo/honda-activa-6g-05.jpg": {
		"type": "image/jpeg",
		"etag": "\"19ab4-mQ53xbpwLDeg0A5S9d6cz2SGNmg\"",
		"mtime": "2026-10-01T16:01:14.154Z",
		"size": 105140,
		"path": "../public/images/demo/honda-activa-6g-05.jpg"
	},
	"/images/demo/Honda-Shine-100-DX-side.jpg": {
		"type": "image/jpeg",
		"etag": "\"3ad2b-wxlH1buhV5Ziw8+0d0dwyhpCAU0\"",
		"mtime": "2026-10-01T16:01:14.138Z",
		"size": 240939,
		"path": "../public/images/demo/Honda-Shine-100-DX-side.jpg"
	},
	"/images/demo/shine-100.jpg": {
		"type": "image/jpeg",
		"etag": "\"188b7-LKKaUiqQSuCq/IlW2U0lgtbWpLo\"",
		"mtime": "2026-10-01T16:01:14.156Z",
		"size": 100535,
		"path": "../public/images/demo/shine-100.jpg"
	},
	"/images/demo/shine-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"16228-57py96T3f0JvDby1huiE/elTVV0\"",
		"mtime": "2026-10-01T16:01:14.159Z",
		"size": 90664,
		"path": "../public/images/demo/shine-125.jpg"
	},
	"/images/demo/showroom-interior.jpg": {
		"type": "image/jpeg",
		"etag": "\"3b13a-WEMYZJKJOxdqaAX0aAb/DCqylRc\"",
		"mtime": "2026-10-01T16:01:14.163Z",
		"size": 241978,
		"path": "../public/images/demo/showroom-interior.jpg"
	},
	"/images/demo/sophistication-redefined-640x426.png": {
		"type": "image/png",
		"etag": "\"22bd8-mgoz5uIxbYNEKBxdrYA0TRh1gJM\"",
		"mtime": "2026-10-01T16:01:14.169Z",
		"size": 142296,
		"path": "../public/images/demo/sophistication-redefined-640x426.png"
	},
	"/images/demo/sp-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"14eea-qBd/lahacVSlvEwxKKP5uhmK0KA\"",
		"mtime": "2026-10-01T16:01:14.171Z",
		"size": 85738,
		"path": "../public/images/demo/sp-125.jpg"
	},
	"/images/demo/unicorn.jpg": {
		"type": "image/jpeg",
		"etag": "\"16e6f-Nb+Is/kf3keLszTQzOf0bLqYYcE\"",
		"mtime": "2026-10-01T16:01:14.174Z",
		"size": 93807,
		"path": "../public/images/demo/unicorn.jpg"
	},
	"/images/reference/honda-ev-scooters.png": {
		"type": "image/png",
		"etag": "\"29697-CUZ8foQrlsNp4SlRWdosHbcAE3c\"",
		"mtime": "2026-10-01T15:09:31.052Z",
		"size": 169623,
		"path": "../public/images/reference/honda-ev-scooters.png"
	},
	"/images/reference/honda-factory.png": {
		"type": "image/png",
		"etag": "\"624e4-qDQurFAcdllq+EXowyo77tZGD2c\"",
		"mtime": "2026-10-01T15:09:31.094Z",
		"size": 402660,
		"path": "../public/images/reference/honda-factory.png"
	},
	"/images/reference/honda-hero-banner.png": {
		"type": "image/png",
		"etag": "\"2ceee-rPlToIHo1Vl+hrtjkHsfT7lpUWI\"",
		"mtime": "2026-10-01T15:09:31.116Z",
		"size": 184046,
		"path": "../public/images/reference/honda-hero-banner.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_Rgmles = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_Rgmles
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
