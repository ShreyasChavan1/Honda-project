globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-zVeZGcyD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f34-gxmTdDq8yRxQizCoAxpkjjbc0j8\"",
		"mtime": "2026-09-26T11:35:39.615Z",
		"size": 3892,
		"path": "../public/assets/about-zVeZGcyD.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-26T11:23:42.582Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/admin-C0T1t_aV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c2e-98qq1aXvUzCxigQZVS2UcHM9fXM\"",
		"mtime": "2026-09-26T11:35:39.618Z",
		"size": 7214,
		"path": "../public/assets/admin-C0T1t_aV.js"
	},
	"/assets/admin.enquiries-BPMEmw7-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11bd-4noDZpCbj7WCCH+kkmEoYzGH35o\"",
		"mtime": "2026-09-26T11:35:39.624Z",
		"size": 4541,
		"path": "../public/assets/admin.enquiries-BPMEmw7-.js"
	},
	"/assets/admin.index-CsPkBa5h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8d-w46EHCx2TmLsKs8wTeCkXtCzBN4\"",
		"mtime": "2026-09-26T11:35:39.629Z",
		"size": 3725,
		"path": "../public/assets/admin.index-CsPkBa5h.js"
	},
	"/assets/admin.offers-C70PvoR5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"178d-4BDzC7dkRCMOrcQOH6+xzaQwOzU\"",
		"mtime": "2026-09-26T11:35:39.637Z",
		"size": 6029,
		"path": "../public/assets/admin.offers-C70PvoR5.js"
	},
	"/assets/admin.vehicles-CwYyv56P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5fc-x3o79cjv7y2l8P8P5d5gwshUpsY\"",
		"mtime": "2026-09-26T11:35:39.661Z",
		"size": 58876,
		"path": "../public/assets/admin.vehicles-CwYyv56P.js"
	},
	"/assets/arrow-right-B8TqEU9E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-T0LghMA+hZ9AFvjzENRVRnEBk9M\"",
		"mtime": "2026-09-26T11:35:39.664Z",
		"size": 155,
		"path": "../public/assets/arrow-right-B8TqEU9E.js"
	},
	"/assets/availability-badge-9fat098s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"280-oz0iyfN/9OEk7skxirFHfCBRLUk\"",
		"mtime": "2026-09-26T11:35:39.669Z",
		"size": 640,
		"path": "../public/assets/availability-badge-9fat098s.js"
	},
	"/assets/badge-percent-DCPulaBE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17c-Cs7HqDhXacrRthjxtbpKDmWIL8U\"",
		"mtime": "2026-09-26T11:35:39.671Z",
		"size": 380,
		"path": "../public/assets/badge-percent-DCPulaBE.js"
	},
	"/assets/bike-CLaq02f9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116-xQMHsUd1SFF9p9JAdxMGOK0OqPM\"",
		"mtime": "2026-09-26T11:35:39.673Z",
		"size": 278,
		"path": "../public/assets/bike-CLaq02f9.js"
	},
	"/assets/button-DaRfW_X4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82be-2H8EkxDBRjYiXpdRlpHxLDDuyQI\"",
		"mtime": "2026-09-26T11:35:39.674Z",
		"size": 33470,
		"path": "../public/assets/button-DaRfW_X4.js"
	},
	"/assets/accessories-ISdcnwFd.jpg": {
		"type": "image/jpeg",
		"etag": "\"17b94-QcbyJBUajrX+on7YbzEI9us8F1o\"",
		"mtime": "2026-09-26T11:35:40.197Z",
		"size": 97172,
		"path": "../public/assets/accessories-ISdcnwFd.jpg"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-26T11:23:42.560Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/circle-check-CWLJlsxZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8-SDPHKweBkSKGNx64W2OXnSwyY4g\"",
		"mtime": "2026-09-26T11:35:39.678Z",
		"size": 168,
		"path": "../public/assets/circle-check-CWLJlsxZ.js"
	},
	"/assets/clock-C24gDAYP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-KGBltAQciBQPkECRT3DQ9xlmRgY\"",
		"mtime": "2026-09-26T11:35:39.680Z",
		"size": 159,
		"path": "../public/assets/clock-C24gDAYP.js"
	},
	"/assets/contact-CxC_6ZNZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1157-K7jKBShzT80HM7c09gq5+6iK0pk\"",
		"mtime": "2026-09-26T11:35:39.697Z",
		"size": 4439,
		"path": "../public/assets/contact-CxC_6ZNZ.js"
	},
	"/assets/dist-1DjoKzri.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1101-8JTTdoViIpg8IwFCUPOSuZFUpKI\"",
		"mtime": "2026-09-26T11:35:39.708Z",
		"size": 4353,
		"path": "../public/assets/dist-1DjoKzri.js"
	},
	"/assets/dist-Ci94ycMT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27f-Zt0mRvYiCbcExROxdQP0RRcGHnU\"",
		"mtime": "2026-09-26T11:35:39.712Z",
		"size": 639,
		"path": "../public/assets/dist-Ci94ycMT.js"
	},
	"/assets/dist-ShCjtxfL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c0-J6LHglTBSZpP9YdSj9n6lx0ceu8\"",
		"mtime": "2026-09-26T11:35:39.718Z",
		"size": 704,
		"path": "../public/assets/dist-ShCjtxfL.js"
	},
	"/assets/enquiry-form-CB-y1K6J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef0f-1FJmRmiWTOo+gAgVo3bba5EszfM\"",
		"mtime": "2026-09-26T11:35:39.737Z",
		"size": 61199,
		"path": "../public/assets/enquiry-form-CB-y1K6J.js"
	},
	"/assets/catalogue-BQrwnliX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2689-GtG1HyjhvAj2BoAJEX88gJCawMQ\"",
		"mtime": "2026-09-26T11:35:39.676Z",
		"size": 9865,
		"path": "../public/assets/catalogue-BQrwnliX.js"
	},
	"/assets/dist-B22s1Ixe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21a1-rosOxecg8o1ENAmYoe0NpfzabvQ\"",
		"mtime": "2026-09-26T11:35:39.711Z",
		"size": 8609,
		"path": "../public/assets/dist-B22s1Ixe.js"
	},
	"/assets/inbox-CJWEGP_o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-rZDxDtZAW0LFhGoDKmQe8tcnb/E\"",
		"mtime": "2026-09-26T11:35:39.754Z",
		"size": 276,
		"path": "../public/assets/inbox-CJWEGP_o.js"
	},
	"/assets/ev-showroom-BOkTnJcS.jpg": {
		"type": "image/jpeg",
		"etag": "\"20ed1-2bA8/VM3uiSEWo7kFhU8bWwkYtg\"",
		"mtime": "2026-09-26T11:35:40.198Z",
		"size": 134865,
		"path": "../public/assets/ev-showroom-BOkTnJcS.jpg"
	},
	"/assets/jsx-runtime-DwuOsvnn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2230-bkegER1PxYsM3nuLQ1dQZp5l344\"",
		"mtime": "2026-09-26T11:35:39.769Z",
		"size": 8752,
		"path": "../public/assets/jsx-runtime-DwuOsvnn.js"
	},
	"/assets/link-D5oWSvHX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b4c-/8SsRtZSq7qSAkySbUCDq3zGle0\"",
		"mtime": "2026-09-26T11:35:39.792Z",
		"size": 23372,
		"path": "../public/assets/link-D5oWSvHX.js"
	},
	"/assets/lubes-chemicals-BRqesYht.jpg": {
		"type": "image/jpeg",
		"etag": "\"2597d-BZanb4KU2+i91IGmZhcbVSq1cqM\"",
		"mtime": "2026-09-26T11:35:40.199Z",
		"size": 153981,
		"path": "../public/assets/lubes-chemicals-BRqesYht.jpg"
	},
	"/assets/Match-BrBSzvlT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be03-tdxKUAl6x7R//rj7VAnjfApP3vs\"",
		"mtime": "2026-09-26T11:35:39.614Z",
		"size": 48643,
		"path": "../public/assets/Match-BrBSzvlT.js"
	},
	"/assets/matchContext-rwyVflaK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29c-B3Ao3P04cNPFiFvVnb1J5HHUmcg\"",
		"mtime": "2026-09-26T11:35:39.809Z",
		"size": 668,
		"path": "../public/assets/matchContext-rwyVflaK.js"
	},
	"/assets/mobile-contact-bar-CO4LHYJO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9173-LspCR87ED6oGmvn9Wjq6EAIIb3s\"",
		"mtime": "2026-09-26T11:35:39.825Z",
		"size": 37235,
		"path": "../public/assets/mobile-contact-bar-CO4LHYJO.js"
	},
	"/assets/offers-DW_eYHuQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1161-Rp134d1hmbNdlh4/h907cqiI9zU\"",
		"mtime": "2026-09-26T11:35:39.828Z",
		"size": 4449,
		"path": "../public/assets/offers-DW_eYHuQ.js"
	},
	"/assets/phone-BkpnS6I9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28a-0rIT7gWtC9+RUm1BMbmC6ldR0ZM\"",
		"mtime": "2026-09-26T11:35:40.019Z",
		"size": 650,
		"path": "../public/assets/phone-BkpnS6I9.js"
	},
	"/assets/product-category-page-DIoWx--6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d9-luH3PyV7hzRzn6U9ZocZTNxYlOA\"",
		"mtime": "2026-09-26T11:35:40.176Z",
		"size": 2521,
		"path": "../public/assets/product-category-page-DIoWx--6.js"
	},
	"/assets/products.accessories-Bz4lR8s4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a4-knlKtRPOnd6Jyiwz2iFS+x29mnQ\"",
		"mtime": "2026-09-26T11:35:40.177Z",
		"size": 932,
		"path": "../public/assets/products.accessories-Bz4lR8s4.js"
	},
	"/assets/label-D9Qkdieb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49e-+vMmsD2QOzebBC5ron2/nrgy0uQ\"",
		"mtime": "2026-09-26T11:35:39.778Z",
		"size": 1182,
		"path": "../public/assets/label-D9Qkdieb.js"
	},
	"/assets/products.ev-U5Cu11NN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c2-chBFjWUsuAi/K4KcYptKd7DMqlE\"",
		"mtime": "2026-09-26T11:35:40.178Z",
		"size": 962,
		"path": "../public/assets/products.ev-U5Cu11NN.js"
	},
	"/assets/products.lubes-BwaixE7l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c0-jYo7RBaHKXRvbjVvYBwaIpUTsMY\"",
		"mtime": "2026-09-26T11:35:40.179Z",
		"size": 960,
		"path": "../public/assets/products.lubes-BwaixE7l.js"
	},
	"/assets/react-dom-lIOC2FHc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f17-LoQpJr1B59JCeBRhq995pAsBCWc\"",
		"mtime": "2026-09-26T11:35:40.181Z",
		"size": 3863,
		"path": "../public/assets/react-dom-lIOC2FHc.js"
	},
	"/assets/resources.video-gallery-Zcdb6xA4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef6-m+bSJz8mMM6H/MelTBv7w2bmtRk\"",
		"mtime": "2026-09-26T11:35:40.182Z",
		"size": 3830,
		"path": "../public/assets/resources.video-gallery-Zcdb6xA4.js"
	},
	"/assets/shield-check-C8fO0WMy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-Iji/y+uRQNthDkltUdgxlOZcACU\"",
		"mtime": "2026-09-26T11:35:40.184Z",
		"size": 310,
		"path": "../public/assets/shield-check-C8fO0WMy.js"
	},
	"/assets/skeleton-B_v4DakP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5-9uWrvYmERgSK5eAYNSxXIsQbcDM\"",
		"mtime": "2026-09-26T11:35:40.186Z",
		"size": 229,
		"path": "../public/assets/skeleton-B_v4DakP.js"
	},
	"/assets/routes-DCM_jhOj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2491-uIXB1Fx/MBNl8QKyf5b4lfZLMEo\"",
		"mtime": "2026-09-26T11:35:40.183Z",
		"size": 9361,
		"path": "../public/assets/routes-DCM_jhOj.js"
	},
	"/assets/switch-YfYGX0DS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132d-1LjJoufzU1xp9cM3hYahUHI+lgc\"",
		"mtime": "2026-09-26T11:35:40.187Z",
		"size": 4909,
		"path": "../public/assets/switch-YfYGX0DS.js"
	},
	"/assets/useMutation-DJLuE8x2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"927-saM8kogrslva7yexVBLP2Is4X54\"",
		"mtime": "2026-09-26T11:35:40.190Z",
		"size": 2343,
		"path": "../public/assets/useMutation-DJLuE8x2.js"
	},
	"/assets/index-6A66-ZSi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80673-Z5Ief3UQA8aqxdXeZl3EWYeQyE8\"",
		"mtime": "2026-09-26T11:35:39.613Z",
		"size": 525939,
		"path": "../public/assets/index-6A66-ZSi.js"
	},
	"/assets/styles-BC3Ba7SB.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16636-0PolhoCjpryB5knJ1XuES6nipRw\"",
		"mtime": "2026-09-26T11:35:40.200Z",
		"size": 91702,
		"path": "../public/assets/styles-BC3Ba7SB.css"
	},
	"/assets/textarea-Bad6Mw2d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"208-4caPW+QPE83rqcfdVg88JbhKYWQ\"",
		"mtime": "2026-09-26T11:35:40.189Z",
		"size": 520,
		"path": "../public/assets/textarea-Bad6Mw2d.js"
	},
	"/assets/vehicles.index-BLq_av7I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7b-95Z9+tz/PMUNrEFlJAyTwQ8qhcc\"",
		"mtime": "2026-09-26T11:35:40.195Z",
		"size": 3195,
		"path": "../public/assets/vehicles.index-BLq_av7I.js"
	},
	"/assets/vehicles._slug-CWY3Fj2T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"569f-+Edz3XqzaOWsIzrb1GuvUinzVRQ\"",
		"mtime": "2026-09-26T11:35:40.193Z",
		"size": 22175,
		"path": "../public/assets/vehicles._slug-CWY3Fj2T.js"
	},
	"/assets/wrench-CZE4mx5-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-CwmC2NBXJqBlNWerG6pBoqJWTqg\"",
		"mtime": "2026-09-26T11:35:40.196Z",
		"size": 293,
		"path": "../public/assets/wrench-CZE4mx5-.js"
	},
	"/assets/xlsx-C8WN43MN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"67b05-hnbVNMlKih9ykm0V6S6Ujg3TNks\"",
		"mtime": "2026-09-26T11:35:40.197Z",
		"size": 424709,
		"path": "../public/assets/xlsx-C8WN43MN.js"
	},
	"/assets/vehicle-card-Cf3l9FpW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b6-dD1UvN2JIUJp2ED72XXOm9+OV3k\"",
		"mtime": "2026-09-26T11:35:40.191Z",
		"size": 1974,
		"path": "../public/assets/vehicle-card-Cf3l9FpW.js"
	},
	"/images/demo/activa-6g.jpg": {
		"type": "image/jpeg",
		"etag": "\"b545-wnWewHEzowz8uiSll3vbMUGlabM\"",
		"mtime": "2026-09-26T11:23:42.764Z",
		"size": 46405,
		"path": "../public/images/demo/activa-6g.jpg"
	},
	"/assets/video-gallery-cover-COE9Pq-q.jpg": {
		"type": "image/jpeg",
		"etag": "\"28a10-qrIMFmSAPRUghLSMy0T6hFlumZk\"",
		"mtime": "2026-09-26T11:35:40.201Z",
		"size": 166416,
		"path": "../public/assets/video-gallery-cover-COE9Pq-q.jpg"
	},
	"/images/demo/dio.jpg": {
		"type": "image/jpeg",
		"etag": "\"dd85-3Mp/nzRBmqlud5vU5Kyx2tSU9v8\"",
		"mtime": "2026-09-26T11:23:42.686Z",
		"size": 56709,
		"path": "../public/images/demo/dio.jpg"
	},
	"/images/demo/shine-100.jpg": {
		"type": "image/jpeg",
		"etag": "\"188b7-LKKaUiqQSuCq/IlW2U0lgtbWpLo\"",
		"mtime": "2026-09-26T11:23:42.664Z",
		"size": 100535,
		"path": "../public/images/demo/shine-100.jpg"
	},
	"/images/demo/sp-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"14eea-qBd/lahacVSlvEwxKKP5uhmK0KA\"",
		"mtime": "2026-09-26T11:23:42.609Z",
		"size": 85738,
		"path": "../public/images/demo/sp-125.jpg"
	},
	"/images/demo/hero-showroom.jpg": {
		"type": "image/jpeg",
		"etag": "\"29c7a-zAlW5T0hx8yWNugetKie80I09IU\"",
		"mtime": "2026-09-26T11:23:42.740Z",
		"size": 171130,
		"path": "../public/images/demo/hero-showroom.jpg"
	},
	"/images/demo/activa-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"15873-9yPJULYyuZRxRPIgfkTow2/RWYE\"",
		"mtime": "2026-09-26T11:23:42.714Z",
		"size": 88179,
		"path": "../public/images/demo/activa-125.jpg"
	},
	"/images/demo/shine-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"16228-57py96T3f0JvDby1huiE/elTVV0\"",
		"mtime": "2026-09-26T11:23:42.824Z",
		"size": 90664,
		"path": "../public/images/demo/shine-125.jpg"
	},
	"/images/demo/showroom-interior.jpg": {
		"type": "image/jpeg",
		"etag": "\"3b13a-WEMYZJKJOxdqaAX0aAb/DCqylRc\"",
		"mtime": "2026-09-26T11:23:42.798Z",
		"size": 241978,
		"path": "../public/images/demo/showroom-interior.jpg"
	},
	"/images/demo/unicorn.jpg": {
		"type": "image/jpeg",
		"etag": "\"16e6f-Nb+Is/kf3keLszTQzOf0bLqYYcE\"",
		"mtime": "2026-09-26T11:23:42.639Z",
		"size": 93807,
		"path": "../public/images/demo/unicorn.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_Rgmles = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_Rgmles
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
