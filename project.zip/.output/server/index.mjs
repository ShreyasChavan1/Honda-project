globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-04T10:55:07.722Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-04T10:55:07.696Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/about-Dp5ZhMrk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f34-RGxamaTQicDebfq5oB12rO6n6hg\"",
		"mtime": "2026-09-22T04:09:28.900Z",
		"size": 3892,
		"path": "../public/assets/about-Dp5ZhMrk.js"
	},
	"/assets/admin-DPnI3uuE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c2e-s/u0IjVwh/KkdEdlIw8wlc81pPI\"",
		"mtime": "2026-09-22T04:09:28.906Z",
		"size": 7214,
		"path": "../public/assets/admin-DPnI3uuE.js"
	},
	"/assets/admin.enquiries-Bbaqj1-S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11bd-FTPPSTe4tcD8/bHJjSgwWjTM9pY\"",
		"mtime": "2026-09-22T04:09:28.907Z",
		"size": 4541,
		"path": "../public/assets/admin.enquiries-Bbaqj1-S.js"
	},
	"/assets/admin.index-CrE_vqoh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8d-pj71xItX31OSQbnvJthjELv335E\"",
		"mtime": "2026-09-22T04:09:28.909Z",
		"size": 3725,
		"path": "../public/assets/admin.index-CrE_vqoh.js"
	},
	"/assets/admin.offers-BSxo9Cvs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"178d-P5fgRjCiQnLAlDzRC+Dvq1kZkQI\"",
		"mtime": "2026-09-22T04:09:28.911Z",
		"size": 6029,
		"path": "../public/assets/admin.offers-BSxo9Cvs.js"
	},
	"/assets/accessories-ISdcnwFd.jpg": {
		"type": "image/jpeg",
		"etag": "\"17b94-QcbyJBUajrX+on7YbzEI9us8F1o\"",
		"mtime": "2026-09-22T04:09:29.182Z",
		"size": 97172,
		"path": "../public/assets/accessories-ISdcnwFd.jpg"
	},
	"/assets/admin.vehicles-BNfAqqLA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ccd-e7saVfGXdKrP7iwDwQke5XxjGQQ\"",
		"mtime": "2026-09-22T04:09:28.912Z",
		"size": 19661,
		"path": "../public/assets/admin.vehicles-BNfAqqLA.js"
	},
	"/assets/arrow-right-CMI1S-5S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-Q9wPpCICV2U+KUsJ14T8oNkJbAI\"",
		"mtime": "2026-09-22T04:09:28.914Z",
		"size": 155,
		"path": "../public/assets/arrow-right-CMI1S-5S.js"
	},
	"/assets/availability-badge-CxeFbWBw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"280-rgB4mWzquJMX7Ag3FQVYlb82EXQ\"",
		"mtime": "2026-09-22T04:09:28.915Z",
		"size": 640,
		"path": "../public/assets/availability-badge-CxeFbWBw.js"
	},
	"/assets/badge-percent-XuGw1xpv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17c-jPC0M6vL0HMtP31TGzyw+1b4yxY\"",
		"mtime": "2026-09-22T04:09:28.945Z",
		"size": 380,
		"path": "../public/assets/badge-percent-XuGw1xpv.js"
	},
	"/assets/bike-fqNSro4a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116-vYD60/JPaeT8/aUkYKwJvGs6Apo\"",
		"mtime": "2026-09-22T04:09:28.952Z",
		"size": 278,
		"path": "../public/assets/bike-fqNSro4a.js"
	},
	"/assets/button-tix-khff.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"814e-nluwBHFeHzZHBJOZXZzPii02dWM\"",
		"mtime": "2026-09-22T04:09:28.953Z",
		"size": 33102,
		"path": "../public/assets/button-tix-khff.js"
	},
	"/assets/catalogue-CxXghWEH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26e5-rD3YSv1EVIh3jFzF9CVjOAnMxng\"",
		"mtime": "2026-09-22T04:09:28.955Z",
		"size": 9957,
		"path": "../public/assets/catalogue-CxXghWEH.js"
	},
	"/assets/circle-check-C1PbQvQy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8-ZK25EX6ERkXPDDZYbR4hFv88A0U\"",
		"mtime": "2026-09-22T04:09:28.957Z",
		"size": 168,
		"path": "../public/assets/circle-check-C1PbQvQy.js"
	},
	"/assets/clock-BIb4EeNf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-4chXqQFOgkjraNm5aOdjIuzbHKU\"",
		"mtime": "2026-09-22T04:09:28.957Z",
		"size": 159,
		"path": "../public/assets/clock-BIb4EeNf.js"
	},
	"/assets/contact-CoYsyw2D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1157-oZTi7bkaujaQQ3saeYH5W1wy4Xc\"",
		"mtime": "2026-09-22T04:09:28.958Z",
		"size": 4439,
		"path": "../public/assets/contact-CoYsyw2D.js"
	},
	"/assets/dist-7gLvwnpF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27f-Pn3FOueP15jB78g2K04ygHO4Uqk\"",
		"mtime": "2026-09-22T04:09:28.963Z",
		"size": 639,
		"path": "../public/assets/dist-7gLvwnpF.js"
	},
	"/assets/dist-BzAtln6b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c0-1Rz9swI3omWJGhCboVN49Yc9PL0\"",
		"mtime": "2026-09-22T04:09:28.974Z",
		"size": 704,
		"path": "../public/assets/dist-BzAtln6b.js"
	},
	"/assets/dist-GkryDKTG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1101-GrLDSsTSweZtFPvIcd3klfc5lB4\"",
		"mtime": "2026-09-22T04:09:28.974Z",
		"size": 4353,
		"path": "../public/assets/dist-GkryDKTG.js"
	},
	"/assets/enquiry-form-CBZSLJcB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef0f-0NaCYg6kozDHem1Owl28dvDtTc4\"",
		"mtime": "2026-09-22T04:09:28.975Z",
		"size": 61199,
		"path": "../public/assets/enquiry-form-CBZSLJcB.js"
	},
	"/assets/inbox-BCCNuaGy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-3AiZKNOS4kS63KKG4GYTPeBvi28\"",
		"mtime": "2026-09-22T04:09:28.976Z",
		"size": 276,
		"path": "../public/assets/inbox-BCCNuaGy.js"
	},
	"/assets/ev-showroom-BOkTnJcS.jpg": {
		"type": "image/jpeg",
		"etag": "\"20ed1-2bA8/VM3uiSEWo7kFhU8bWwkYtg\"",
		"mtime": "2026-09-22T04:09:29.183Z",
		"size": 134865,
		"path": "../public/assets/ev-showroom-BOkTnJcS.jpg"
	},
	"/assets/index-Bz4Yq3-y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"77ee5-dTAOo48TKFHIcHDqocCzRXXp7SA\"",
		"mtime": "2026-09-22T04:09:28.898Z",
		"size": 491237,
		"path": "../public/assets/index-Bz4Yq3-y.js"
	},
	"/assets/jsx-runtime-BKllkxft.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-OsELDERtTmr6S+CCOADMMZjtZ2o\"",
		"mtime": "2026-09-22T04:09:28.977Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-BKllkxft.js"
	},
	"/assets/link-BfEU25L_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b4c-MaUAu67RTuJkMvf2889gN5YyDrs\"",
		"mtime": "2026-09-22T04:09:28.978Z",
		"size": 23372,
		"path": "../public/assets/link-BfEU25L_.js"
	},
	"/assets/label-Dmeazhsc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49e-UWOzrb/HR7jbRsCCqe93bJ6caA8\"",
		"mtime": "2026-09-22T04:09:28.977Z",
		"size": 1182,
		"path": "../public/assets/label-Dmeazhsc.js"
	},
	"/assets/Match-dYEIYYWP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be03-Wy5YITkzA+0YDlAC09qV3Saq13I\"",
		"mtime": "2026-09-22T04:09:28.899Z",
		"size": 48643,
		"path": "../public/assets/Match-dYEIYYWP.js"
	},
	"/assets/matchContext-CRq-ZNtE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29c-Yq+8lEIk6eTYL+oaDQkjReCGpMs\"",
		"mtime": "2026-09-22T04:09:28.979Z",
		"size": 668,
		"path": "../public/assets/matchContext-CRq-ZNtE.js"
	},
	"/assets/mobile-contact-bar-BwFnMLib.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1eb-FRPWdKVdKl813KvzW4MPgMh4+Co\"",
		"mtime": "2026-09-22T04:09:28.983Z",
		"size": 45547,
		"path": "../public/assets/mobile-contact-bar-BwFnMLib.js"
	},
	"/assets/offers-FSnxDa82.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1161-WUtsLiRWVBkFvo8tweDEzf8Q8lw\"",
		"mtime": "2026-09-22T04:09:28.984Z",
		"size": 4449,
		"path": "../public/assets/offers-FSnxDa82.js"
	},
	"/assets/phone-CauQ93-b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28a-iwusgr/eKHjWidS/ehwIIixkdxI\"",
		"mtime": "2026-09-22T04:09:29.075Z",
		"size": 650,
		"path": "../public/assets/phone-CauQ93-b.js"
	},
	"/assets/product-category-page-Dbr-xALf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d9-Os7TmOfLJhTUPr3f15uBzEsflT0\"",
		"mtime": "2026-09-22T04:09:29.165Z",
		"size": 2521,
		"path": "../public/assets/product-category-page-Dbr-xALf.js"
	},
	"/assets/products.accessories-s0NnaiLq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a4-sIIOI84Kg46rekbrCdIZi4Rnlmc\"",
		"mtime": "2026-09-22T04:09:29.167Z",
		"size": 932,
		"path": "../public/assets/products.accessories-s0NnaiLq.js"
	},
	"/assets/products.ev-BFwJbO-8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c2-6hkddrBzDFjWCYIxrNn1pWDHT8Q\"",
		"mtime": "2026-09-22T04:09:29.168Z",
		"size": 962,
		"path": "../public/assets/products.ev-BFwJbO-8.js"
	},
	"/assets/products.lubes-5n6ecJgi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c0-+C6Bsur7P2/05NPf/SHjaKwpKuk\"",
		"mtime": "2026-09-22T04:09:29.170Z",
		"size": 960,
		"path": "../public/assets/products.lubes-5n6ecJgi.js"
	},
	"/assets/resources.video-gallery-B7bw0JSS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef6-KKcdgglEG60MI8DG+jdIxahlfqo\"",
		"mtime": "2026-09-22T04:09:29.174Z",
		"size": 3830,
		"path": "../public/assets/resources.video-gallery-B7bw0JSS.js"
	},
	"/assets/react-dom-C3P-7zdq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-G3ZC9pMYApYU42TA5fWZ8aObfNs\"",
		"mtime": "2026-09-22T04:09:29.172Z",
		"size": 3546,
		"path": "../public/assets/react-dom-C3P-7zdq.js"
	},
	"/assets/routes-C7LtuU0t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2491-uvN/gcjhwZyWfRUGpbvM3UMtG3I\"",
		"mtime": "2026-09-22T04:09:29.175Z",
		"size": 9361,
		"path": "../public/assets/routes-C7LtuU0t.js"
	},
	"/assets/shield-check-qnCRlTvT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-8/A752vJxV+c2nFuvh15CH1Wv5U\"",
		"mtime": "2026-09-22T04:09:29.175Z",
		"size": 310,
		"path": "../public/assets/shield-check-qnCRlTvT.js"
	},
	"/assets/skeleton-B7qN7Xfk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5-gNHjXrIgSRH6xJowMPfcjYGB3TY\"",
		"mtime": "2026-09-22T04:09:29.176Z",
		"size": 229,
		"path": "../public/assets/skeleton-B7qN7Xfk.js"
	},
	"/assets/switch-BSuCKpGK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132d-J8dRITORMAVIDFxbtTGFS8n2rAk\"",
		"mtime": "2026-09-22T04:09:29.176Z",
		"size": 4909,
		"path": "../public/assets/switch-BSuCKpGK.js"
	},
	"/assets/textarea-Dr1NXiza.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"208-4rypCdXTRJWp7CyMb47rTKKzZ20\"",
		"mtime": "2026-09-22T04:09:29.177Z",
		"size": 520,
		"path": "../public/assets/textarea-Dr1NXiza.js"
	},
	"/assets/useMutation-CvGTbxhr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"927-Ke7u3R9p0YQecJTDGHBx2RG8f5U\"",
		"mtime": "2026-09-22T04:09:29.178Z",
		"size": 2343,
		"path": "../public/assets/useMutation-CvGTbxhr.js"
	},
	"/assets/vehicle-card-CYkkcqh6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b6-KgpqhRcOhRGS8OLOo/LKbNnEvCA\"",
		"mtime": "2026-09-22T04:09:29.179Z",
		"size": 1974,
		"path": "../public/assets/vehicle-card-CYkkcqh6.js"
	},
	"/assets/vehicles.index-CjptqMyg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7b-ZG8BCgFOvK9kwc57+rKpjulB37w\"",
		"mtime": "2026-09-22T04:09:29.180Z",
		"size": 3195,
		"path": "../public/assets/vehicles.index-CjptqMyg.js"
	},
	"/assets/vehicles._slug-B-dHxvWm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5598-zrQFkiUmDAS+fI64x0dN9qRKTf8\"",
		"mtime": "2026-09-22T04:09:29.179Z",
		"size": 21912,
		"path": "../public/assets/vehicles._slug-B-dHxvWm.js"
	},
	"/assets/styles-Bdav6Fgd.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"161dc-Iw0keHfTHyA2D60jTswEu77LLFc\"",
		"mtime": "2026-09-22T04:09:29.185Z",
		"size": 90588,
		"path": "../public/assets/styles-Bdav6Fgd.css"
	},
	"/assets/lubes-chemicals-BRqesYht.jpg": {
		"type": "image/jpeg",
		"etag": "\"2597d-BZanb4KU2+i91IGmZhcbVSq1cqM\"",
		"mtime": "2026-09-22T04:09:29.184Z",
		"size": 153981,
		"path": "../public/assets/lubes-chemicals-BRqesYht.jpg"
	},
	"/assets/video-gallery-cover-COE9Pq-q.jpg": {
		"type": "image/jpeg",
		"etag": "\"28a10-qrIMFmSAPRUghLSMy0T6hFlumZk\"",
		"mtime": "2026-09-22T04:09:29.186Z",
		"size": 166416,
		"path": "../public/assets/video-gallery-cover-COE9Pq-q.jpg"
	},
	"/assets/wrench-EzsjIp6q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"125-WFJnenN+l5eSL8lnnXRwfhcujXY\"",
		"mtime": "2026-09-22T04:09:29.181Z",
		"size": 293,
		"path": "../public/assets/wrench-EzsjIp6q.js"
	},
	"/assets/x-O92UbkGL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-dQBiKG+G9BjAJnEHWp+og04+mcs\"",
		"mtime": "2026-09-22T04:09:29.181Z",
		"size": 144,
		"path": "../public/assets/x-O92UbkGL.js"
	},
	"/images/demo/activa-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"15873-9yPJULYyuZRxRPIgfkTow2/RWYE\"",
		"mtime": "2026-09-04T10:55:07.700Z",
		"size": 88179,
		"path": "../public/images/demo/activa-125.jpg"
	},
	"/images/demo/activa-6g.jpg": {
		"type": "image/jpeg",
		"etag": "\"b545-wnWewHEzowz8uiSll3vbMUGlabM\"",
		"mtime": "2026-09-04T10:55:07.702Z",
		"size": 46405,
		"path": "../public/images/demo/activa-6g.jpg"
	},
	"/images/demo/dio.jpg": {
		"type": "image/jpeg",
		"etag": "\"dd85-3Mp/nzRBmqlud5vU5Kyx2tSU9v8\"",
		"mtime": "2026-09-04T10:55:07.704Z",
		"size": 56709,
		"path": "../public/images/demo/dio.jpg"
	},
	"/images/demo/hero-showroom.jpg": {
		"type": "image/jpeg",
		"etag": "\"29c7a-zAlW5T0hx8yWNugetKie80I09IU\"",
		"mtime": "2026-09-04T10:55:07.708Z",
		"size": 171130,
		"path": "../public/images/demo/hero-showroom.jpg"
	},
	"/images/demo/shine-100.jpg": {
		"type": "image/jpeg",
		"etag": "\"188b7-LKKaUiqQSuCq/IlW2U0lgtbWpLo\"",
		"mtime": "2026-09-04T10:55:07.710Z",
		"size": 100535,
		"path": "../public/images/demo/shine-100.jpg"
	},
	"/images/demo/shine-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"16228-57py96T3f0JvDby1huiE/elTVV0\"",
		"mtime": "2026-09-04T10:55:07.713Z",
		"size": 90664,
		"path": "../public/images/demo/shine-125.jpg"
	},
	"/images/demo/sp-125.jpg": {
		"type": "image/jpeg",
		"etag": "\"14eea-qBd/lahacVSlvEwxKKP5uhmK0KA\"",
		"mtime": "2026-09-04T10:55:07.719Z",
		"size": 85738,
		"path": "../public/images/demo/sp-125.jpg"
	},
	"/images/demo/showroom-interior.jpg": {
		"type": "image/jpeg",
		"etag": "\"3b13a-WEMYZJKJOxdqaAX0aAb/DCqylRc\"",
		"mtime": "2026-09-04T10:55:07.716Z",
		"size": 241978,
		"path": "../public/images/demo/showroom-interior.jpg"
	},
	"/images/demo/unicorn.jpg": {
		"type": "image/jpeg",
		"etag": "\"16e6f-Nb+Is/kf3keLszTQzOf0bLqYYcE\"",
		"mtime": "2026-09-04T10:55:07.721Z",
		"size": 93807,
		"path": "../public/images/demo/unicorn.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_Rgmles = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_Rgmles
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
