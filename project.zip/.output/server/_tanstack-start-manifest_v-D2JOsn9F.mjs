//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D2JOsn9F.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/contact",
			"/offers",
			"/products/accessories",
			"/products/ev",
			"/products/lubes",
			"/resources/video-gallery",
			"/vehicles/$slug",
			"/vehicles/"
		],
		preloads: [
			"/assets/index-Bz4Yq3-y.js",
			"/assets/jsx-runtime-BKllkxft.js",
			"/assets/react-dom-C3P-7zdq.js",
			"/assets/link-BfEU25L_.js",
			"/assets/Match-dYEIYYWP.js",
			"/assets/matchContext-CRq-ZNtE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bz4Yq3-y.js"
		} }]
	},
	"/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C7LtuU0t.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/button-tix-khff.js",
			"/assets/arrow-right-CMI1S-5S.js",
			"/assets/badge-percent-XuGw1xpv.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/phone-CauQ93-b.js",
			"/assets/shield-check-qnCRlTvT.js",
			"/assets/wrench-EzsjIp6q.js",
			"/assets/skeleton-B7qN7Xfk.js",
			"/assets/vehicle-card-CYkkcqh6.js"
		]
	},
	"/about": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-Dp5ZhMrk.js",
			"/assets/button-tix-khff.js",
			"/assets/arrow-right-CMI1S-5S.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/phone-CauQ93-b.js"
		]
	},
	"/admin": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.tsx",
		children: [
			"/admin/enquiries",
			"/admin/offers",
			"/admin/vehicles",
			"/admin/"
		],
		preloads: [
			"/assets/admin-DPnI3uuE.js",
			"/assets/button-tix-khff.js",
			"/assets/badge-percent-XuGw1xpv.js",
			"/assets/bike-fqNSro4a.js",
			"/assets/inbox-BCCNuaGy.js",
			"/assets/shield-check-qnCRlTvT.js",
			"/assets/label-Dmeazhsc.js"
		]
	},
	"/contact": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CoYsyw2D.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/enquiry-form-CBZSLJcB.js",
			"/assets/clock-BIb4EeNf.js",
			"/assets/phone-CauQ93-b.js"
		]
	},
	"/offers": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-FSnxDa82.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/button-tix-khff.js",
			"/assets/badge-percent-XuGw1xpv.js",
			"/assets/bike-fqNSro4a.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/phone-CauQ93-b.js",
			"/assets/skeleton-B7qN7Xfk.js"
		]
	},
	"/admin/enquiries": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.enquiries.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.enquiries-Bbaqj1-S.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/useMutation-CvGTbxhr.js",
			"/assets/phone-CauQ93-b.js",
			"/assets/skeleton-B7qN7Xfk.js"
		]
	},
	"/admin/offers": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.offers.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.offers-BSxo9Cvs.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/useMutation-CvGTbxhr.js",
			"/assets/switch-BSuCKpGK.js",
			"/assets/skeleton-B7qN7Xfk.js",
			"/assets/textarea-Dr1NXiza.js"
		]
	},
	"/admin/vehicles": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.vehicles.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.vehicles-BNfAqqLA.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/useMutation-CvGTbxhr.js",
			"/assets/switch-BSuCKpGK.js",
			"/assets/x-O92UbkGL.js",
			"/assets/skeleton-B7qN7Xfk.js",
			"/assets/textarea-Dr1NXiza.js",
			"/assets/availability-badge-CxeFbWBw.js"
		]
	},
	"/products/accessories": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.accessories.tsx",
		children: void 0,
		preloads: ["/assets/products.accessories-s0NnaiLq.js", "/assets/product-category-page-Dbr-xALf.js"]
	},
	"/products/ev": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.ev.tsx",
		children: void 0,
		preloads: ["/assets/products.ev-BFwJbO-8.js", "/assets/product-category-page-Dbr-xALf.js"]
	},
	"/products/lubes": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/products.lubes.tsx",
		children: void 0,
		preloads: ["/assets/products.lubes-5n6ecJgi.js", "/assets/product-category-page-Dbr-xALf.js"]
	},
	"/resources/video-gallery": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/resources.video-gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/resources.video-gallery-B7bw0JSS.js",
			"/assets/button-tix-khff.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/shield-check-qnCRlTvT.js",
			"/assets/wrench-EzsjIp6q.js"
		]
	},
	"/vehicles/$slug": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/vehicles.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles._slug-B-dHxvWm.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/button-tix-khff.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/enquiry-form-CBZSLJcB.js",
			"/assets/phone-CauQ93-b.js",
			"/assets/dist-GkryDKTG.js",
			"/assets/dist-BzAtln6b.js",
			"/assets/skeleton-B7qN7Xfk.js",
			"/assets/label-Dmeazhsc.js",
			"/assets/dist-7gLvwnpF.js",
			"/assets/availability-badge-CxeFbWBw.js"
		]
	},
	"/admin/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CrE_vqoh.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/arrow-right-CMI1S-5S.js",
			"/assets/circle-check-C1PbQvQy.js",
			"/assets/skeleton-B7qN7Xfk.js"
		]
	},
	"/vehicles/": {
		filePath: "D:/New-honda/premium-two-wheel/src/routes/vehicles.index.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles.index-CjptqMyg.js",
			"/assets/catalogue-CxXghWEH.js",
			"/assets/button-tix-khff.js",
			"/assets/mobile-contact-bar-BwFnMLib.js",
			"/assets/skeleton-B7qN7Xfk.js",
			"/assets/vehicle-card-CYkkcqh6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
