import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Vehicle = {
  id: string;
  slug: string;
  name: string;
  category: string;
  short_description: string;
  description: string;
  price_from: number | null;
  image_url: string;
  gallery: string[];
  variants: string[];
  colors: string[];
  specs: Record<string, string>;
  is_available: boolean;
  is_featured: boolean;
  sort_order: number;
  video_url: string | null;
  info_context: string;
};

export type Product = {
  id: string;
  category: "lubes" | "accessories";
  name: string;
  short_description: string;
  description: string;
  price: number | null;
  image_url: string;
  gallery: string[];
  specs: Record<string, string>;
  is_available: boolean;
  is_featured: boolean;
  sort_order: number;
};

export type Offer = {
  id: string;
  title: string;
  description: string;
  applicable_vehicles: string;
  benefit: string;
  valid_until: string | null;
  is_active: boolean;
  sort_order: number;
};

export type Enquiry = {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  vehicle_interest: string | null;
  message: string;
  status: string;
  created_at: string;
};

export type VariantColour = {
  id: string;
  variant_id: string;
  name: string;
  images: string[];
  sort_order: number;
};

export type EmiOption = {
  months: number;
  rate: number;
};

export type VehicleVariant = {
  id: string;
  vehicle_id: string;
  name: string;
  price: number | null;
  ex_showroom_price: number | null;
  on_road_price: number | null;
  emi_options: EmiOption[];
  specs: Record<string, string>;
  is_available: boolean;
  sort_order: number;
  colours: VariantColour[];
};

export const normaliseEmiOptions = (value: unknown): EmiOption[] =>
  (Array.isArray(value) ? value : [])
    .map((item) => {
      const row = (item ?? {}) as Record<string, unknown>;
      return { months: Number(row["months"]) || 0, rate: Number(row["rate"]) || 0 };
    })
    .filter((option) => option.months > 0);

/** Standard reducing-balance EMI. */
export const calculateEmi = (principal: number, annualRate: number, months: number) => {
  if (principal <= 0 || months <= 0) return 0;
  const monthly = annualRate / 12 / 100;
  if (monthly === 0) return principal / months;
  const factor = Math.pow(1 + monthly, months);
  return (principal * monthly * factor) / (factor - 1);
};

export const EMI_DISCLAIMER =
  "EMI and on-road price are indicative and may vary based on lender, insurance, RTO charges, offers and other applicable charges.";

const asVehicle = (row: Record<string, unknown>): Vehicle => ({
  ...(row as unknown as Vehicle),
  price_from: row["price_from"] == null ? null : Number(row["price_from"]),
  specs: (row["specs"] ?? {}) as Record<string, string>,
  video_url: (row["video_url"] as string | null) ?? null,
  info_context: (row["info_context"] as string | null) ?? "",
});

const asProduct = (row: Record<string, unknown>): Product => ({
  ...(row as unknown as Product),
  price: row["price"] == null ? null : Number(row["price"]),
  specs: (row["specs"] ?? {}) as Record<string, string>,
  gallery: (row["gallery"] ?? []) as string[],
});

const asVariant = (row: Record<string, unknown>): VehicleVariant => ({
  ...(row as unknown as VehicleVariant),
  price: row["price"] == null ? null : Number(row["price"]),
  ex_showroom_price:
    row["ex_showroom_price"] == null
      ? row["price"] == null
        ? null
        : Number(row["price"])
      : Number(row["ex_showroom_price"]),
  on_road_price: row["on_road_price"] == null ? null : Number(row["on_road_price"]),
  emi_options: normaliseEmiOptions(row["emi_options"]),
  specs: (row["specs"] ?? {}) as Record<string, string>,
  colours: ((row["variant_colours"] ?? []) as Record<string, unknown>[])
    .map((colour) => colour as unknown as VariantColour)
    .sort((a, b) => a.sort_order - b.sort_order),
});

export const variantsQuery = (vehicleId: string | undefined) =>
  queryOptions({
    queryKey: ["variants", vehicleId ?? "none"],
    enabled: Boolean(vehicleId),
    queryFn: async (): Promise<VehicleVariant[]> => {
      if (!vehicleId) return [];
      const { data, error } = await supabase
        .from("vehicle_variants")
        .select("*, variant_colours(*)")
        .eq("vehicle_id", vehicleId)
        .order("sort_order", { ascending: true });
      if (error) throw new Error(error.message);
      return (data ?? []).map(asVariant);
    },
  });


export const vehiclesQuery = queryOptions({
  queryKey: ["vehicles"],
  queryFn: async (): Promise<Vehicle[]> => {
    const { data, error } = await supabase
      .from("vehicles")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []).map(asVehicle);
  },
});

export const vehicleQuery = (slug: string) =>
  queryOptions({
    queryKey: ["vehicle", slug],
    queryFn: async (): Promise<Vehicle | null> => {
      const { data, error } = await supabase
        .from("vehicles")
        .select("*")
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data ? asVehicle(data) : null;
    },
  });

export const productQuery = (id: string) =>
  queryOptions({
    queryKey: ["product", id],
    enabled: Boolean(id),
    queryFn: async (): Promise<Product | null> => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data ? asProduct(data) : null;
    },
  });

export const productsQuery = (category?: "lubes" | "accessories") =>
  queryOptions({
    queryKey: ["products", category ?? "all"],
    queryFn: async (): Promise<Product[]> => {
      let query = supabase.from("products").select("*").order("sort_order", { ascending: true });
      if (category) query = query.eq("category", category);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return (data ?? []).map(asProduct);
    },
  });

export const offersQuery = queryOptions({
  queryKey: ["offers"],
  queryFn: async (): Promise<Offer[]> => {
    const { data, error } = await supabase
      .from("offers")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []) as Offer[];
  },
});

export const enquiriesQuery = queryOptions({
  queryKey: ["enquiries"],
  queryFn: async (): Promise<Enquiry[]> => {
    const { data, error } = await supabase
      .from("enquiries")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as Enquiry[];
  },
});
